import { useEffect } from 'react';
import '../styles/main.css';
import '../styles/mobile.css';
import '../legacy/main.firebase.js';
import { init as initMainPage } from '../legacy/main.legacy.js';
import MobileNav from '../components/MobileNav';
import SosButton from '../components/SosButton';
import HomeHeader from '../components/HomeHeader';
import PromoCarousel from '../components/PromoCarousel';
import Tracker from '../components/Tracker';
import Rekomendasi from '../components/Rekomendasi';
import AsistenChat from '../components/AsistenChat';
import AkunPage from '../components/AkunPage';

export default function MainPage() {
  useEffect(() => {
    initMainPage();
  }, []);

  return (
      <div>
        <div id="toast-box" />
        <MobileNav />
        <SosButton />

        {/* ══════════ BERANDA ══════════ */}
        <div id="page-dash" className="page">
          <nav className="topbar">
            <div style={{display: 'flex', alignItems: 'center'}}>
              <div className="tb-logo" onClick={(event) => { goPage('dash'); }}><img src="/assets/stuntingcare-wordmark.png" alt="StuntingCare" /></div>
            </div>
            <div className="topbar-right" style={{display: 'flex', alignItems: 'center', gap: 10}}>
              <div className="user-pill" onClick={(event) => { goPage('akun'); }}>
                <div className="u-ava" id="dash-ava">U</div>
                <span style={{fontSize: '.84rem', fontWeight: 600}} id="dash-uname">User</span>
              </div>
            </div>
          </nav>
          <div className="dash-body">
            <HomeHeader />
            <PromoCarousel />
            <Tracker />
            <Rekomendasi />
          </div>
        </div>

        {/* ══════════ ASISTEN (CHATBOT AI) ══════════ */}
        <div id="page-asisten" className="page">
          <nav className="topbar">
            <div style={{display: 'flex', alignItems: 'center'}}>
              <div className="tb-logo" onClick={(event) => { goPage('dash'); }}><img src="/assets/stuntingcare-wordmark.png" alt="StuntingCare" /></div>
            </div>
          </nav>
          <AsistenChat />
        </div>

        {/* ══════════ AKUN SAYA ══════════ */}
        <div id="page-akun" className="page">
          <AkunPage />
        </div>

        {/* ══════════ KONSULTASI / CHAT DOKTER ══════════ */}
        <div id="page-chat" className="page">
          <nav className="topbar">
            <div style={{display: 'flex', alignItems: 'center'}}>
              <div className="tb-logo" onClick={(event) => { goPage('dash'); }}><img src="/assets/stuntingcare-wordmark.png" alt="StuntingCare" /></div>
            </div>
            <div className="topbar-right"><div className="user-pill" onClick={(event) => { showUM(); }}><div className="u-ava" id="chat-ava">U</div><span style={{fontSize: '.84rem', fontWeight: 600}} id="chat-uname">User</span></div></div>
          </nav>
          <div className="chat-page-wrap">
            <div className="chat-sidebar">
              <div className="chat-sidebar-hd">
                <h3><span className="material-symbols-rounded">chat</span> <span id="chat-hd-title">Konsultasi Saya</span></h3>
                <p id="chat-hd-sub">Riwayat &amp; sesi konsultasi Anda</p>
              </div>
              <div className="chat-search" id="chat-search-wrap"><button className="btn btn-primary btn-full btn-sm" onClick={() => { window.dispatchEvent(new Event('sc:konsul')); }}><span className="material-symbols-rounded">add</span> Mulai Konsultasi Baru</button></div>
              <div className="doc-list" id="doc-list" />
            </div>
            <div className="chat-main" id="chat-main">
              <button className="chat-back" onClick={() => {
                document.getElementById('chat-messages').style.display = 'none';
                document.getElementById('chat-input-area').style.display = 'none';
              }}><span className="material-symbols-rounded">arrow_back</span> Daftar konsultasi</button>
              <div className="chat-topbar" id="chat-topbar">
                <div style={{fontSize: '1.4rem'}}><span className="material-symbols-rounded">chat</span></div>
                <div><div className="chat-doc-name">Pilih Dokter</div><div className="chat-doc-status" style={{color: 'var(--gray)'}}>Silakan pilih dokter dari panel kiri</div></div>
              </div>
              <div className="chat-empty" id="chat-empty">
                <div className="chat-empty-icon"><span className="material-symbols-rounded">chat</span></div>
                <div className="chat-empty-title">Mulai Konsultasi</div>
                <div className="chat-empty-sub">Pilih dokter spesialis dari panel kiri untuk memulai sesi konsultasi online secara real-time.</div>
              </div>
              <div className="chat-messages" id="chat-messages" style={{display: 'none'}} />
              <div className="chat-input-area" id="chat-input-area" style={{display: 'none'}}>
                <textarea className="chat-input" id="chat-input-box" placeholder="Tulis pesan atau pertanyaan Anda..." rows={1} onKeyDown={(event) => { chatEnter(event); }} onInput={(event) => { autoH(event.currentTarget); }} defaultValue={""} />
                <button className="send-btn" onClick={(event) => { sendChat(); }}>➤</button>
              </div>
            </div>
          </div>
        </div>

        {/* ══════════ MODAL ══════════ */}
        <div className="modal-bg" id="summary-modal" onClick={(event) => { if(event.target===event.currentTarget) window.closeSummaryModal(); }}>
          <div className="modal" style={{maxWidth: 460}}>
            <div className="modal-hd">
              <div className="modal-title"><span className="material-symbols-rounded">auto_awesome</span> Ringkasan Percakapan</div>
              <button className="modal-x" onClick={(event) => { window.closeSummaryModal(); }}>✕</button>
            </div>
            <div id="summary-modal-body" />
          </div>
        </div>
        <div className="modal-bg" id="um-modal" onClick={(event) => { if(event.target===event.currentTarget)closeUM(); }}>
          <div className="modal" style={{maxWidth: 320}}>
            <div className="modal-hd"><div className="modal-title">Akun Saya</div><button className="modal-x" onClick={(event) => { closeUM(); }}>✕</button></div>
            <div style={{textAlign: 'center', padding: '14px 0 20px'}}>
              <div style={{width: 60, height: 60, borderRadius: '50%', background: 'linear-gradient(135deg,var(--teal),var(--teal3))', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 700, fontSize: '1.3rem', margin: '0 auto 11px'}} id="um-ava">U</div>
              <div style={{fontFamily: '"Plus Jakarta Sans",sans-serif', fontSize: '1.05rem', fontWeight: 700, color: 'var(--navy)'}} id="um-name">–</div>
              <div style={{fontSize: '.82rem', color: 'var(--gray)', marginTop: 3}} id="um-email">–</div>
            </div>
            <button className="btn btn-danger btn-full" onClick={(event) => { doLogout(); }}><span className="material-symbols-rounded">logout</span> Keluar dari Akun</button>
          </div>
        </div>
      </div>
  );
}