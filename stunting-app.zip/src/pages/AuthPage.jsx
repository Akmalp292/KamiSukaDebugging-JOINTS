import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  GoogleAuthProvider, createUserWithEmailAndPassword, sendPasswordResetEmail,
  signInWithEmailAndPassword, signInWithPopup, signOut, updateProfile,
} from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { loadMaskot } from '../lib/maskot';
import MaskotStage from '../components/MaskotStage';
import '../styles/auth.css';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const FITUR = [
  { ic: 'monitor_weight', g: ['#17806F', '#2BB5A0'], t: 'Pelacak Pertumbuhan', d: 'Catat berat dan tinggi badan, lihat status hijau, kuning, atau merah berdasarkan standar WHO.' },
  { ic: 'forum', g: ['#E8872E', '#F4A261'], t: 'Konsultasi Dokter Online', d: 'Chat dengan dokter yang sedang online, lalu dapat ringkasan 3 poin dari AI.' },
  { ic: 'emergency', g: ['#DC143C', '#F0506E'], t: 'Tombol SOS Darurat', d: 'Cari faskes terdekat, panduan pertolongan pertama, dan hubungi 119.' },
];

function sesi() {
  try { return JSON.parse(localStorage.getItem('sc_s') || 'null'); } catch { return null; }
}

function pesanError(e) {
  switch (e && e.code) {
    case 'auth/invalid-credential':
    case 'auth/invalid-login-credentials':
    case 'auth/wrong-password':
    case 'auth/user-not-found': return 'Email atau kata sandi salah.';
    case 'auth/invalid-email': return 'Format email tidak valid.';
    case 'auth/email-already-in-use': return 'Email ini sudah terdaftar. Silakan masuk.';
    case 'auth/weak-password': return 'Kata sandi terlalu lemah (minimal 6 karakter).';
    case 'auth/too-many-requests': return 'Terlalu banyak percobaan. Coba lagi beberapa menit lagi.';
    case 'auth/network-request-failed': return 'Koneksi internet bermasalah. Coba lagi.';
    case 'auth/popup-closed-by-user':
    case 'auth/cancelled-popup-request': return '';
    case 'auth/popup-blocked': return 'Pop-up diblokir browser. Izinkan pop-up lalu coba lagi.';
    case 'auth/unauthorized-domain': return 'Domain ini belum didaftarkan di Firebase (Authentication → Authorized domains).';
    default: return 'Terjadi kesalahan. Coba lagi.';
  }
}

// simpan sesi dengan format yang dibaca main.legacy.js, lalu tentukan peran dari koleksi doctors
async function simpanSesi(user, namaCadangan) {
  let role = 'pasien';
  let name = user.displayName || namaCadangan || (user.email || 'Pengguna').split('@')[0];
  try {
    const d = await getDoc(doc(db, 'doctors', user.uid));
    if (d.exists()) {
      role = 'dokter';
      name = d.data().name || name;
    }
  } catch (e) {
    console.error('[auth] gagal membaca data dokter', e);
  }
  const s = { uid: user.uid, name, email: user.email || '', ava: (name[0] || 'U').toUpperCase(), role };
  try { localStorage.setItem('sc_s', JSON.stringify(s)); } catch { /* abaikan */ }
}

export default function AuthPage() {
  const nav = useNavigate();
  const [mode, setMode] = useState('masuk');
  const [nama, setNama] = useState('');
  const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');
  const [lihat, setLihat] = useState(false);
  const [setuju, setSetuju] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [info, setInfo] = useState('');
  const [cfg] = useState(loadMaskot);

  // sudah login -> langsung ke app; sisa sesi yang tidak cocok dibersihkan
  useEffect(() => {
    let batal = false;
    (async () => {
      if (auth.authStateReady) await auth.authStateReady();
      if (batal) return;
      const s = sesi();
      const u = auth.currentUser;
      if (s && s.uid && u && u.uid === s.uid) {
        nav('/main', { replace: true });
      } else if (u && !s) {
        signOut(auth).catch(() => {});
      } else if (s && !u) {
        try { localStorage.removeItem('sc_s'); } catch { /* abaikan */ }
      }
    })();
    return () => { batal = true; };
  }, [nav]);

  function ganti(m) {
    setMode(m);
    setErr('');
    setInfo('');
  }

  async function masuk(e) {
    e.preventDefault();
    setErr('');
    setInfo('');
    if (!EMAIL_RE.test(email.trim())) return setErr('Format email tidak valid.');
    if (!pass) return setErr('Kata sandi wajib diisi.');
    setBusy(true);
    try {
      const cred = await signInWithEmailAndPassword(auth, email.trim(), pass);
      await simpanSesi(cred.user);
      nav('/main', { replace: true });
    } catch (ex) {
      console.error('[auth] masuk', ex);
      setErr(pesanError(ex));
    } finally { setBusy(false); }
  }

  async function daftar(e) {
    e.preventDefault();
    setErr('');
    setInfo('');
    if (nama.trim().length < 2) return setErr('Nama wajib diisi.');
    if (!EMAIL_RE.test(email.trim())) return setErr('Format email tidak valid.');
    if (pass.length < 6) return setErr('Kata sandi minimal 6 karakter.');
    if (!setuju) return setErr('Centang persetujuan Syarat & Ketentuan dan Kebijakan Privasi.');
    setBusy(true);
    try {
      const cred = await createUserWithEmailAndPassword(auth, email.trim(), pass);
      try { await updateProfile(cred.user, { displayName: nama.trim() }); } catch (ex) { console.error('[auth] updateProfile', ex); }
      await simpanSesi(cred.user, nama.trim());
      nav('/main', { replace: true });
    } catch (ex) {
      console.error('[auth] daftar', ex);
      setErr(pesanError(ex));
    } finally { setBusy(false); }
  }

  async function google() {
    setErr('');
    setInfo('');
    if (mode === 'daftar' && !setuju) return setErr('Centang persetujuan Syarat & Ketentuan dan Kebijakan Privasi.');
    setBusy(true);
    try {
      const cred = await signInWithPopup(auth, new GoogleAuthProvider());
      await simpanSesi(cred.user);
      nav('/main', { replace: true });
    } catch (ex) {
      console.error('[auth] google', ex);
      setErr(pesanError(ex));
    } finally { setBusy(false); }
  }

  async function lupa() {
    setErr('');
    setInfo('');
    if (!EMAIL_RE.test(email.trim())) return setErr('Isi email dulu, lalu tekan Lupa kata sandi.');
    setBusy(true);
    try {
      await sendPasswordResetEmail(auth, email.trim());
      setInfo(`Tautan untuk mengatur ulang kata sandi dikirim ke ${email.trim()}. Cek juga folder Spam.`);
    } catch (ex) {
      console.error('[auth] reset', ex);
      setErr(pesanError(ex));
    } finally { setBusy(false); }
  }

  return (
    <div className="au-wrap">
      <div className="au-shell">
        <div className="au-top">
          <i className="au-blob b1" />
          <i className="au-blob b2" />
          <div className="au-logo"><img src="/assets/stuntingcare-logo-white-text.png" alt="StuntingCare" /></div>
          <div className="au-hero">
            <div className="au-bubble">Halo, Bunda! 👋</div>
            <MaskotStage cfg={cfg} view="full" size={128} />
          </div>
          <div className="au-h">Pantau tumbuh kembang si kecil bersama kami</div>
          <p className="au-p">Catat pertumbuhan, tanya asisten AI, dan konsultasi dengan dokter kapan saja.</p>
        </div>

        <div className="au-card">
          <div className="au-tabs">
            <button type="button" className={'au-tab' + (mode === 'masuk' ? ' on' : '')} onClick={() => ganti('masuk')}>Masuk</button>
            <button type="button" className={'au-tab' + (mode === 'daftar' ? ' on' : '')} onClick={() => ganti('daftar')}>Daftar</button>
          </div>

          <div className="au-title">{mode === 'masuk' ? 'Selamat datang kembali' : 'Buat akun gratis'}</div>
          <p className="au-sub">{mode === 'masuk' ? 'Masuk untuk melanjutkan.' : 'Cukup beberapa detik untuk mulai.'}</p>

          {err && <div className="au-err">{err}</div>}
          {info && <div className="au-ok">{info}</div>}

          <form onSubmit={mode === 'masuk' ? masuk : daftar} noValidate>
            {mode === 'daftar' && (
              <div className="au-f">
                <label htmlFor="au-nama">Nama lengkap</label>
                <input id="au-nama" className="au-in" autoComplete="name" value={nama} onChange={(e) => setNama(e.target.value)} placeholder="Nama Bunda" />
              </div>
            )}
            <div className="au-f">
              <label htmlFor="au-email">Email</label>
              <input id="au-email" className="au-in" type="email" inputMode="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email@anda.com" />
            </div>
            <div className="au-f">
              <label htmlFor="au-pass">Kata sandi</label>
              <div className="au-pw">
                <input
                  id="au-pass"
                  className="au-in"
                  type={lihat ? 'text' : 'password'}
                  autoComplete={mode === 'masuk' ? 'current-password' : 'new-password'}
                  value={pass}
                  onChange={(e) => setPass(e.target.value)}
                  placeholder={mode === 'masuk' ? 'Kata sandi Anda' : 'Minimal 6 karakter'}
                />
                <button type="button" className="au-eye" onClick={() => setLihat((v) => !v)} aria-label={lihat ? 'Sembunyikan kata sandi' : 'Tampilkan kata sandi'}>
                  <span className="material-symbols-rounded">{lihat ? 'visibility_off' : 'visibility'}</span>
                </button>
              </div>
            </div>

            {mode === 'daftar' && (
              <label className="au-check">
                <input type="checkbox" checked={setuju} onChange={(e) => setSetuju(e.target.checked)} />
                <span>
                  Saya menyetujui <Link to="/syarat-ketentuan" target="_blank">Syarat &amp; Ketentuan</Link> dan{' '}
                  <Link to="/kebijakan-privasi" target="_blank">Kebijakan Privasi</Link>.
                </span>
              </label>
            )}

            <button className="au-btn" type="submit" disabled={busy}>
              {busy ? 'Memproses…' : mode === 'masuk' ? 'Masuk' : 'Buat Akun'}
            </button>
            {mode === 'masuk' && <button type="button" className="au-link" onClick={lupa} disabled={busy}>Lupa kata sandi?</button>}
          </form>

          <div className="au-or">atau</div>
          <button type="button" className="au-google" onClick={google} disabled={busy}>
            <svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true">
              <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.33 2.56 13.22l7.98 6.19C12.43 13.08 17.74 9.5 24 9.5z" />
              <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
              <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
              <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-3.58-13.46-8.91l-7.98 6.19C6.51 42.67 14.62 48 24 48z" />
            </svg>
            {mode === 'masuk' ? 'Masuk dengan Google' : 'Daftar dengan Google'}
          </button>
        </div>

        <div className="au-feats">
          {FITUR.map((f) => (
            <div className="au-feat" key={f.t}>
              <span className="au-feat-ic" style={{ background: `linear-gradient(135deg, ${f.g[0]}, ${f.g[1]})` }}>
                <span className="material-symbols-rounded">{f.ic}</span>
              </span>
              <span><b>{f.t}</b><small>{f.d}</small></span>
            </div>
          ))}
        </div>

        <div className="au-foot">
          Hasil pelacak adalah skrining awal, bukan diagnosis.<br />
          Dalam keadaan darurat, segera hubungi <a href="tel:119">119</a>.
        </div>
      </div>
    </div>
  );
}