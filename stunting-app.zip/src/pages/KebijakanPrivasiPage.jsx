import { useEffect } from 'react';
import '../styles/kebijakan-privasi.css';

export default function KebijakanPrivasiPage() {
  useEffect(() => {
    document.body.classList.add('legal-page');
    return () => document.body.classList.remove('legal-page');
  }, []);

  return (
      <div>
        <div className="header">
          <div className="header-inner">
            <div className="logo-icon">🌱</div>
            <div className="logo-text">Stunting<span>Care</span></div>
            <div className="page-badge">🔒 Kebijakan Privasi</div>
          </div>
        </div>
        <div className="content">
          <div className="hero-card">
            <div className="hero-icon">🔒</div>
            <div>
              <div className="hero-title">Kebijakan Privasi</div>
              <p className="hero-sub">StuntingCare berkomitmen melindungi privasi dan keamanan data pribadi Anda. Dokumen ini menjelaskan bagaimana kami mengumpulkan, menggunakan, dan melindungi informasi Anda.</p>
              <div className="last-update">📅 Terakhir diperbarui: Maret 2025</div>
            </div>
          </div>
          <div className="toc">
            <div className="toc-title">📌 Daftar Isi</div>
            <ol>
              <li><a href="#p1">Data yang Kami Kumpulkan</a></li>
              <li><a href="#p2">Cara Kami Menggunakan Data</a></li>
              <li><a href="#p3">Penyimpanan &amp; Keamanan Data</a></li>
              <li><a href="#p4">Berbagi Data dengan Pihak Ketiga</a></li>
              <li><a href="#p5">Cookies &amp; Teknologi Pelacakan</a></li>
              <li><a href="#p6">Hak-hak Pengguna</a></li>
              <li><a href="#p7">Data Anak &amp; Perlindungan Khusus</a></li>
              <li><a href="#p8">Perubahan Kebijakan</a></li>
              <li><a href="#p9">Hubungi Kami</a></li>
            </ol>
          </div>
          <section id="p1">
            <div className="section-hd"><span className="section-num">1</span>Data yang Kami Kumpulkan</div>
            <p>Kami mengumpulkan berbagai kategori informasi untuk menyediakan dan meningkatkan layanan:</p>
            <p><strong>Data Identitas:</strong></p>
            <ul>
              <li>Nama lengkap, alamat email, dan kata sandi (terenkripsi)</li>
              <li>Foto profil (jika diunggah)</li>
            </ul>
            <p><strong>Data Kesehatan (hanya untuk fitur terkait):</strong></p>
            <ul>
              <li>Data anak: nama, tanggal lahir, jenis kelamin, tinggi/berat badan untuk Stunting Checker</li>
              <li>Data penggunaan layanan: riwayat booking, hasil pemeriksaan, riwayat chat</li>
              <li>Informasi medis yang Anda bagikan secara sukarela dalam konsultasi</li>
            </ul>
            <p><strong>Data Teknis:</strong></p>
            <ul>
              <li>Alamat IP, jenis perangkat, dan browser yang digunakan</li>
              <li>Log aktivitas penggunaan platform</li>
            </ul>
            <div className="highlight-box"><p>🔐 Kami tidak pernah meminta data pembayaran atau nomor kartu kredit melalui platform ini.</p></div>
          </section>
          <section id="p2">
            <div className="section-hd"><span className="section-num">2</span>Cara Kami Menggunakan Data</div>
            <p>Data yang dikumpulkan digunakan secara terbatas untuk tujuan berikut:</p>
            <ul>
              <li>✅ Menyediakan dan memperbaiki layanan platform</li>
              <li>✅ Memproses booking appointment dan menghubungkan dengan dokter mitra</li>
              <li>✅ Mengirimkan notifikasi penting (konfirmasi email, pengingat jadwal)</li>
              <li>✅ Meningkatkan akurasi Stunting Checker berdasarkan data agregat anonim</li>
              <li>✅ Memenuhi kewajiban hukum dan regulasi kesehatan</li>
              <li>❌ Kami TIDAK menjual data pribadi Anda kepada pihak ketiga</li>
              <li>❌ Kami TIDAK menggunakan data untuk iklan pihak ketiga tanpa persetujuan</li>
            </ul>
          </section>
          <section id="p3">
            <div className="section-hd"><span className="section-num">3</span>Penyimpanan &amp; Keamanan Data</div>
            <p>Keamanan data Anda adalah prioritas utama kami:</p>
            <ul>
              <li>Data disimpan di server berkeamanan tinggi dengan enkripsi AES-256</li>
              <li>Kata sandi dienkripsi menggunakan algoritma hash satu arah (tidak dapat dibaca)</li>
              <li>Akses data dibatasi hanya kepada staf yang berwenang dengan audit trail</li>
              <li>Kami melakukan pemindaian keamanan berkala dan uji penetrasi</li>
              <li>Data akan disimpan selama akun aktif dan dihapus dalam 90 hari setelah penutupan akun</li>
            </ul>
            <div className="warn-box"><p>⚠️ Meski kami menerapkan langkah keamanan terbaik, tidak ada sistem yang 100% aman. Segera hubungi kami jika mencurigai kebocoran data.</p></div>
          </section>
          <section id="p4">
            <div className="section-hd"><span className="section-num">4</span>Berbagi Data dengan Pihak Ketiga</div>
            <p>Kami hanya berbagi data dengan pihak terbatas dan untuk tujuan spesifik:</p>
            <ul>
              <li><strong>Dokter Mitra</strong>: informasi booking dan keluhan pasien yang relevan untuk konsultasi</li>
              <li><strong>Rumah Sakit Mitra</strong>: konfirmasi jadwal appointment (nama, tanggal, jam)</li>
              <li><strong>Penyedia Layanan Teknis</strong>: hosting dan infrastruktur server (terikat NDA)</li>
              <li><strong>Otoritas Hukum</strong>: jika diwajibkan oleh hukum atau perintah pengadilan</li>
            </ul>
            <p>Semua mitra terikat perjanjian kerahasiaan data dan tidak diperbolehkan menggunakan data Anda di luar tujuan yang disepakati.</p>
          </section>
          <section id="p5">
            <div className="section-hd"><span className="section-num">5</span>Cookies &amp; Teknologi Pelacakan</div>
            <p>Kami menggunakan cookies untuk meningkatkan pengalaman pengguna:</p>
            <ul>
              <li><strong>Cookies Sesi</strong>: menjaga status login Anda selama menggunakan platform</li>
              <li><strong>Cookies Preferensi</strong>: menyimpan pengaturan bahasa dan tampilan</li>
              <li><strong>Cookies Analitik</strong>: memahami pola penggunaan secara anonim (tidak mengidentifikasi individu)</li>
            </ul>
            <p>Anda dapat mengatur preferensi cookies melalui pengaturan browser Anda. Namun, menonaktifkan cookies tertentu dapat mempengaruhi fungsi platform.</p>
          </section>
          <section id="p6">
            <div className="section-hd"><span className="section-num">6</span>Hak-hak Pengguna</div>
            <p>Sesuai regulasi perlindungan data, Anda memiliki hak-hak berikut:</p>
            <div className="rights-grid">
              <div className="right-item"><div className="right-ic">👁</div><div><div className="right-title">Hak Akses</div><div className="right-desc">Melihat data pribadi yang kami simpan tentang Anda</div></div></div>
              <div className="right-item"><div className="right-ic">✏️</div><div><div className="right-title">Hak Koreksi</div><div className="right-desc">Memperbarui data yang tidak akurat atau tidak lengkap</div></div></div>
              <div className="right-item"><div className="right-ic">🗑️</div><div><div className="right-title">Hak Penghapusan</div><div className="right-desc">Meminta penghapusan data pribadi Anda dari sistem kami</div></div></div>
              <div className="right-item"><div className="right-ic">📦</div><div><div className="right-title">Hak Portabilitas</div><div className="right-desc">Mendapatkan salinan data dalam format yang dapat dibaca mesin</div></div></div>
              <div className="right-item"><div className="right-ic">🚫</div><div><div className="right-title">Hak Pembatasan</div><div className="right-desc">Membatasi pemrosesan data dalam kondisi tertentu</div></div></div>
              <div className="right-item"><div className="right-ic">📢</div><div><div className="right-title">Hak Keberatan</div><div className="right-desc">Menolak pemrosesan data untuk tujuan tertentu</div></div></div>
            </div>
            <p>Untuk menggunakan hak-hak di atas, hubungi kami melalui email: <a href="mailto:layananStuntingcare@gmail.com">layananStuntingcare@gmail.com</a></p>
          </section>
          <section id="p7">
            <div className="section-hd"><span className="section-num">7</span>Data Anak &amp; Perlindungan Khusus</div>
            <p>StuntingCare dirancang untuk layanan kesehatan anak, sehingga kami menerapkan perlindungan tambahan:</p>
            <ul>
              <li>Data kesehatan anak hanya dapat diinput oleh orang tua atau wali yang terdaftar</li>
              <li>Anak di bawah 13 tahun tidak dapat mendaftarkan akun sendiri</li>
              <li>Data anak tidak dibagikan kepada pihak mana pun selain dokter yang menangani kasus tersebut</li>
              <li>Orang tua dapat meminta penghapusan data anak kapan saja</li>
            </ul>
            <div className="highlight-box"><p>🛡️ Perlindungan data anak adalah prioritas tertinggi kami. Data medis anak diperlakukan dengan standar keamanan paling ketat.</p></div>
          </section>
          <section id="p8">
            <div className="section-hd"><span className="section-num">8</span>Perubahan Kebijakan</div>
            <p>Kami dapat memperbarui Kebijakan Privasi ini dari waktu ke waktu. Perubahan signifikan akan diberitahukan melalui:</p>
            <ul>
              <li>Email ke alamat terdaftar Anda</li>
              <li>Notifikasi di dalam platform saat Anda masuk</li>
              <li>Pembaruan tanggal "Terakhir diperbarui" pada halaman ini</li>
            </ul>
            <p>Penggunaan platform setelah pemberitahuan dianggap sebagai penerimaan terhadap kebijakan yang diperbarui.</p>
          </section>
          <section id="p9">
            <div className="section-hd"><span className="section-num">9</span>Hubungi Kami</div>
            <p>Untuk pertanyaan, permintaan, atau keluhan terkait privasi data Anda:</p>
            <ul>
              <li>📧 <strong>Email DPO</strong>: <a href="mailto:layananStuntingcare@gmail.com">layananStuntingcare@gmail.com</a></li>
              <li>📞 <strong>Telepon</strong>: 081 923 231 331 (Sen–Sab 07.00–21.00 WIB)</li>
              <li>📍 <strong>Alamat</strong>: Jalan Monas Utama, Jakarta Selatan, Indonesia</li>
            </ul>
            <p>Kami berkomitmen merespons setiap pertanyaan privasi dalam waktu <strong>3 hari kerja</strong>.</p>
          </section>
          <div className="footer">
            <div style={{display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, marginBottom: 12}}>
              <img src="/assets/stuntingcare-logo.png" alt="StuntingCare" style={{height: 38}} />
            </div>
            <p>© 2025 StuntingCare. Semua hak dilindungi. Platform Kesehatan Anak Indonesia.</p>
            <button className="close-btn" onClick={(event) => { window.close(); }}>✕ Tutup Tab Ini</button>
          </div>
        </div>
      </div>

  );
}
