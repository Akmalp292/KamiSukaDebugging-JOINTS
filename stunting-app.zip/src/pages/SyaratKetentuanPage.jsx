import { useEffect } from 'react';
import '../styles/syarat-ketentuan.css';

export default function SyaratKetentuanPage() {
  useEffect(() => {
    document.body.classList.add('legal-page');
    return () => document.body.classList.remove('legal-page');
  }, []);

  return (
      <div>
        <div className="header">
          <div className="header-inner">
            <div className="logo-icon">🌱</div>
            <div className="logo-text">Stunting<span>Care</span></div>
            <div className="page-badge">📋 Syarat &amp; Ketentuan</div>
          </div>
        </div>
        <div className="content">
          <div className="hero-card">
            <div className="hero-icon">📋</div>
            <div>
              <div className="hero-title">Syarat &amp; Ketentuan Penggunaan</div>
              <p className="hero-sub">Dokumen ini mengatur hak dan kewajiban pengguna platform StuntingCare. Dengan menggunakan layanan kami, Anda menyatakan telah membaca, memahami, dan menyetujui seluruh ketentuan berikut.</p>
              <div className="last-update">📅 Terakhir diperbarui: Maret 2025</div>
            </div>
          </div>
          <div className="toc">
            <div className="toc-title">📌 Daftar Isi</div>
            <ol>
              <li><a href="#s1">Definisi dan Ruang Lingkup</a></li>
              <li><a href="#s2">Pendaftaran Akun</a></li>
              <li><a href="#s3">Penggunaan Layanan</a></li>
              <li><a href="#s4">Informasi Medis &amp; Konsultasi</a></li>
              <li><a href="#s5">Booking Appointment</a></li>
              <li><a href="#s6">Hak Kekayaan Intelektual</a></li>
              <li><a href="#s7">Batasan Tanggung Jawab</a></li>
              <li><a href="#s8">Perubahan &amp; Penghentian Layanan</a></li>
              <li><a href="#s9">Hukum yang Berlaku</a></li>
              <li><a href="#s10">Kontak</a></li>
            </ol>
          </div>
          <section id="s1">
            <div className="section-hd"><span className="section-num">1</span>Definisi dan Ruang Lingkup</div>
            <p><strong>StuntingCare</strong> adalah platform kesehatan digital yang menyediakan layanan deteksi stunting, edukasi, booking konsultasi dokter, dan chat online dengan tenaga medis.</p>
            <ul>
              <li><strong>Pengguna</strong>: setiap individu yang mendaftar dan menggunakan layanan StuntingCare.</li>
              <li><strong>Layanan</strong>: mencakup Stunting Checker, Chat Dokter, Booking Appointment, dan konten edukasi.</li>
              <li><strong>Platform</strong>: situs web dan aplikasi StuntingCare beserta seluruh fiturnya.</li>
            </ul>
            <div className="highlight-box"><p>Syarat ini berlaku untuk seluruh pengguna platform StuntingCare, baik yang mengakses secara gratis maupun berbayar.</p></div>
          </section>
          <section id="s2">
            <div className="section-hd"><span className="section-num">2</span>Pendaftaran Akun</div>
            <p>Untuk menggunakan sebagian besar fitur StuntingCare, Anda wajib membuat akun dengan ketentuan:</p>
            <ul>
              <li>Memberikan informasi yang akurat, lengkap, dan terkini saat pendaftaran.</li>
              <li>Menjaga kerahasiaan kata sandi dan bertanggung jawab atas seluruh aktivitas di akun Anda.</li>
              <li>Melakukan verifikasi email yang dikirimkan setelah pendaftaran sebelum dapat masuk.</li>
              <li>Tidak membagi akun kepada pihak lain atau menggunakan akun orang lain.</li>
              <li>Segera memberitahu kami jika terjadi akses tidak sah ke akun Anda.</li>
            </ul>
            <div className="warn-box"><p>⚠️ StuntingCare tidak bertanggung jawab atas kerugian yang timbul akibat kelalaian pengguna dalam menjaga kerahasiaan akun.</p></div>
          </section>
          <section id="s3">
            <div className="section-hd"><span className="section-num">3</span>Penggunaan Layanan</div>
            <p>Pengguna berkomitmen untuk menggunakan platform StuntingCare secara bertanggung jawab. Dilarang keras:</p>
            <ul>
              <li>Menggunakan layanan untuk tujuan yang melanggar hukum atau merugikan pihak lain.</li>
              <li>Mengunggah konten yang mengandung ujaran kebencian, pornografi, atau informasi palsu.</li>
              <li>Mencoba meretas, mengganggu, atau merusak sistem teknis platform.</li>
              <li>Menggunakan bot, scraper, atau alat otomatis untuk mengakses platform tanpa izin.</li>
              <li>Menerbitkan informasi medis yang tidak akurat atau menyesatkan kepada pengguna lain.</li>
            </ul>
          </section>
          <section id="s4">
            <div className="section-hd"><span className="section-num">4</span>Informasi Medis &amp; Konsultasi</div>
            <p>Layanan StuntingCare bersifat informatif dan <strong>tidak menggantikan diagnosis atau penanganan medis profesional</strong>.</p>
            <ul>
              <li>Hasil Stunting Checker adalah estimasi berbasis Z-Score WHO dan bukan diagnosis klinis resmi.</li>
              <li>Konsultasi chat dokter merupakan diskusi awal dan tidak setara dengan pemeriksaan tatap muka.</li>
              <li>Selalu konsultasikan kondisi kesehatan anak kepada dokter atau tenaga medis bersertifikat secara langsung.</li>
            </ul>
            <div className="highlight-box"><p>✅ StuntingCare bekerja sama dengan dokter berlisensi. Namun, keputusan medis tetap merupakan kewenangan dokter dan pasien.</p></div>
          </section>
          <section id="s5">
            <div className="section-hd"><span className="section-num">5</span>Booking Appointment</div>
            <p>Layanan booking appointment menghubungkan pengguna dengan dokter mitra. Ketentuan:</p>
            <ul>
              <li>Pembatalan appointment wajib dilakukan minimal 24 jam sebelum jadwal.</li>
              <li>Keterlambatan lebih dari 15 menit dapat mengakibatkan pembatalan sepihak oleh dokter.</li>
              <li>StuntingCare berhak membatalkan appointment apabila dokter tidak tersedia karena kondisi darurat.</li>
              <li>Pengguna wajib memberikan data pasien yang akurat saat melakukan booking.</li>
            </ul>
          </section>
          <section id="s6">
            <div className="section-hd"><span className="section-num">6</span>Hak Kekayaan Intelektual</div>
            <p>Seluruh konten platform StuntingCare — termasuk teks, gambar, logo, desain antarmuka, dan kode — dilindungi oleh hak cipta dan hak kekayaan intelektual lainnya yang dimiliki oleh StuntingCare.</p>
            <ul>
              <li>Pengguna tidak diperkenankan menyalin, mendistribusikan, atau memodifikasi konten tanpa izin tertulis.</li>
              <li>Tautan referensi ke sumber eksternal (WHO, Google Scholar) dimiliki oleh pihak ketiga terkait.</li>
            </ul>
          </section>
          <section id="s7">
            <div className="section-hd"><span className="section-num">7</span>Batasan Tanggung Jawab</div>
            <p>StuntingCare tidak bertanggung jawab atas:</p>
            <ul>
              <li>Kerugian yang timbul dari penggunaan informasi kesehatan di platform tanpa konsultasi dokter langsung.</li>
              <li>Gangguan layanan yang disebabkan oleh force majeure, pemeliharaan sistem, atau gangguan pihak ketiga.</li>
              <li>Keakuratan data yang diinput oleh pengguna ke dalam Stunting Checker.</li>
              <li>Keputusan medis yang diambil berdasarkan hasil estimasi platform semata.</li>
            </ul>
          </section>
          <section id="s8">
            <div className="section-hd"><span className="section-num">8</span>Perubahan &amp; Penghentian Layanan</div>
            <p>StuntingCare berhak mengubah, menangguhkan, atau menghentikan layanan kapan saja dengan pemberitahuan sebelumnya. Perubahan syarat ketentuan akan diumumkan melalui email terdaftar dan halaman ini. Penggunaan layanan setelah pemberitahuan dianggap sebagai persetujuan terhadap perubahan tersebut.</p>
          </section>
          <section id="s9">
            <div className="section-hd"><span className="section-num">9</span>Hukum yang Berlaku</div>
            <p>Syarat &amp; Ketentuan ini diatur oleh hukum Negara Kesatuan Republik Indonesia. Setiap sengketa yang timbul akan diselesaikan melalui musyawarah dan, jika diperlukan, melalui jalur hukum yang berlaku di Indonesia.</p>
          </section>
          <section id="s10">
            <div className="section-hd"><span className="section-num">10</span>Kontak</div>
            <p>Jika ada pertanyaan terkait Syarat &amp; Ketentuan ini, hubungi kami:</p>
            <ul>
              <li>📧 Email: <a href="mailto:layananStuntingcare@gmail.com">layananStuntingcare@gmail.com</a></li>
              <li>📞 Telepon: 081 923 231 331 (Sen–Sab 07.00–21.00 WIB)</li>
              <li>📍 Alamat: Jalan Monas Utama, Jakarta Selatan, Indonesia</li>
            </ul>
          </section>
          <div className="footer">
            <div style={{display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, marginBottom: 12}}>
              <img src="/assets/stuntingcare-logo.png" alt="StuntingCare" style={{height: 38}} />
            </div>
            <p>© 2025 StuntingCare. Semua hak dilindungi. Platform Kesehatan Anak Indonesia.</p>
            <button className="close-btn" onClick={(event) => { window.close(); }}>✕ Tutup Tab Ini</button>
          </div>
        </div>
      </div>

  );
}
