import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import AuthPage from './pages/AuthPage';
import MainPage from './pages/MainPage';
import KebijakanPrivasiPage from './pages/KebijakanPrivasiPage';
import SyaratKetentuanPage from './pages/SyaratKetentuanPage';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<AuthPage />} />
        <Route path="/login" element={<Navigate to="/" replace />} />
        <Route path="/main" element={<MainPage />} />
        <Route path="/app/*" element={<Navigate to="/main" replace />} />
        <Route path="/kebijakan-privasi" element={<KebijakanPrivasiPage />} />
        <Route path="/syarat-ketentuan" element={<SyaratKetentuanPage />} />
      </Routes>
    </BrowserRouter>
  );
}