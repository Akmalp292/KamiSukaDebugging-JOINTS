import { useEffect, useRef, useState } from 'react';
import { askChatbot } from '../lib/chatbotBackend';
import { useMaskot } from '../lib/maskot';
import Maskot from './Maskot';
import MaskotStage from './MaskotStage';
import MaskotStudio from './MaskotStudio';
import '../styles/asisten.css';
import '../styles/maskot.css';

const GREETING = 'Halo, Bunda! Saya asisten StuntingCare. Tanyakan seputar gizi, MPASI, dan tumbuh kembang anak. Untuk keluhan kesehatan, saya bisa menghubungkan Bunda ke dokter.';
const CHIPS = ['Apa itu stunting?', 'Menu MPASI bergizi', 'Anak susah makan', 'Kapan perlu ke dokter?'];
const URGENT = /kejang|sesak napas|sesak nafas|tidak sadar|pingsan|perdarahan|berdarah banyak|tidak bernapas|tidak bernafas|keracunan/i;
const MEDIS = /dokter|demam|batuk|diare|muntah|ruam|obat|berat badan tidak naik|gizi buruk|stunting|sakit|lemas/i;
const MAPS = 'https://www.google.com/maps/search/rumah+sakit+terdekat';

export default function AsistenChat() {
  const cfg = useMaskot();
  const [msgs, setMsgs] = useState([{ role: 'bot', text: GREETING }]);
  const [input, setInput] = useState('');
  const [typing, setTyping] = useState(false);
  const [happy, setHappy] = useState(false);
  const [studio, setStudio] = useState(false);
  const bodyRef = useRef(null);
  const happyTimer = useRef(null);

  useEffect(() => {
    const el = bodyRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [msgs, typing]);

  useEffect(() => () => clearTimeout(happyTimer.current), []);

  const konsul = () => window.dispatchEvent(new Event('sc:konsul'));

  function senang() {
    setHappy(true);
    clearTimeout(happyTimer.current);
    happyTimer.current = setTimeout(() => setHappy(false), 2200);
  }

  async function kirim(teks) {
    const pesan = (teks ?? input).trim();
    if (!pesan || typing) return;

    const riwayat = msgs.filter((m) => m.role !== 'emg').slice(-8);
    const tambah = [{ role: 'user', text: pesan }];
    if (URGENT.test(pesan)) tambah.push({ role: 'emg' });
    setMsgs((m) => [...m, ...tambah]);
    setInput('');
    setTyping(true);

    try {
      const jawaban = await askChatbot(pesan, riwayat);
      setMsgs((m) => [...m, { role: 'bot', text: jawaban, doc: MEDIS.test(pesan + ' ' + jawaban) }]);
      senang();
    } catch (err) {
      console.error('Chatbot error:', err);
      setMsgs((m) => [...m, { role: 'bot', text: 'Maaf, asisten sedang tidak bisa dihubungi. Coba lagi sebentar, atau hubungkan ke dokter.', doc: true }]);
    } finally {
      setTyping(false);
    }
  }

  function onKey(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      kirim();
    }
  }

  const say = typing ? 'Sebentar ya, aku cari jawabannya…' : happy ? 'Semoga membantu, Bunda! 😊' : 'Halo, Bunda! Mau tanya apa hari ini?';

  return (
    <div className="as-wrap">
      <div className="mk-hero">
        <MaskotStage cfg={cfg} view="bust" size={78} pose={typing ? 'think' : happy ? 'wave' : 'idle'} />
        <div className="mk-hero-txt">
          <div className="mk-say">{say}</div>
          <div className="mk-btns">
            <button className="mk-b" onClick={() => setStudio(true)}>
              <span className="material-symbols-rounded">checkroom</span> Ubah Penampilan
            </button>
            <button className="mk-b dark" onClick={konsul}>
              <span className="material-symbols-rounded">forum</span> Ke Dokter
            </button>
          </div>
        </div>
      </div>
      <div className="as-links">
        Sudah pernah konsultasi? <button onClick={() => window.goPage && window.goPage('chat')}>Lihat riwayat chat dokter</button>
      </div>

      <div className="as-body" ref={bodyRef}>
        {msgs.map((m, i) => {
          if (m.role === 'emg') {
            return (
              <div key={i} className="as-emg">
                <b>Tanda bahaya terdeteksi</b>
                Kondisi seperti ini bisa darurat. Jangan menunggu jawaban chat, segera hubungi bantuan medis.
                <div>
                  <a href="tel:119">Telepon 119</a>
                  <a className="alt" href={MAPS} target="_blank" rel="noreferrer">Faskes terdekat</a>
                </div>
              </div>
            );
          }
          if (m.role === 'user') {
            return (
              <div key={i} className="as-msg user">
                <div className="as-bubble">{m.text}</div>
              </div>
            );
          }
          return (
            <div key={i} className="as-row">
              <span className="as-face"><Maskot cfg={cfg} view="face" size={34} animate={false} /></span>
              <div className="as-msg bot">
                <div className="as-bubble">{m.text}</div>
                {m.doc && <button className="as-doc" onClick={konsul}>Konsultasi dengan dokter</button>}
              </div>
            </div>
          );
        })}

        {typing && (
          <div className="as-row">
            <span className="as-face"><Maskot cfg={cfg} view="face" size={34} animate={false} /></span>
            <div className="as-msg bot">
              <div className="as-bubble as-typing"><i /><i /><i /></div>
            </div>
          </div>
        )}

        {msgs.length === 1 && !typing && (
          <div className="as-chips">
            {CHIPS.map((c) => <button key={c} className="as-chip" onClick={() => kirim(c)}>{c}</button>)}
          </div>
        )}
      </div>

      <div className="as-input">
        <textarea rows={1} placeholder="Tulis pertanyaan Bunda…" value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={onKey} />
        <button className="as-send" disabled={!input.trim() || typing} onClick={() => kirim()} aria-label="Kirim">
          <span className="material-symbols-rounded">send</span>
        </button>
      </div>
      <div className="as-foot">Jawaban asisten bukan pengganti pemeriksaan dokter.</div>

      <MaskotStudio open={studio} onClose={() => setStudio(false)} />
    </div>
  );
}