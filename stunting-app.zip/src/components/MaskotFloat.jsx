import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { doc, onSnapshot } from 'firebase/firestore';
import { useAuth } from '../lib/useAuth';
import { db } from '../lib/firebase';
import { useMaskot, applyMaskot, loadMaskot, sanitize } from '../lib/maskot';
import Maskot from './Maskot';
import '../styles/maskot.css';

const W = 72;
const H = Math.round((W * 112) / 88);
const POS_KEY = 'sc_maskot_pos2';
const COL = 420; // lebar bingkai app

// bingkai app: selebar 420px di tengah (atau selebar layar di HP)
function colBox() {
  const vw = window.innerWidth;
  const w = Math.min(COL, vw);
  return { left: (vw - w) / 2, w };
}

// posisi disimpan relatif terhadap bingkai, bukan terhadap layar
function clampRel(p) {
  const { w } = colBox();
  const vh = window.innerHeight;
  return {
    x: Math.min(Math.max(p.x, 4), Math.max(4, w - W - 4)),
    y: Math.min(Math.max(p.y, 56), Math.max(56, vh - H - 70)),
  };
}

function defaultRel() {
  return clampRel({ x: 12, y: window.innerHeight - H - 96 });
}

function loadRel() {
  try {
    const p = JSON.parse(localStorage.getItem(POS_KEY) || 'null');
    if (p && Number.isFinite(p.x) && Number.isFinite(p.y)) return clampRel(p);
  } catch { /* abaikan */ }
  return defaultRel();
}

export default function MaskotFloat() {
  const { user } = useAuth();
  const uid = user?.uid;
  const cfg = useMaskot();
  const [rel, setRel] = useState(loadRel);
  const relRef = useRef(rel);
  const drag = useRef(null);
  const [show, setShow] = useState(false);
  const [hold, setHold] = useState(false);
  const [hi, setHi] = useState(false);

  // sinkron penampilan dari akun
  useEffect(() => {
    if (!uid) return undefined;
    return onSnapshot(
      doc(db, 'patients', uid),
      (s) => {
        const m = s.exists() ? s.data().maskot : null;
        if (!m) return;
        const n = sanitize(m);
        if (JSON.stringify(n) !== JSON.stringify(loadMaskot())) applyMaskot(n);
      },
      () => {}
    );
  }, [uid]);

  // tampil hanya di Beranda + hitung ulang saat jendela berubah ukuran
  useEffect(() => {
    const t = setInterval(() => setShow(document.querySelector('.page.active')?.id === 'page-dash'), 400);
    const onResize = () => {
      const p = clampRel(relRef.current);
      relRef.current = p;
      setRel(p);
    };
    window.addEventListener('resize', onResize);
    return () => { clearInterval(t); window.removeEventListener('resize', onResize); };
  }, []);

  // sapaan sekali per sesi
  useEffect(() => {
    if (!show) return undefined;
    let seen = false;
    try { seen = sessionStorage.getItem('sc_mk_hi') === '1'; } catch { /* abaikan */ }
    if (seen) return undefined;
    try { sessionStorage.setItem('sc_mk_hi', '1'); } catch { /* abaikan */ }
    setHi(true);
    const t = setTimeout(() => setHi(false), 5000);
    return () => { clearTimeout(t); setHi(false); };
  }, [show]);

  function down(e) {
    drag.current = { sx: e.clientX, sy: e.clientY, ox: relRef.current.x, oy: relRef.current.y, moved: false };
    if (e.currentTarget.setPointerCapture) e.currentTarget.setPointerCapture(e.pointerId);
  }

  function move(e) {
    const d = drag.current;
    if (!d) return;
    const dx = e.clientX - d.sx;
    const dy = e.clientY - d.sy;
    if (!d.moved && Math.hypot(dx, dy) > 6) { d.moved = true; setHold(true); }
    if (d.moved) {
      const p = clampRel({ x: d.ox + dx, y: d.oy + dy });
      relRef.current = p;
      setRel(p);
    }
  }

  function up() {
    const d = drag.current;
    drag.current = null;
    if (!d) return;
    setHold(false);
    if (d.moved) {
      try { localStorage.setItem(POS_KEY, JSON.stringify(relRef.current)); } catch { /* abaikan */ }
    } else if (window.goPage) {
      window.goPage('asisten');
    }
  }

  if (!show) return null;
  const { left, w } = colBox();
  const right = rel.x > w / 2;

  return createPortal(
    <div className={'mkf' + (hold ? ' hold' : '')} style={{ left: left + rel.x, top: rel.y }} onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up}>
      {hi && !hold && <div className="mkf-say" style={right ? { right: 0 } : { left: 0 }}>Tanya aku ya, Bunda! 👋</div>}
      <Maskot cfg={cfg} view="bust" size={W} pose={hold ? 'wave' : 'idle'} />
    </div>,
    document.body
  );
}