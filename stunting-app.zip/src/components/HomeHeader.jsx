import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { doc, onSnapshot, setDoc } from 'firebase/firestore';
import { useAuth } from '../lib/useAuth';
import { db } from '../lib/firebase';
import Avatar, { CHARS } from './Avatar';
import MaskotFloat from './MaskotFloat';
import '../styles/home.css';

const MAPS = 'https://www.google.com/maps/search/rumah+sakit+terdekat';
const QUICK = [
  { ic: 'forum', t: 'Konsultasi', g: ['#17806F', '#2BB5A0'], go: () => window.dispatchEvent(new Event('sc:konsul')) },
  { ic: 'smart_toy', t: 'Asisten AI', g: ['#E8872E', '#F4A261'], go: () => window.goPage && window.goPage('asisten') },
  { ic: 'history', t: 'Riwayat', g: ['#7A5BD6', '#A68BF0'], go: () => window.goPage && window.goPage('chat') },
  { ic: 'local_hospital', t: 'Faskes', g: ['#3F7FE0', '#6DB2F5'], go: () => window.open(MAPS, '_blank', 'noopener') },
];

const lsGet = (k) => { try { return localStorage.getItem(k); } catch { return null; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch { /* abaikan */ } };

function sapa() {
  const h = new Date().getHours();
  return h < 11 ? 'Selamat pagi' : h < 15 ? 'Selamat siang' : h < 18 ? 'Selamat sore' : 'Selamat malam';
}

function namaDepan(user) {
  let n = user?.displayName;
  if (!n) {
    try { n = JSON.parse(localStorage.getItem('sc_s') || 'null')?.name; } catch { /* abaikan */ }
  }
  return (n || 'Bunda').split(' ')[0];
}

export default function HomeHeader() {
  const { user } = useAuth();
  const uid = user?.uid;
  const [kind, setKind] = useState(() => lsGet('sc_avatar') || 'bunda');
  const [pick, setPick] = useState(false);

  useEffect(() => {
    if (!uid) return undefined;
    return onSnapshot(
      doc(db, 'patients', uid),
      (s) => {
        const a = s.exists() ? s.data().avatar : null;
        if (a) { setKind(a); lsSet('sc_avatar', a); }
      },
      () => {}
    );
  }, [uid]);

  async function pilih(id) {
    setKind(id);
    lsSet('sc_avatar', id);
    setPick(false);
    try {
      if (uid) await setDoc(doc(db, 'patients', uid), { avatar: id }, { merge: true });
    } catch (e) {
      console.error('[avatar] gagal menyimpan', e);
    }
  }

  return (
    <>
      <div className="hm-top">
        <button className="hm-ava" onClick={() => setPick(true)} aria-label="Ganti karakter">
          <Avatar kind={kind} size={56} />
          <span className="material-symbols-rounded hm-edit">edit</span>
        </button>
        <div className="hm-hi">
          <small>{sapa()} 👋</small>
          <b>{namaDepan(user)}</b>
        </div>
      </div>

      <div className="hm-hero">
        <i className="hm-blob b1" />
        <i className="hm-blob b2" />
        <i className="hm-spark s1" />
        <i className="hm-spark s2" />
        <i className="hm-spark s3" />
        <div className="hm-hero-txt">
          <span className="hm-pill">StuntingCare</span>
          <h2>Yuk, pantau tumbuh kembang si kecil</h2>
          <p>Catat ukuran, tanya asisten, dan konsultasi dengan dokter kapan saja.</p>
          <button className="hm-cta" onClick={() => window.dispatchEvent(new Event('sc:konsul'))}>
            <span className="material-symbols-rounded">forum</span> Konsultasi Online
          </button>
        </div>
        <div className="hm-mascot">
          <div className="hm-bubble">Halo, Bunda! 👋</div>
          <Avatar kind={kind} size={104} />
        </div>
      </div>

      <div className="hm-quick">
        {QUICK.map((q) => (
          <button key={q.t} className="hm-q" onClick={q.go}>
            <span className="hm-q-ic" style={{ background: `linear-gradient(135deg, ${q.g[0]}, ${q.g[1]})` }}>
              <span className="material-symbols-rounded">{q.ic}</span>
            </span>
            {q.t}
          </button>
        ))}
      </div>

      <MaskotFloat />

      {pick && createPortal(
        <div className="hm-sh-bg" onClick={() => setPick(false)}>
          <div className="hm-sh" onClick={(e) => e.stopPropagation()}>
            <div className="hm-grip" />
            <h3>Pilih Karakter</h3>
            <p>Karakter ini tampil sebagai profil Bunda di Beranda.</p>
            <div className="hm-grid">
              {CHARS.map((c) => (
                <button key={c.id} className={'hm-opt' + (c.id === kind ? ' sel' : '')} onClick={() => pilih(c.id)}>
                  <Avatar kind={c.id} size={64} />
                  {c.nama}
                </button>
              ))}
            </div>
          </div>
        </div>,
        document.body
      )}
    </>
  );
}