import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { Link, useNavigate } from 'react-router-dom';
import {
  EmailAuthProvider, GoogleAuthProvider, deleteUser, reauthenticateWithCredential,
  reauthenticateWithPopup, sendPasswordResetEmail, signOut, updateProfile,
} from 'firebase/auth';
import {
  collection, deleteDoc, deleteField, doc, getDocs, onSnapshot, orderBy, query, setDoc, where,
} from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { useAuth } from '../lib/useAuth';
import { saveChild } from '../lib/records';
import { ageMonths, status } from '../lib/growth';
import { hitungKehamilan, validHpht, fmtUtc } from '../lib/kehamilan';
import { JENIS } from '../lib/sos';
import { downloadSummaryPdf } from '../lib/summaryPdf';
import { downloadGrowthPdf } from '../lib/akunPdf';
import Avatar, { CHARS } from './Avatar';
import MaskotStudio from './MaskotStudio';
import '../styles/akun.css';

const COLOR = { hijau: '#2E9E5B', kuning: '#F2B705', merah: '#DC143C' };
const TIDAK_ADA = /^tidak disebutkan/i;
const KONTAK = 'layananStuntingcare@gmail.com'; // ganti dengan email resmi StuntingCare

const lsGet = (k) => { try { return localStorage.getItem(k); } catch { return null; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch { /* abaikan */ } };

function todayLocal() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}
const fmt = (d) => (d ? d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' }) : '-');
const fmtStr = (s) => (s ? fmt(new Date(s)) : '-');
const tsDate = (t) => (t && t.toDate ? t.toDate() : null);
const umur = (m) => (m >= 12 ? `${Math.floor(m / 12)} th ${m % 12} bln` : `${m} bln`);

function Chart({ label, unit, color, vals }) {
  if (!vals.length) return null;
  const W = 300, H = 84, P = 10;
  let min = Math.min(...vals), max = Math.max(...vals);
  if (min === max) { min -= 1; max += 1; }
  const sx = (i) => (vals.length === 1 ? W / 2 : P + ((W - 2 * P) * i) / (vals.length - 1));
  const sy = (v) => H - P - ((H - 2 * P) * (v - min)) / (max - min);
  const d = vals.map((v, i) => `${i ? 'L' : 'M'}${sx(i).toFixed(1)} ${sy(v).toFixed(1)}`).join(' ');
  return (
    <div className="ak-chart">
      <div className="ak-chart-h"><b>{label}</b><span>{vals[vals.length - 1]} {unit}</span></div>
      <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label={label}>
        <rect x="0" y="0" width={W} height={H} rx="10" fill="#F7FAFA" />
        {vals.length > 1 && <path d={d} fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />}
        {vals.map((v, i) => <circle key={i} cx={sx(i)} cy={sy(v)} r="3.6" fill={color} />)}
      </svg>
    </div>
  );
}

export default function AkunPage() {
  const nav = useNavigate();
  const { user } = useAuth();
  const uid = user?.uid;

  const [tab, setTab] = useState('profil');
  const [sub, setSub] = useState('tumbuh');
  const [child, setChild] = useState(null);
  const [preg, setPreg] = useState(null);
  const [avatar, setAvatar] = useState(() => lsGet('sc_avatar') || 'bunda');
  const [recs, setRecs] = useState([]);
  const [konsul, setKonsul] = useState([]);
  const [sums, setSums] = useState([]);
  const [kej, setKej] = useState([]);
  const [open, setOpen] = useState('');

  const [editAnak, setEditAnak] = useState(false);
  const [fa, setFa] = useState({ name: '', dob: '', gender: '' });
  const [editPreg, setEditPreg] = useState(false);
  const [hpht, setHpht] = useState('');
  const [editNama, setEditNama] = useState(false);
  const [nama, setNama] = useState('');
  const [msg, setMsg] = useState({ ok: '', err: '' });
  const [busy, setBusy] = useState(false);
  const [studio, setStudio] = useState(false);
  const [del, setDel] = useState(false);
  const [delTxt, setDelTxt] = useState('');
  const [delPass, setDelPass] = useState('');
  const [delErr, setDelErr] = useState('');

  const isPassword = !!user?.providerData?.some((p) => p.providerId === 'password');
  const namaAkun = user?.displayName || (user?.email || 'Pengguna').split('@')[0];

  useEffect(() => {
    if (!uid) return undefined;
    const off = [];
    off.push(onSnapshot(doc(db, 'patients', uid), (s) => {
      const d = s.exists() ? s.data() : {};
      setChild(d.child || null);
      setPreg(d.pregnancy || null);
      if (d.avatar) { setAvatar(d.avatar); lsSet('sc_avatar', d.avatar); }
    }, () => {}));
    off.push(onSnapshot(query(collection(db, 'patients', uid, 'records'), orderBy('date', 'asc')),
      (s) => setRecs(s.docs.map((x) => ({ id: x.id, ...x.data() }))), () => {}));
    off.push(onSnapshot(query(collection(db, 'patients', uid, 'summaries'), orderBy('createdAt', 'desc')),
      (s) => setSums(s.docs.map((x) => ({ id: x.id, ...x.data() }))), () => {}));
    off.push(onSnapshot(query(collection(db, 'consultations'), where('patientId', '==', uid)),
      (s) => setKonsul(s.docs.map((x) => ({ id: x.id, ...x.data() }))
        .sort((a, b) => (tsDate(b.updatedAt)?.getTime() || 0) - (tsDate(a.updatedAt)?.getTime() || 0))), () => {}));
    off.push(onSnapshot(query(collection(db, 'emergencyEvents'), where('patientId', '==', uid)),
      (s) => setKej(s.docs.map((x) => ({ id: x.id, ...x.data() }))
        .sort((a, b) => (tsDate(b.createdAt)?.getTime() || 0) - (tsDate(a.createdAt)?.getTime() || 0))), () => {}));
    return () => off.forEach((f) => f());
  }, [uid]);

  function flash(ok, err) {
    setMsg({ ok, err });
    setTimeout(() => setMsg({ ok: '', err: '' }), 4000);
  }

  /* ── Data anak ── */
  function mulaiAnak() {
    setFa({ name: child?.name || '', dob: child?.dob || '', gender: child?.gender || '' });
    setEditAnak(true);
  }

  async function simpanAnak() {
    const name = fa.name.trim();
    if (!name || !fa.dob || !fa.gender) return flash('', 'Lengkapi semua kolom data anak.');
    if (ageMonths(fa.dob) > 60) return flash('', 'Usia anak lebih dari 5 tahun. Pelacak untuk usia 0–5 tahun, cek tanggal lahir.');
    setBusy(true);
    try {
      await saveChild(uid, { name, dob: fa.dob, gender: fa.gender });
      setEditAnak(false);
      flash('Data anak disimpan.', '');
    } catch (e) {
      console.error('[akun] simpan anak', e);
      flash('', 'Gagal menyimpan. Coba lagi.');
    } finally { setBusy(false); }
  }

  /* ── Kehamilan ── */
  async function simpanPreg() {
    const err = validHpht(hpht);
    if (err) return flash('', err);
    setBusy(true);
    try {
      await setDoc(doc(db, 'patients', uid), { pregnancy: { hpht } }, { merge: true });
      setEditPreg(false);
      flash('Data kehamilan disimpan.', '');
    } catch (e) {
      console.error('[akun] simpan kehamilan', e);
      flash('', 'Gagal menyimpan. Coba lagi.');
    } finally { setBusy(false); }
  }

  async function hapusPreg() {
    if (!window.confirm('Hapus data kehamilan?')) return;
    try {
      await setDoc(doc(db, 'patients', uid), { pregnancy: deleteField() }, { merge: true });
      flash('Data kehamilan dihapus.', '');
    } catch (e) {
      console.error('[akun] hapus kehamilan', e);
      flash('', 'Gagal menghapus. Coba lagi.');
    }
  }

  /* ── Karakter ── */
  async function pilihAvatar(id) {
    setAvatar(id);
    lsSet('sc_avatar', id);
    try { await setDoc(doc(db, 'patients', uid), { avatar: id }, { merge: true }); } catch (e) { console.error('[akun] avatar', e); }
  }

  /* ── Nama akun ── */
  async function simpanNama() {
    const n = nama.trim();
    if (n.length < 2) return flash('', 'Nama minimal 2 huruf.');
    setBusy(true);
    try {
      await updateProfile(auth.currentUser, { displayName: n });
      try {
        const s = JSON.parse(localStorage.getItem('sc_s') || 'null');
        if (s) { s.name = n; s.ava = (n[0] || 'U').toUpperCase(); localStorage.setItem('sc_s', JSON.stringify(s)); }
      } catch { /* abaikan */ }
      if (window.syncUI) window.syncUI();
      setEditNama(false);
      flash('Nama diperbarui. Muat ulang halaman untuk melihatnya di semua tempat.', '');
    } catch (e) {
      console.error('[akun] nama', e);
      flash('', 'Gagal menyimpan nama. Coba lagi.');
    } finally { setBusy(false); }
  }

  /* ── Riwayat ── */
  function bukaKonsul(id) {
    if (window.goPage) window.goPage('chat');
    setTimeout(() => { if (window.openPatientConsultation) window.openPatientConsultation(id); }, 400);
  }

  async function hapusRingkasan(id) {
    if (!window.confirm('Hapus ringkasan ini?')) return;
    try { await deleteDoc(doc(db, 'patients', uid, 'summaries', id)); } catch (e) { console.error('[akun] hapus ringkasan', e); flash('', 'Gagal menghapus ringkasan.'); }
  }

  function unduhPdfRingkasan(s) {
    downloadSummaryPdf({
      doctorName: s.doctorName || '-',
      tanggal: fmt(tsDate(s.createdAt) || new Date()),
      poin: { diagnosa: s.diagnosa, resep: s.resep, pantangan: s.pantangan },
    });
  }

  /* ── Pengaturan ── */
  async function resetSandi() {
    if (!user?.email) return;
    try {
      await sendPasswordResetEmail(auth, user.email);
      flash(`Tautan ganti kata sandi dikirim ke ${user.email}. Cek folder Spam.`, '');
    } catch (e) {
      console.error('[akun] reset sandi', e);
      flash('', 'Gagal mengirim email. Coba lagi.');
    }
  }

  function unduhData() {
    const iso = (t) => (tsDate(t) ? tsDate(t).toISOString() : null);
    const data = {
      diunduh: new Date().toISOString(),
      akun: { nama: namaAkun, email: user?.email || '' },
      anak: child,
      kehamilan: preg,
      pertumbuhan: recs.map(({ id, ...r }) => ({ ...r, createdAt: iso(r.createdAt) })),
      ringkasanKonsultasi: sums.map(({ id, ...r }) => ({ ...r, createdAt: iso(r.createdAt) })),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'data-stuntingcare.json';
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }

  function unduhPertumbuhan() {
    downloadGrowthPdf({ child, recs, tanggal: fmt(new Date()) });
  }

  async function keluar() {
    try { await signOut(auth); } catch { /* abaikan */ }
    try { localStorage.removeItem('sc_s'); } catch { /* abaikan */ }
    nav('/', { replace: true });
  }

  async function hapusAkun() {
    setDelErr('');
    if (delTxt.trim().toUpperCase() !== 'HAPUS') return setDelErr('Ketik HAPUS untuk melanjutkan.');
    const u = auth.currentUser;
    if (!u) return setDelErr('Sesi berakhir. Masuk lagi lalu ulangi.');
    setBusy(true);
    try {
      // 1) verifikasi ulang identitas (wajib oleh Firebase untuk menghapus akun)
      if (isPassword) {
        if (!delPass) { setBusy(false); return setDelErr('Masukkan kata sandi Anda.'); }
        await reauthenticateWithCredential(u, EmailAuthProvider.credential(u.email, delPass));
      } else {
        await reauthenticateWithPopup(u, new GoogleAuthProvider());
      }
      // 2) hapus data pribadi
      for (const sc of ['records', 'summaries']) {
        const snap = await getDocs(collection(db, 'patients', uid, sc));
        await Promise.all(snap.docs.map((d) => deleteDoc(d.ref)));
      }
      await deleteDoc(doc(db, 'patients', uid));
      // 3) hapus akun
      await deleteUser(u);
      ['sc_s', 'sc_avatar', 'sc_maskot', 'sc_maskot_pos2'].forEach((k) => { try { localStorage.removeItem(k); } catch { /* abaikan */ } });
      nav('/', { replace: true });
    } catch (e) {
      console.error('[akun] hapus akun', e);
      const c = e && e.code;
      setDelErr(
        c === 'auth/wrong-password' || c === 'auth/invalid-credential' ? 'Kata sandi salah.'
        : c === 'auth/too-many-requests' ? 'Terlalu banyak percobaan. Coba lagi nanti.'
        : c === 'auth/popup-closed-by-user' || c === 'auth/cancelled-popup-request' ? 'Verifikasi dibatalkan.'
        : 'Gagal menghapus akun. Keluar, masuk lagi, lalu coba kembali.'
      );
    } finally { setBusy(false); }
  }

  const k = preg?.hpht ? hitungKehamilan(preg.hpht) : null;
  const bulanAnak = child ? ageMonths(child.dob) : null;
  const rec12 = recs.slice(-12);

  return (
    <div className="ak">
      {/* ═══ Hero ═══ */}
      <div className="ak-hero">
        <i className="ak-blob b1" />
        <i className="ak-blob b2" />
        <div className="ak-ava"><Avatar kind={avatar} size={92} /></div>
        <div className="ak-name">{namaAkun}</div>
        <div className="ak-mail">{user?.email || ''}</div>
        {child && <span className="ak-chip">Anak: {child.name} · {umur(bulanAnak)}</span>}
      </div>

      <div className="ak-stats">
        <div className="ak-stat"><b>{recs.length}</b><small>Catatan ukur</small></div>
        <div className="ak-stat"><b>{konsul.length}</b><small>Konsultasi</small></div>
        <div className="ak-stat"><b>{sums.length}</b><small>Ringkasan</small></div>
      </div>

      <div className="ak-tabs">
        {[['profil', 'Profil'], ['riwayat', 'Riwayat'], ['atur', 'Pengaturan']].map(([id, l]) => (
          <button key={id} className={'ak-tab' + (tab === id ? ' on' : '')} onClick={() => setTab(id)}>{l}</button>
        ))}
      </div>

      {msg.ok && <div className="ak-msg ok">{msg.ok}</div>}
      {msg.err && <div className="ak-msg err">{msg.err}</div>}

      {/* ═══════════ PROFIL ═══════════ */}
      {tab === 'profil' && (
        <>
          <div className="ak-card">
            <div className="ak-ch"><b>Data Anak</b>{child && !editAnak && <button className="ak-link" onClick={mulaiAnak}>Ubah</button>}</div>
            {!editAnak && child && (
              <>
                <div className="ak-kv"><span>Nama</span><span>{child.name}</span></div>
                <div className="ak-kv"><span>Tanggal lahir</span><span>{fmtStr(child.dob)}</span></div>
                <div className="ak-kv"><span>Jenis kelamin</span><span>{child.gender === 'L' ? 'Laki-laki' : 'Perempuan'}</span></div>
                <div className="ak-kv"><span>Usia</span><span>{umur(bulanAnak)}</span></div>
              </>
            )}
            {!editAnak && !child && (
              <>
                <div className="ak-mute">Belum ada data anak. Isi untuk mulai memantau pertumbuhan.</div>
                <button className="ak-btn" onClick={mulaiAnak}>Isi Data Anak</button>
              </>
            )}
            {editAnak && (
              <>
                <label className="ak-lb">Nama anak</label>
                <input className="ak-in" value={fa.name} onChange={(e) => setFa({ ...fa, name: e.target.value })} />
                <label className="ak-lb">Tanggal lahir</label>
                <input className="ak-in" type="date" max={todayLocal()} value={fa.dob} onChange={(e) => setFa({ ...fa, dob: e.target.value })} />
                <label className="ak-lb">Jenis kelamin</label>
                <select className="ak-in" value={fa.gender} onChange={(e) => setFa({ ...fa, gender: e.target.value })}>
                  <option value="">Pilih…</option>
                  <option value="L">Laki-laki</option>
                  <option value="P">Perempuan</option>
                </select>
                {recs.length > 0 && <div className="ak-mute">Catatan lama tidak dihitung ulang. Jika tanggal lahir berubah banyak, riwayat lama bisa menyesatkan.</div>}
                <div className="ak-row">
                  <button className="ak-btn gray" onClick={() => setEditAnak(false)}>Batal</button>
                  <button className="ak-btn" disabled={busy} onClick={simpanAnak}>{busy ? 'Menyimpan…' : 'Simpan'}</button>
                </div>
              </>
            )}
          </div>

          <div className="ak-card ak-preg">
            <div className="ak-ch">
              <b>Kehamilan</b>
              {k && !editPreg && <button className="ak-link" onClick={() => { setHpht(preg.hpht); setEditPreg(true); }}>Ubah</button>}
            </div>
            {!k && !editPreg && (
              <>
                <div className="ak-mute">Sedang hamil? Isi HPHT untuk melihat usia kehamilan dan perkiraan lahir. Opsional.</div>
                <button className="ak-btn soft" onClick={() => { setHpht(''); setEditPreg(true); }}>Isi Data Kehamilan</button>
              </>
            )}
            {k && !editPreg && (
              <>
                <div className="ak-pw">{k.minggu} <small>minggu</small> {k.hari} <small>hari</small></div>
                <div className="ak-bar"><i style={{ width: k.pct + '%' }} /></div>
                <div className="ak-kv"><span>Trimester</span><span>{k.trimester}</span></div>
                <div className="ak-kv"><span>Perkiraan lahir (HPL)</span><span>{fmtUtc(k.hplMs)}</span></div>
                <div className="ak-kv"><span>Sisa</span><span>{k.sisa > 0 ? `± ${k.sisa} hari` : 'Sudah melewati HPL'}</span></div>
                {k.sisa < 0 && <div className="ak-warn">Kehamilan sudah melewati perkiraan lahir. Segera hubungi bidan atau dokter.</div>}
                <div className="ak-mute" style={{ marginTop: 8 }}>
                  Perhitungan perkiraan dari HPHT + 280 hari, USG dapat menggeser HPL. Periksa kehamilan rutin ke bidan atau dokter sesuai jadwal di buku KIA.
                </div>
                <button className="ak-link red" onClick={hapusPreg}>Hapus data kehamilan</button>
              </>
            )}
            {editPreg && (
              <>
                <label className="ak-lb">HPHT (hari pertama haid terakhir)</label>
                <input className="ak-in" type="date" max={todayLocal()} value={hpht} onChange={(e) => setHpht(e.target.value)} />
                <div className="ak-row">
                  <button className="ak-btn gray" onClick={() => setEditPreg(false)}>Batal</button>
                  <button className="ak-btn" disabled={busy} onClick={simpanPreg}>{busy ? 'Menyimpan…' : 'Simpan'}</button>
                </div>
              </>
            )}
          </div>

          <div className="ak-card">
            <div className="ak-ch"><b>Karakter Profil</b></div>
            <div className="ak-chars">
              {CHARS.map((c) => (
                <button key={c.id} className={'ak-ch1' + (c.id === avatar ? ' sel' : '')} onClick={() => pilihAvatar(c.id)}>
                  <Avatar kind={c.id} size={52} animate={false} />
                  {c.nama}
                </button>
              ))}
            </div>
            <button className="ak-btn soft" onClick={() => setStudio(true)}>Ubah Penampilan Maskot Asisten</button>
          </div>

          <div className="ak-card">
            <div className="ak-ch"><b>Akun</b>{!editNama && <button className="ak-link" onClick={() => { setNama(namaAkun); setEditNama(true); }}>Ubah nama</button>}</div>
            {!editNama && (
              <>
                <div className="ak-kv"><span>Nama</span><span>{namaAkun}</span></div>
                <div className="ak-kv"><span>Email</span><span>{user?.email || '-'}</span></div>
                <div className="ak-kv"><span>Masuk dengan</span><span>{isPassword ? 'Email & kata sandi' : 'Google'}</span></div>
              </>
            )}
            {editNama && (
              <>
                <input className="ak-in" value={nama} onChange={(e) => setNama(e.target.value)} />
                <div className="ak-row">
                  <button className="ak-btn gray" onClick={() => setEditNama(false)}>Batal</button>
                  <button className="ak-btn" disabled={busy} onClick={simpanNama}>Simpan</button>
                </div>
              </>
            )}
          </div>
        </>
      )}

      {/* ═══════════ RIWAYAT ═══════════ */}
      {tab === 'riwayat' && (
        <>
          <div className="ak-subs">
            {[['tumbuh', 'Pertumbuhan'], ['konsul', 'Konsultasi'], ['ringkas', 'Ringkasan'], ['darurat', 'Darurat']].map(([id, l]) => (
              <button key={id} className={'ak-sub' + (sub === id ? ' on' : '')} onClick={() => setSub(id)}>{l}</button>
            ))}
          </div>

          {sub === 'tumbuh' && (
            <div className="ak-card">
              <div className="ak-ch"><b>Perkembangan Tumbuh Kembang</b></div>
              {recs.length === 0 && <div className="ak-empty">Belum ada catatan ukur. Catat berat dan tinggi badan di Beranda.</div>}
              {recs.length > 0 && (
                <>
                  <Chart label="Berat badan" unit="kg" color="#17806F" vals={rec12.map((r) => r.weight)} />
                  <Chart label="Tinggi badan" unit="cm" color="#E8872E" vals={rec12.map((r) => r.height)} />
                  {[...recs].reverse().map((r) => {
                    const st = status([r]);
                    return (
                      <div className="ak-li" key={r.id}>
                        <i style={{ background: st ? COLOR[st.key] : '#CBD9DB' }} />
                        <div className="ak-grow">
                          <b>{fmtStr(r.date)} · {r.ageM} bln</b>
                          <small>{r.weight} kg · {r.height} cm · TB/U {r.haz} · BB/U {r.waz}</small>
                        </div>
                        <small>{st ? st.label : ''}</small>
                      </div>
                    );
                  })}
                  <button className="ak-btn soft" onClick={unduhPertumbuhan}>Unduh riwayat (PDF)</button>
                  <div className="ak-mute" style={{ marginTop: 6 }}>Skrining awal berdasarkan standar WHO, bukan diagnosis.</div>
                </>
              )}
            </div>
          )}

          {sub === 'konsul' && (
            <div className="ak-card">
              <div className="ak-ch"><b>Riwayat Konsultasi</b></div>
              {konsul.length === 0 && <div className="ak-empty">Belum ada konsultasi. Mulai dari tombol Konsultasi Online di Beranda.</div>}
              {konsul.map((c) => (
                <button className="ak-clk ak-li" key={c.id} onClick={() => bukaKonsul(c.id)}>
                  <span className="ak-ic"><span className="material-symbols-rounded">medical_services</span></span>
                  <span className="ak-grow">
                    <b>{c.doctorName || 'Dokter'}</b>
                    <small>{fmt(tsDate(c.updatedAt) || tsDate(c.createdAt))} · {c.status === 'selesai' ? 'Selesai' : 'Aktif'} · {c.lastMessage || 'Belum ada pesan'}</small>
                  </span>
                  <span className="material-symbols-rounded" style={{ color: '#9DB3B6' }}>chevron_right</span>
                </button>
              ))}
            </div>
          )}

          {sub === 'ringkas' && (
            <div className="ak-card">
              <div className="ak-ch"><b>Ringkasan dari Dokter</b></div>
              {sums.length === 0 && <div className="ak-empty">Belum ada ringkasan. Ringkasan dibuat dari tombol Ringkas Percakapan di chat dokter.</div>}
              {sums.map((s) => (
                <div className="ak-sum" key={s.id}>
                  <button className="ak-sum-h" onClick={() => setOpen(open === s.id ? '' : s.id)}>
                    <span className="ak-ic"><span className="material-symbols-rounded">auto_awesome</span></span>
                    <span className="ak-grow" style={{ flex: 1, minWidth: 0 }}>
                      <b style={{ display: 'block', fontSize: '.86rem' }}>{s.doctorName || 'Dokter'}</b>
                      <small style={{ color: '#5B7075', fontSize: '.72rem' }}>{fmt(tsDate(s.createdAt))}</small>
                    </span>
                    <span className="material-symbols-rounded" style={{ color: '#5B7075' }}>{open === s.id ? 'expand_less' : 'expand_more'}</span>
                  </button>
                  {open === s.id && (
                    <div className="ak-sum-b">
                      {[['Diagnosa / Saran Dokter', s.diagnosa], ['Resep Obat', s.resep], ['Pantangan Makanan', s.pantangan]].map(([t, v]) => (
                        <div className="ak-pt" key={t}>
                          <b>{t}</b>
                          <div style={TIDAK_ADA.test(v || '') ? { color: '#7A8E91', fontStyle: 'italic' } : undefined}>{v || 'Tidak disebutkan dokter.'}</div>
                        </div>
                      ))}
                      <div className="ak-row">
                        <button className="ak-btn soft" onClick={() => unduhPdfRingkasan(s)}>Unduh PDF</button>
                        <button className="ak-btn line" onClick={() => hapusRingkasan(s.id)}>Hapus</button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {sub === 'darurat' && (
            <div className="ak-card">
              <div className="ak-ch"><b>Riwayat SOS</b></div>
              {kej.length === 0 && <div className="ak-empty">Belum ada riwayat SOS.</div>}
              {kej.map((e) => {
                const j = JENIS.find((x) => x.id === e.kejadian);
                return (
                  <div className="ak-li" key={e.id}>
                    <span className="ak-ic red"><span className="material-symbols-rounded">{j ? j.icon : 'emergency'}</span></span>
                    <span className="ak-grow">
                      <b>{j ? j.t : 'Darurat'}{e.mode === 'demo' ? ' (simulasi)' : ''}</b>
                      <small>{fmt(tsDate(e.createdAt))} · {e.kecamatan ? String(e.kecamatan).split(',')[0] : '-'} → {e.faskesNama || '-'}</small>
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {/* ═══════════ PENGATURAN ═══════════ */}
      {tab === 'atur' && (
        <>
          <div className="ak-card">
            <div className="ak-ch"><b>Keamanan</b></div>
            {isPassword ? (
              <button className="ak-set" onClick={resetSandi}>
                <span className="material-symbols-rounded">lock_reset</span>
                <span>Ganti kata sandi<small>Tautan dikirim ke email Anda</small></span>
                <span className="material-symbols-rounded">chevron_right</span>
              </button>
            ) : (
              <div className="ak-mute">Akun ini masuk dengan Google, jadi kata sandi dikelola oleh akun Google Anda.</div>
            )}
          </div>

          <div className="ak-card">
            <div className="ak-ch"><b>Data &amp; Privasi</b></div>
            <button className="ak-set" onClick={unduhData}>
              <span className="material-symbols-rounded">download</span>
              <span>Unduh data saya<small>Data anak, pertumbuhan, dan ringkasan (JSON)</small></span>
              <span className="material-symbols-rounded">chevron_right</span>
            </button>
            <Link className="ak-set" to="/kebijakan-privasi" target="_blank">
              <span className="material-symbols-rounded">shield</span><span>Kebijakan Privasi</span>
              <span className="material-symbols-rounded">chevron_right</span>
            </Link>
            <Link className="ak-set" to="/syarat-ketentuan" target="_blank">
              <span className="material-symbols-rounded">description</span><span>Syarat &amp; Ketentuan</span>
              <span className="material-symbols-rounded">chevron_right</span>
            </Link>
          </div>

          <div className="ak-card">
            <div className="ak-ch"><b>Bantuan</b></div>
            <a className="ak-set" href={`mailto:${KONTAK}`}>
              <span className="material-symbols-rounded">mail</span>
              <span>Hubungi kami<small>{KONTAK}</small></span>
              <span className="material-symbols-rounded">chevron_right</span>
            </a>
            <a className="ak-set" href="tel:119">
              <span className="material-symbols-rounded">call</span>
              <span>Darurat: 119<small>Ambulans dan layanan gawat darurat</small></span>
              <span className="material-symbols-rounded">chevron_right</span>
            </a>
          </div>

          <div className="ak-card">
            <div className="ak-ch"><b>Tentang</b></div>
            <div className="ak-kv"><span>Versi</span><span>1.0 (prototype)</span></div>
            <div className="ak-mute" style={{ marginTop: 6 }}>
              StuntingCare membantu memantau tumbuh kembang anak. Hasil pelacak dan jawaban asisten AI bukan pengganti pemeriksaan tenaga medis.
            </div>
          </div>

          <div className="ak-card">
            <button className="ak-btn gray" style={{ marginTop: 0 }} onClick={keluar}>Keluar dari Akun</button>
          </div>

          <div className="ak-card ak-danger">
            <div className="ak-ch"><b>Hapus Akun</b></div>
            <div className="ak-mute">Menghapus akun beserta data anak, catatan ukur, dan ringkasan secara permanen.</div>
            <button className="ak-btn line" onClick={() => { setDel(true); setDelTxt(''); setDelPass(''); setDelErr(''); }}>Hapus Akun Saya</button>
          </div>
        </>
      )}

      <MaskotStudio open={studio} onClose={() => setStudio(false)} />

      {del && createPortal(
        <div className="ak-sh-bg" onClick={() => !busy && setDel(false)}>
          <div className="ak-sh" onClick={(e) => e.stopPropagation()}>
            <h3>Hapus akun?</h3>
            <div className="ak-mute">Tindakan ini tidak bisa dibatalkan.</div>
            <ul>
              <li>Dihapus: akun, data anak dan kehamilan, catatan ukur, ringkasan konsultasi.</li>
              <li>Tidak ikut terhapus: riwayat chat dengan dokter dan catatan SOS, karena disimpan sebagai catatan layanan. Untuk menghapusnya, hubungi {KONTAK}.</li>
            </ul>
            <label className="ak-lb">Ketik HAPUS untuk konfirmasi</label>
            <input className="ak-in" value={delTxt} onChange={(e) => setDelTxt(e.target.value)} />
            {isPassword ? (
              <>
                <label className="ak-lb">Kata sandi</label>
                <input className="ak-in" type="password" autoComplete="current-password" value={delPass} onChange={(e) => setDelPass(e.target.value)} />
              </>
            ) : (
              <div className="ak-mute">Anda akan diminta masuk dengan Google sekali lagi untuk verifikasi.</div>
            )}
            {delErr && <div className="ak-msg err" style={{ margin: '8px 0 0' }}>{delErr}</div>}
            <div className="ak-row">
              <button className="ak-btn gray" disabled={busy} onClick={() => setDel(false)}>Batal</button>
              <button className="ak-btn red" disabled={busy} onClick={hapusAkun}>{busy ? 'Menghapus…' : 'Hapus Permanen'}</button>
            </div>
          </div>
        </div>,
        document.body
      )}
    </div>
  );
}