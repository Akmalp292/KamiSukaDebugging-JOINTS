import { useId } from 'react';
import '../styles/anim.css';

export const CHARS = [
  { id: 'bunda', nama: 'Bunda' },
  { id: 'hijab', nama: 'Bunda Hijab' },
  { id: 'bumil', nama: 'Bumil' },
  { id: 'bayi', nama: 'Bayi' },
  { id: 'balita', nama: 'Balita Perempuan' },
  { id: 'balitaL', nama: 'Balita Laki-laki' },
];

const BG = {
  bunda: ['#CFF3EC', '#8EDCCB'],
  hijab: ['#FFE9D2', '#FFC48F'],
  bumil: ['#FFE1EA', '#FFB3CB'],
  bayi: ['#FFF6CC', '#FFE07A'],
  balita: ['#E4DBFF', '#B9A6F4'],
  balitaL: ['#D5ECFF', '#8EC8F5'],
};
const NECK = '#E9A883';
const url = (u, n) => `url(#${u}${n})`;

function Defs({ u, bg }) {
  const rg = (id, a, b) => (
    <radialGradient id={u + id} cx="0.35" cy="0.3" r="0.9">
      <stop offset="0" stopColor={a} />
      <stop offset="1" stopColor={b} />
    </radialGradient>
  );
  return (
    <defs>
      <linearGradient id={u + 'bg'} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor={bg[0]} />
        <stop offset="1" stopColor={bg[1]} />
      </linearGradient>
      {rg('skin', '#FFE3CF', '#F0B08C')}
      {rg('hair', '#7A5545', '#3B261E')}
      {rg('teal', '#7FE0CF', '#17806F')}
      {rg('apr', '#FFCB9A', '#EE9A52')}
      {rg('yel', '#FFF0A8', '#F2C94C')}
      {rg('lav', '#E3D9FF', '#9B82EA')}
      <clipPath id={u + 'cp'}>
        <circle cx="60" cy="60" r="60" />
      </clipPath>
    </defs>
  );
}

function Face({ u, cx = 60, cy = 56, rx = 24, ry = 26, ex = 9, er = 3.3, ears = false }) {
  const ey = cy + 2;
  const skin = url(u, 'skin');
  return (
    <g>
      {ears && (
        <>
          <circle cx={cx - rx + 1} cy={cy + 4} r="6" fill={skin} />
          <circle cx={cx + rx - 1} cy={cy + 4} r="6" fill={skin} />
        </>
      )}
      <ellipse cx={cx} cy={cy} rx={rx} ry={ry} fill={skin} />
      <ellipse cx={cx - rx * 0.4} cy={cy - ry * 0.45} rx={rx * 0.28} ry={ry * 0.14} fill="#fff" opacity="0.28" />
      <g className="av-eyes">
        <ellipse cx={cx - ex} cy={ey} rx={er} ry={er * 1.15} fill="#2B1B17" />
        <ellipse cx={cx + ex} cy={ey} rx={er} ry={er * 1.15} fill="#2B1B17" />
        <circle cx={cx - ex + 1} cy={ey - 1.3} r="1.1" fill="#fff" />
        <circle cx={cx + ex + 1} cy={ey - 1.3} r="1.1" fill="#fff" />
      </g>
      <ellipse cx={cx - ex - 5} cy={ey + 8} rx="5" ry="3" fill="#FF8F8F" opacity="0.45" />
      <ellipse cx={cx + ex + 5} cy={ey + 8} rx="5" ry="3" fill="#FF8F8F" opacity="0.45" />
      <path d={`M${cx - 6} ${ey + 9} Q${cx} ${ey + 15} ${cx + 6} ${ey + 9}`} stroke="#B5503F" strokeWidth="2.2" strokeLinecap="round" fill="none" />
    </g>
  );
}

const Neck = ({ y = 76, h = 18 }) => <rect x="53" y={y} width="14" height={h} rx="6" fill={NECK} />;

function Bunda({ u }) {
  return (
    <>
      <ellipse cx="60" cy="122" rx="42" ry="34" fill={url(u, 'apr')} />
      <path d="M46 98 Q60 110 74 98" stroke="#fff" strokeOpacity="0.55" strokeWidth="2.5" fill="none" strokeLinecap="round" />
      <Neck />
      <circle cx="60" cy="22" r="12" fill={url(u, 'hair')} />
      <ellipse cx="60" cy="52" rx="29" ry="30" fill={url(u, 'hair')} />
      <Face u={u} />
      <path d="M35 54 Q38 27 60 27 Q82 27 85 54 Q72 40 60 41 Q48 40 35 54Z" fill={url(u, 'hair')} />
      <ellipse cx="47" cy="33" rx="6" ry="3" fill="#fff" opacity="0.18" transform="rotate(-25 47 33)" />
    </>
  );
}

function Hijab({ u }) {
  return (
    <>
      <path d="M24 94 Q26 70 60 74 Q94 70 96 94 L100 130 L20 130Z" fill={url(u, 'lav')} />
      <ellipse cx="60" cy="54" rx="34" ry="37" fill={url(u, 'lav')} />
      <Face u={u} cy={57} rx={22} ry={24} />
      <ellipse cx="60" cy="57" rx="22.6" ry="24.6" fill="none" stroke="#7A5BD6" strokeOpacity="0.3" strokeWidth="1.5" />
      <path d="M37 50 Q40 26 60 25 Q80 26 83 50 Q72 41 60 41 Q48 41 37 50Z" fill={url(u, 'lav')} />
      <circle cx="60" cy="98" r="4" fill="#F4A261" />
    </>
  );
}

function Bumil({ u }) {
  return (
    <>
      <ellipse cx="60" cy="124" rx="40" ry="36" fill={url(u, 'teal')} />
      <ellipse cx="60" cy="110" rx="26" ry="24" fill={url(u, 'teal')} />
      <ellipse cx="53" cy="101" rx="8" ry="5" fill="#fff" opacity="0.22" />
      <path d="M60 118 C52 112 52 105 57 105 C59 105 60 107 60 107 C60 107 61 105 63 105 C68 105 68 112 60 118Z" fill="#fff" opacity="0.85" />
      <circle cx="43" cy="108" r="5.5" fill={url(u, 'skin')} />
      <circle cx="77" cy="108" r="5.5" fill={url(u, 'skin')} />
      <Neck />
      <path d="M30 62 Q26 26 60 24 Q94 26 90 62 L93 92 Q60 102 27 92Z" fill={url(u, 'hair')} />
      <Face u={u} />
      <path d="M35 52 Q40 27 62 28 Q82 30 85 52 Q70 38 54 46 Q44 46 35 52Z" fill={url(u, 'hair')} />
      <circle cx="82" cy="36" r="5" fill="#FF9EB5" />
      <circle cx="82" cy="36" r="2" fill="#FFE08A" />
    </>
  );
}

function Bayi({ u }) {
  return (
    <>
      <ellipse cx="60" cy="124" rx="32" ry="28" fill={url(u, 'teal')} />
      <path d="M60 104 l2.4 5 5.4.7 -4 3.8 1 5.3 -4.8-2.6 -4.8 2.6 1-5.3 -4-3.8 5.4-.7z" fill="#fff" opacity="0.8" />
      <rect x="52" y="82" width="16" height="18" rx="7" fill={NECK} />
      <Face u={u} cy={58} rx={30} ry={28} ex={11} er={4} ears />
      <path d="M54 31 Q58 18 68 26 Q62 24 62 32Z" fill={url(u, 'hair')} />
    </>
  );
}

function Balita({ u }) {
  return (
    <>
      <ellipse cx="60" cy="122" rx="38" ry="32" fill={url(u, 'apr')} />
      <Neck y={78} h={16} />
      <circle cx="30" cy="48" r="10" fill={url(u, 'hair')} />
      <circle cx="90" cy="48" r="10" fill={url(u, 'hair')} />
      <ellipse cx="60" cy="50" rx="28" ry="29" fill={url(u, 'hair')} />
      <Face u={u} ears />
      <path d="M36 52 Q40 28 60 28 Q80 28 84 52 Q74 42 60 44 Q46 42 36 52Z" fill={url(u, 'hair')} />
      <path d="M30 40 L20 34 L20 46Z M30 40 L40 34 L40 46Z" fill="#FF7FA0" />
      <path d="M90 40 L80 34 L80 46Z M90 40 L100 34 L100 46Z" fill="#FF7FA0" />
    </>
  );
}

function BalitaL({ u }) {
  return (
    <>
      <ellipse cx="60" cy="122" rx="38" ry="32" fill={url(u, 'apr')} />
      <path d="M28 110 Q60 120 92 110" stroke="#fff" strokeOpacity="0.55" strokeWidth="5" fill="none" />
      <Neck y={78} h={16} />
      <Face u={u} ears />
      <path d="M34 54 Q32 24 60 22 Q88 24 86 54 Q80 38 66 36 Q54 40 48 34 Q40 40 34 54Z" fill={url(u, 'hair')} />
      <path d="M54 26 L60 14 L67 26Z" fill={url(u, 'hair')} />
    </>
  );
}

const ART = { bunda: Bunda, hijab: Hijab, bumil: Bumil, bayi: Bayi, balita: Balita, balitaL: BalitaL };

export default function Avatar({ kind = 'bunda', size = 48, animate = true }) {
  const u = useId().replace(/[^a-zA-Z0-9]/g, '');
  const k = ART[kind] ? kind : 'bunda';
  const Art = ART[k];
  const nama = (CHARS.find((c) => c.id === k) || {}).nama;
  return (
    <svg className="av" width={size} height={size} viewBox="0 0 120 120" role="img" aria-label={`Karakter ${nama}`}>
      <Defs u={u} bg={BG[k]} />
      <g clipPath={url(u, 'cp')}>
        <circle cx="60" cy="60" r="60" fill={url(u, 'bg')} />
        <g className={animate ? 'av-bob' : ''}>
          <Art u={u} />
        </g>
      </g>
    </svg>
  );
}