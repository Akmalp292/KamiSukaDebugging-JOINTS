import { useEffect, useMemo, useState } from 'react';
import { collection, doc, limit, onSnapshot, orderBy, query } from 'firebase/firestore';
import { useAuth } from '../lib/useAuth';
import { db } from '../lib/firebase';
import { ageMonths, status } from '../lib/growth';
import { tagDari, pilihRekomendasi } from '../lib/recommend';
import '../styles/rekom.css';

const TIDAK_ADA = /^tidak disebutkan/i;

export default function Rekomendasi() {
  const { user } = useAuth();
  const uid = user?.uid;
  const [child, setChild] = useState(undefined);
  const [recs, setRecs] = useState([]);
  const [sums, setSums] = useState([]);
  const [open, setOpen] = useState('');

  useEffect(() => {
    if (!uid) return;
    const u1 = onSnapshot(
      doc(db, 'patients', uid),
      (s) => setChild(s.exists() ? s.data().child || null : null),
      () => setChild(null)
    );
    const u2 = onSnapshot(
      query(collection(db, 'patients', uid, 'records'), orderBy('date', 'asc')),
      (s) => setRecs(s.docs.map((d) => ({ id: d.id, ...d.data() }))),
      () => {}
    );
    const u3 = onSnapshot(
      query(collection(db, 'patients', uid, 'summaries'), orderBy('createdAt', 'desc'), limit(5)),
      (s) => setSums(s.docs.map((d) => ({ id: d.id, ...d.data() }))),
      () => {}
    );
    return () => { u1(); u2(); u3(); };
  }, [uid]);

  const hasil = useMemo(() => {
    if (!child) return null;
    const ageM = ageMonths(child.dob);
    const st = status(recs);

    let tags = [];
    let sumber = 'umum';
    let dokter = '';
    for (const s of sums) {
      const t = tagDari(`${s.diagnosa || ''} ${s.resep || ''}`);
      if (t.length) { tags = t; sumber = 'dokter'; dokter = s.doctorName || ''; break; }
    }
    if (!tags.length && st && st.key !== 'hijau') { tags = ['protein']; sumber = 'status'; }

    const pantanganList = sums.map((s) => s.pantangan).filter((p) => p && !TIDAK_ADA.test(p));
    const { items, disaring } = pilihRekomendasi({ tags, pantangan: pantanganList.join(' ; '), ageM });
    return { ageM, items, disaring, sumber, dokter, adaPantangan: pantanganList.length > 0 };
  }, [child, recs, sums]);

  if (!hasil) return null;

  const { ageM, items, disaring, sumber, dokter, adaPantangan } = hasil;

  if (ageM < 6) {
    return (
      <div className="rk-card">
        <h3>Rekomendasi Menu</h3>
        <p className="rk-sub">Anak di bawah 6 bulan cukup ASI eksklusif. MPASI baru dimulai pada usia 6 bulan. Konsultasikan dengan dokter atau bidan.</p>
      </div>
    );
  }

  const sub =
    sumber === 'dokter' ? `Berdasarkan ringkasan konsultasi${dokter ? ' dengan ' + dokter : ''}.`
    : sumber === 'status' ? 'Berdasarkan status pertumbuhan terakhir.'
    : 'Menu bergizi sesuai usia anak.';

  return (
    <div className="rk-card">
      <h3>Rekomendasi Menu</h3>
      <p className="rk-sub">{sub}</p>

      {adaPantangan && (
        <div className="rk-filter">
          Menu disaring sesuai pantangan dari dokter{disaring > 0 ? ` (${disaring} menu tidak ditampilkan)` : ''}.
        </div>
      )}

      {items.length === 0 && (
        <p className="rk-sub">Belum ada menu yang cocok. Tanyakan ke dokter atau asisten untuk saran menu.</p>
      )}

      {items.map((r) => (
        <div key={r.id} className={'rk-item' + (open === r.id ? ' open' : '')}>
          <button className="rk-head" onClick={() => setOpen(open === r.id ? '' : r.id)}>
            <span className="rk-ic"><span className="material-symbols-rounded">restaurant</span></span>
            <span>
              <b>{r.nama}</b>
              <small>Mulai usia {r.usiaMin} bulan</small>
            </span>
            <span className="material-symbols-rounded rk-chev">expand_more</span>
          </button>
          {open === r.id && (
            <div className="rk-body">
              <h4>Bahan</h4>
              <ul>{r.bahan.map((b, i) => <li key={i}>{b}</li>)}</ul>
              <h4>Cara membuat</h4>
              <ol>{r.langkah.map((l, i) => <li key={i}>{l}</li>)}</ol>
              <div className="rk-cat">{r.catatan}</div>
            </div>
          )}
        </div>
      ))}

      <p className="rk-note">
        Saran menu umum, bukan pengganti arahan dokter. Jangan menambah garam atau gula, dan jangan beri madu pada anak di bawah 12 bulan.
        Hentikan dan konsultasikan bila muncul alergi (ruam, bengkak, sesak).
      </p>
    </div>
  );
}