import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { useAuth } from '../lib/useAuth';
import { getChild, saveChild, addRecord, listRecords } from '../lib/records';
import { calc, status, ageMonths } from '../lib/growth';
import '../styles/tracker.css';

const COLOR = { hijau: '#2E9E5B', kuning: '#F2B705', merah: '#DC143C' };
const MAPS = 'https://www.google.com/maps/search/rumah+sakit+terdekat';

const TOPIK = [
  { id: 'gizi', icon: 'restaurant', t: 'Gizi & Nutrisi Anak', d: 'Nafsu makan, MPASI, berat badan' },
  { id: 'anak', icon: 'child_care', t: 'Tumbuh Kembang Anak', d: 'Tinggi badan, perkembangan, imunisasi' },
  { id: 'kandungan', icon: 'pregnant_woman', t: 'Kehamilan & Kandungan', d: 'Konsultasi untuk ibu hamil' },
];

function todayLocal() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}
const fmtTgl = (s) => new Date(s).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
const num = (v) => parseFloat(String(v).replace(',', '.'));

export default function Tracker() {
  const { user } = useAuth();
  const uid = user?.uid;
  const [child, setChild] = useState(undefined);
  const [recs, setRecs] = useState([]);
  const [form, setForm] = useState({ name: '', dob: '', gender: '' });
  const [inp, setInp] = useState({ weight: '', height: '' });
  const [err, setErr] = useState('');
  const [fail, setFail] = useState('');
  const [busy, setBusy] = useState(false);
  const [editing, setEditing] = useState(false);
  const [sheet, setSheet] = useState(false);
  const [kbusy, setKbusy] = useState('');
  const [kerr, setKerr] = useState('');

  async function load() {
    setFail('');
    try {
      const c = await getChild(uid);
      setRecs(c ? await listRecords(uid) : []);
      setChild(c);
    } catch (e) {
      console.error('[tracker] gagal memuat', e);
      setFail('Gagal memuat data. Cek koneksi dan pastikan rules Firestore sudah dipublish.');
    }
  }
  useEffect(() => { if (uid) load(); }, [uid]);

  function bukaKonsul() {
    if (!child) {
      window.toast && window.toast('Isi data anak dulu di Beranda.', 'warn');
      window.goPage && window.goPage('dash');
      return;
    }
    setKerr('');
    setSheet(true);
  }

  useEffect(() => {
    const h = () => bukaKonsul();
    window.addEventListener('sc:konsul', h);
    return () => window.removeEventListener('sc:konsul', h);
  }, [child, recs]);

  async function mulaiKonsul(topik) {
    if (!window.submitPreConsultForm) return setKerr('Fitur konsultasi belum siap. Muat ulang halaman.');
    const last = recs.at(-1);
    setKbusy(topik);
    setKerr('');
    try {
      const id = await window.submitPreConsultForm({
        childName: child.name,
        dob: child.dob,
        gender: child.gender,
        usia: `${ageMonths(child.dob)} bulan`,
        height: last ? last.height : null,
        weight: last ? last.weight : null,
        asi: '',
        sanitasi: '',
        riwayatPenyakitAlergi: '',
        ekonomi: '',
        giziIbu: '',
        topik,
      });
      if (!id) {
        setKerr('Belum ada dokter online untuk topik ini. Coba topik lain atau ulangi beberapa saat lagi.');
        return;
      }
      setSheet(false);
      window.goPage && window.goPage('chat');
      setTimeout(() => window.openPatientConsultation && window.openPatientConsultation(id), 400);
    } catch (e) {
      console.error('[tracker] konsultasi', e);
      setKerr('Gagal menghubungkan ke dokter. Coba lagi.');
    } finally { setKbusy(''); }
  }

  function mulaiUbah() {
    setForm({ name: child.name, dob: child.dob, gender: child.gender });
    setErr('');
    setEditing(true);
  }

  async function simpanAnak() {
    const name = form.name.trim();
    if (!name || !form.dob || !form.gender) return setErr('Lengkapi semua kolom.');
    if (ageMonths(form.dob) > 60) return setErr('Usia anak lebih dari 5 tahun. Pelacak ini untuk usia 0–5 tahun, cek tanggal lahir.');
    setBusy(true);
    try {
      await saveChild(uid, { name, dob: form.dob, gender: form.gender });
      setErr('');
      setEditing(false);
      await load();
    } catch (e) {
      console.error('[tracker] simpan anak', e);
      setErr('Gagal menyimpan. Coba lagi.');
    } finally { setBusy(false); }
  }

  async function simpanUkur() {
    const weight = num(inp.weight), height = num(inp.height);
    if (!(weight > 0) || !(height > 0)) return setErr('Isi BB dan TB dengan angka.');
    const date = todayLocal();
    if (recs.some((r) => r.date === date)) return setErr('Hari ini sudah dicatat. Catat lagi bulan depan.');
    const r = calc({ ...child, date, weight, height });
    if (r.ageM > 60) return setErr(`Usia anak terhitung ${r.ageM} bulan (lebih dari 5 tahun). Cek tanggal lahir lewat "Ubah data anak".`);
    if (Math.abs(r.haz) > 6 || Math.abs(r.waz) > 6) return setErr('Nilai tampak tidak wajar. Cek BB (kg) dan TB (cm).');
    setBusy(true);
    try {
      await addRecord(uid, { date, weight, height, ...r });
      setInp({ weight: '', height: '' });
      setErr('');
      await load();
    } catch (e) {
      console.error('[tracker] simpan ukur', e);
      setErr('Gagal menyimpan. Coba lagi.');
    } finally { setBusy(false); }
  }

  if (fail) {
    return (
      <div className="tk-card">
        <p className="tk-msg">{fail}</p>
        <button className="tk-btn tk-btn-light" onClick={load}>Coba lagi</button>
      </div>
    );
  }
  if (child === undefined) return <div className="tk-card"><p className="tk-msg">Memuat pelacak…</p></div>;

  /* ── Form data anak (pertama kali atau ubah) ── */
  if (child === null || editing) {
    return (
      <div className="tk-card">
        <h3>{editing ? 'Ubah Data Anak' : 'Data Anak'}</h3>
        <label>Nama anak</label>
        <input className="tk-in" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <label>Tanggal lahir</label>
        <input className="tk-in" type="date" max={todayLocal()} value={form.dob} onChange={(e) => setForm({ ...form, dob: e.target.value })} />
        <label>Jenis kelamin</label>
        <select className="tk-in" value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value })}>
          <option value="">Pilih…</option>
          <option value="L">Laki-laki</option>
          <option value="P">Perempuan</option>
        </select>
        {editing && recs.length > 0 && (
          <p className="tk-note">Catatan lama tidak dihitung ulang. Kalau tanggal lahir berubah banyak, riwayat lama bisa menyesatkan.</p>
        )}
        {err && <p className="tk-err">{err}</p>}
        <button className="tk-btn" disabled={busy} onClick={simpanAnak}>{busy ? 'Menyimpan…' : 'Simpan'}</button>
        {editing && <button className="tk-btn tk-btn-light" onClick={() => { setEditing(false); setErr(''); }}>Batal</button>}
      </div>
    );
  }

  const st = status(recs);
  const last = recs.at(-1);
  const umurSekarang = ageMonths(child.dob);
  const disarankan = st && st.key !== 'hijau' ? 'gizi' : 'anak';

  return (
    <>
      <div className="tk-card tk-status" style={{ borderColor: st ? COLOR[st.key] : '#E3ECEC' }}>
        <div className="tk-name">{child.name} · {umurSekarang} bln</div>
        {st ? (
          <>
            <div className="tk-dot" style={{ background: COLOR[st.key] }}>{st.label}</div>
            <p className="tk-msg">{st.msg}</p>
            <div className="tk-meta">Usia {last.ageM} bln · TB/U {last.haz} · BB/U {last.waz}</div>
            {st.key !== 'hijau' && (
              <button className="tk-btn" onClick={bukaKonsul}>Konsultasi Online</button>
            )}
          </>
        ) : (
          <p className="tk-msg">Belum ada catatan. Masukkan BB dan TB di bawah untuk melihat status.</p>
        )}
        <div className="tk-meta" style={{ marginTop: 10 }}>
          Lahir {fmtTgl(child.dob)} · <a href="#ubah" onClick={(e) => { e.preventDefault(); mulaiUbah(); }} style={{ color: '#17806F', fontWeight: 700 }}>Ubah data anak</a>
        </div>
      </div>

      <div className="tk-card">
        <h3>Catat hari ini</h3>
        <div className="tk-row">
          <div>
            <label>Berat (kg)</label>
            <input className="tk-in" inputMode="decimal" placeholder="mis. 9,6" value={inp.weight} onChange={(e) => setInp({ ...inp, weight: e.target.value })} />
          </div>
          <div>
            <label>Tinggi (cm)</label>
            <input className="tk-in" inputMode="decimal" placeholder="mis. 75,7" value={inp.height} onChange={(e) => setInp({ ...inp, height: e.target.value })} />
          </div>
        </div>
        <p className="tk-note">Anak di bawah 2 tahun diukur berbaring, 2 tahun ke atas berdiri.</p>
        {err && <p className="tk-err">{err}</p>}
        <button className="tk-btn" disabled={busy} onClick={simpanUkur}>{busy ? 'Menyimpan…' : 'Simpan & Cek Status'}</button>
      </div>

      {recs.length > 0 && (
        <div className="tk-card">
          <h3>Riwayat</h3>
          {[...recs].reverse().slice(0, 6).map((r) => (
            <div className="tk-hist" key={r.id}>
              <i style={{ background: COLOR[status([r]).key] }} />
              <span>{fmtTgl(r.date)}</span>
              <span>{r.weight} kg · {r.height} cm</span>
            </div>
          ))}
        </div>
      )}

      <p className="tk-note" style={{ marginBottom: 14 }}>Hasil ini skrining awal berdasarkan standar WHO, bukan diagnosis. Konsultasikan dengan dokter atau bidan.</p>

      {sheet && createPortal(
        <div className="tk-sh-bg" onClick={() => !kbusy && setSheet(false)}>
          <div className="tk-sh" onClick={(e) => e.stopPropagation()}>
            <div className="tk-grip" />
            <h3 className="tk-sh-title">Konsultasi Online</h3>
            <p className="tk-sh-sub">Pilih topik. Dokter yang sedang online dipilihkan otomatis.</p>

            {st && st.key === 'merah' && (
              <div className="tk-warn">
                Hasil menunjukkan risiko tinggi. Pastikan ukuran BB dan TB sudah benar, ukur ulang bila ragu.
                Jika anak lemas, tidak mau makan atau minum, atau sesak, segera ke faskes:{' '}
                <a href="tel:119">Telepon 119</a> · <a href={MAPS} target="_blank" rel="noreferrer">Faskes terdekat</a>
              </div>
            )}

            <div className="tk-send">
              Data yang dikirim ke dokter: {child.name} · {umurSekarang} bln
              {last ? ` · ${last.weight} kg · ${last.height} cm` : ' · belum ada catatan ukur'}
            </div>

            {TOPIK.map((x) => (
              <button key={x.id} className={'tk-opt' + (x.id === disarankan ? ' rec' : '')} disabled={!!kbusy} onClick={() => mulaiKonsul(x.id)}>
                <span className="tk-opt-ic"><span className="material-symbols-rounded">{x.icon}</span></span>
                <span>
                  <b>{x.t}</b>
                  <small>{kbusy === x.id ? 'Mencari dokter online…' : x.d}</small>
                </span>
                {x.id === disarankan && <span className="tk-badge">Disarankan</span>}
              </button>
            ))}

            {kerr && <p className="tk-err">{kerr}</p>}
            <button className="tk-btn tk-btn-light" disabled={!!kbusy} onClick={() => setSheet(false)}>Batal</button>
          </div>
        </div>,
        document.body
      )}
    </>
  );
}