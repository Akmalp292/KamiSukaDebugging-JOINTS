import { useEffect, useRef, useState } from 'react';
import promos from '../data/promos.json';
import Avatar from './Avatar';
import '../styles/home.css';

const MAPS_POSYANDU = 'https://www.google.com/maps/search/posyandu+terdekat';

function aksi(p) {
  if (p.aksi === 'konsul') window.dispatchEvent(new Event('sc:konsul'));
  else if (p.aksi === 'asisten') window.goPage && window.goPage('asisten');
  else if (p.aksi === 'maps') window.open(MAPS_POSYANDU, '_blank', 'noopener');
  else if (p.aksi === 'ukur') document.querySelector('.tk-status')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

export default function PromoCarousel() {
  const ref = useRef(null);
  const pause = useRef(false);
  const [idx, setIdx] = useState(0);

  useEffect(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return undefined;
    const t = setInterval(() => {
      const el = ref.current;
      if (!el || pause.current || !el.clientWidth) return; // halaman sedang disembunyikan
      const next = (Math.round(el.scrollLeft / el.clientWidth) + 1) % promos.length;
      el.scrollTo({ left: next * el.clientWidth, behavior: 'smooth' });
    }, 4500);
    return () => clearInterval(t);
  }, []);

  function onScroll(e) {
    const el = e.currentTarget;
    if (el.clientWidth) setIdx(Math.round(el.scrollLeft / el.clientWidth));
  }

  function keSlide(i) {
    const el = ref.current;
    if (el) el.scrollTo({ left: i * el.clientWidth, behavior: 'smooth' });
  }

  return (
    <div className="pr-wrap">
      <div
        className="pr-track"
        ref={ref}
        onScroll={onScroll}
        onTouchStart={() => { pause.current = true; }}
        onTouchEnd={() => { setTimeout(() => { pause.current = false; }, 3000); }}
        onMouseEnter={() => { pause.current = true; }}
        onMouseLeave={() => { pause.current = false; }}
      >
        {promos.map((p) => (
          <div className="pr-slide" key={p.id}>
            <div className="pr-card" style={{ background: `linear-gradient(135deg, ${p.warna[0]}, ${p.warna[1]})` }}>
              <i className="pr-circle c1" />
              <i className="pr-circle c2" />
              <div className="pr-txt">
                <span className="pr-tag">{p.label}</span>
                <b>{p.judul}</b>
                <p>{p.isi}</p>
                <button onClick={() => aksi(p)}>{p.tombol}</button>
              </div>
              <div className="pr-art"><Avatar kind={p.karakter} size={92} /></div>
            </div>
          </div>
        ))}
      </div>
      <div className="pr-dots">
        {promos.map((p, i) => <i key={p.id} className={i === idx ? 'on' : ''} onClick={() => keSlide(i)} />)}
      </div>
    </div>
  );
}