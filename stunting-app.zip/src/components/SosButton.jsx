import { useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { DEMO, JENIS, TIPE, cariKecamatan, cariFaskes, telHref } from '../lib/sos';
import { useAmbulance, URUT, LABEL } from '../lib/useAmbulance';
import SosMap from './SosMap';
import '../styles/sos.css';

const FLOW = ['wilayah', 'faskes', 'jenis', 'konfirmasi'];
const FLOW_LABEL = ['Wilayah', 'Faskes', 'Kejadian', 'Ambulans'];
const CHIPS = [['semua', 'Semua'], ['rs', 'RS'], ['puskesmas', 'Puskesmas'], ['klinik', 'Klinik'], ['posyandu', 'Posyandu']];

const mapsDir = (o, f) =>
  `https://www.google.com/maps/dir/?api=1&origin=${o.lat},${o.lon}&destination=${f.lat},${f.lon}`;

function pesanTahap(tahap, st, ctx) {
  const eta = st?.etaMin ? `${st.etaMin} menit` : 'segera';
  switch (tahap) {
    case 'diterima': return ['Panggilan diterima', 'Petugas menerima laporan Anda. Tetap di lokasi dan ikuti arahan.'];
    case 'ditugaskan': return ['Unit ditugaskan', `Ambulans ditugaskan ke ${ctx.asal}.`];
    case 'berangkat': return ['Ambulans berangkat', `Unit berangkat dari ${ctx.tujuan} menuju ${ctx.asal}.`];
    case 'perjalanan': return ['Ambulans dalam perjalanan', `Perkiraan tiba ${eta}.`];
    case 'tiba': return ['Ambulans tiba di lokasi', `Unit telah tiba di ${ctx.asal}.`];
    case 'menuju_faskes': return ['Menuju fasilitas kesehatan', `Dalam perjalanan ke ${ctx.tujuan}${st?.etaMin ? `, perkiraan ${eta}` : ''}.`];
    case 'selesai': return ['Tiba di tujuan', `Pasien telah tiba di ${ctx.tujuan}.`];
    default: return ['Status ambulans', String(tahap)];
  }
}

export default function SosButton() {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState('wilayah');
  const [q, setQ] = useState('');
  const [hasilW, setHasilW] = useState([]);
  const [wLoading, setWLoading] = useState(false);
  const [wErr, setWErr] = useState('');
  const [origin, setOrigin] = useState(null);
  const [faskes, setFaskes] = useState([]);
  const [fLoading, setFLoading] = useState(false);
  const [fErr, setFErr] = useState('');
  const [tipe, setTipe] = useState('semua');
  const [selectedId, setSelectedId] = useState(null);
  const [jenisId, setJenisId] = useState('');
  const [calling, setCalling] = useState(false);
  const [active, setActive] = useState(false);
  const [eventId, setEventId] = useState(null);
  const [notif, setNotif] = useState(null);
  const reqId = useRef(0);
  const lastTahap = useRef(null);

  const tampil = useMemo(() => faskes.filter((f) => tipe === 'semua' || f.tipe === tipe), [faskes, tipe]);
  const chosen = useMemo(() => faskes.find((f) => f.id === selectedId) || null, [faskes, selectedId]);
  const mapFaskes = useMemo(() => (step === 'faskes' ? tampil : chosen ? [chosen] : []), [step, tampil, chosen]);
  const jenis = JENIS.find((j) => j.id === jenisId) || null;
  const asal = origin ? origin.nama.split(',')[0] : '';

  const st = useAmbulance({ active, demo: DEMO, eventId, origin, faskes: chosen });
  const idx = st ? URUT.indexOf(st.tahap) : -1;

  // gulir ke kartu faskes yang dipilih (juga saat marker di peta diketuk)
  useEffect(() => {
    if (step === 'faskes' && selectedId) {
      document.getElementById('sxf-' + selectedId)?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }, [selectedId, step]);

  // notifikasi tiap status ambulans berubah
  useEffect(() => {
    if (!active) { lastTahap.current = null; return undefined; }
    if (!st || st.tahap === lastTahap.current) return undefined;
    lastTahap.current = st.tahap;
    const [title, msg] = pesanTahap(st.tahap, st, { asal, tujuan: chosen ? chosen.nama : 'fasilitas kesehatan' });
    setNotif({ title, msg });
    try { if (navigator.vibrate) navigator.vibrate([120, 60, 120]); } catch { /* abaikan */ }
    const t = setTimeout(() => setNotif(null), 6000);
    return () => clearTimeout(t);
  }, [st?.tahap, active]);

  async function muatFaskes(o) {
    const my = ++reqId.current;
    setFLoading(true);
    setFErr('');
    setFaskes([]);
    setSelectedId(null);
    try {
      const r = await cariFaskes(o);
      if (my === reqId.current) setFaskes(r);
    } catch (e) {
      if (my === reqId.current) setFErr(e.message || 'Gagal memuat data faskes.');
    } finally {
      if (my === reqId.current) setFLoading(false);
    }
  }

  function pilihWilayah(o) {
    setOrigin(o);
    setTipe('semua');
    setStep('faskes');
    muatFaskes(o);
  }

  async function cari() {
    const t = q.trim();
    if (t.length < 3) return setWErr('Ketik nama kecamatan (minimal 3 huruf).');
    setWLoading(true);
    setWErr('');
    setHasilW([]);
    try {
      const r = await cariKecamatan(t);
      if (!r.length) setWErr('Kecamatan tidak ditemukan. Tambahkan nama kota, misalnya "Kebayoran Baru, Jakarta Selatan".');
      setHasilW(r);
    } catch (e) {
      setWErr(e.message || 'Pencarian gagal. Coba lagi.');
    } finally {
      setWLoading(false);
    }
  }

  function pakaiGps() {
    if (!navigator.geolocation) return setWErr('Perangkat tidak mendukung lokasi. Ketik nama kecamatan.');
    setWLoading(true);
    setWErr('');
    navigator.geolocation.getCurrentPosition(
      (p) => { setWLoading(false); pilihWilayah({ nama: 'Lokasi saya', lat: p.coords.latitude, lon: p.coords.longitude }); },
      () => { setWLoading(false); setWErr('Lokasi tidak bisa diakses. Ketik nama kecamatan.'); },
      { timeout: 8000, enableHighAccuracy: true }
    );
  }

  async function mulaiPantau() {
    let id = null;
    try {
      const uid = auth.currentUser?.uid;
      if (uid && chosen && origin) {
        const ref = await addDoc(collection(db, 'emergencyEvents'), {
          patientId: uid,
          kecamatan: origin.nama,
          lokasi: { lat: origin.lat, lon: origin.lon },
          faskesNama: chosen.nama,
          faskesTipe: chosen.tipe,
          faskesLokasi: { lat: chosen.lat, lon: chosen.lon },
          kejadian: jenisId,
          mode: DEMO ? 'demo' : 'nyata',
          status: 'diterima',
          createdAt: serverTimestamp(),
        });
        id = ref.id;
      }
    } catch (e) {
      console.error('[sos] gagal mencatat kejadian', e);
    }
    setEventId(id);
    setActive(true);
    setStep('tracking');
  }

  function akhiri() {
    setActive(false);
    setEventId(null);
    setCalling(false);
    setStep('wilayah');
    setOrigin(null);
    setFaskes([]);
    setSelectedId(null);
    setJenisId('');
    setQ('');
    setHasilW([]);
    setNotif(null);
    lastTahap.current = null;
    setOpen(false);
  }

  const pillText = st ? `${LABEL[st.tahap]}${st.etaMin && st.tahap !== 'tiba' && st.tahap !== 'selesai' ? ` · ${st.etaMin} mnt` : ''}` : 'Menunggu petugas…';
  const stepIdx = FLOW.indexOf(step);

  return (
    <>
      <button className="sx-fab" onClick={() => setOpen(true)} aria-label="Darurat">SOS</button>

      {active && !open && (
        <button className="sx-pill" onClick={() => setOpen(true)}>
          <span>🚑</span> {DEMO ? 'Simulasi · ' : ''}{pillText}
        </button>
      )}

      {notif && (
        <div className="sx-notif" onClick={() => { setNotif(null); setOpen(true); }}>
          <b>{DEMO ? 'SIMULASI · ' : ''}{notif.title}</b>
          <span>{notif.msg}</span>
        </div>
      )}

      {open && createPortal(
        <div className="sx-bg" onClick={() => setOpen(false)}>
          <div className="sx-sheet" onClick={(e) => e.stopPropagation()}>
            <div className="sx-head">
              <div className="sx-top">
                <h3 className="sx-title">Siaga Darurat</h3>
                <button className="sx-x" onClick={() => setOpen(false)} aria-label="Tutup">
                  <span className="material-symbols-rounded">close</span>
                </button>
              </div>
              <a className="sx-quick" href="tel:119">
                <span className="material-symbols-rounded">call</span> Langsung telepon 119
              </a>
              {step !== 'tracking' && (
                <div className="sx-steps">
                  {FLOW_LABEL.map((l, i) => (
                    <span key={l} className={'sx-st' + (i === stepIdx ? ' on' : i < stepIdx ? ' done' : '')}>{i + 1}. {l}</span>
                  ))}
                </div>
              )}
            </div>

            <div className="sx-mapbox">
              <SosMap
                origin={origin}
                faskes={mapFaskes}
                selectedId={selectedId}
                onSelect={setSelectedId}
                ambulance={st?.pos ? { lat: st.pos.lat, lon: st.pos.lon } : null}
              />
            </div>

            <div className="sx-body">
              {/* ═══ 1. WILAYAH ═══ */}
              {step === 'wilayah' && (
                <>
                  <h4 className="sx-h">Kamu berada di kecamatan mana?</h4>
                  <div className="sx-search">
                    <input
                      value={q}
                      onChange={(e) => setQ(e.target.value)}
                      onKeyDown={(e) => { if (e.key === 'Enter') cari(); }}
                      placeholder="mis. Kebayoran Baru, Jakarta Selatan"
                    />
                    <button onClick={cari} disabled={wLoading}>{wLoading ? '…' : 'Cari'}</button>
                  </div>
                  <button className="sx-link" onClick={pakaiGps} disabled={wLoading}>
                    <span className="material-symbols-rounded">my_location</span> Pakai lokasi saya
                  </button>
                  {wErr && <p className="sx-err">{wErr}</p>}
                  {hasilW.map((h) => (
                    <button key={h.nama} className="sx-res" onClick={() => pilihWilayah(h)}>
                      <span className="material-symbols-rounded">location_on</span>
                      <span>{h.nama}</span>
                    </button>
                  ))}
                  {!hasilW.length && !wErr && <p className="sx-sub">Ketik nama kecamatan, lalu tekan Cari. Peta akan langsung menuju wilayahmu.</p>}
                </>
              )}

              {/* ═══ 2. FASKES ═══ */}
              {step === 'faskes' && (
                <>
                  <div className="sx-rowh">
                    <h4 className="sx-h">Faskes &amp; posyandu terdekat</h4>
                    <button className="sx-link" onClick={() => setStep('wilayah')}>Ganti wilayah</button>
                  </div>
                  <p className="sx-sub">Dari {asal}. Ketuk kartu atau titik di peta untuk melihat detail.</p>
                  <div className="sx-chips">
                    {CHIPS.map(([k, l]) => (
                      <button key={k} className={'sx-chip' + (tipe === k ? ' sel' : '')} onClick={() => setTipe(k)}>{l}</button>
                    ))}
                  </div>

                  {fLoading && <p className="sx-sub">Mencari faskes terdekat…</p>}
                  {fErr && (
                    <>
                      <p className="sx-err">{fErr}</p>
                      <button className="sx-btn sx-soft" onClick={() => muatFaskes(origin)}>Coba lagi</button>
                    </>
                  )}
                  {!fLoading && !fErr && tampil.length === 0 && (
                    <p className="sx-sub">
                      Belum ada data {tipe === 'semua' ? 'faskes' : TIPE[tipe]} tercatat di sekitar wilayah ini. Telepon 119 atau cari di{' '}
                      <a href={`https://www.google.com/maps/search/rumah+sakit+terdekat/@${origin.lat},${origin.lon},14z`} target="_blank" rel="noreferrer">Google Maps</a>.
                    </p>
                  )}

                  {tampil.map((f) => {
                    const sel = f.id === selectedId;
                    return (
                      <div key={f.id} id={'sxf-' + f.id} className={'sx-card' + (sel ? ' sel' : '')}>
                        <button className="sx-card-h" onClick={() => setSelectedId(sel ? null : f.id)}>
                          <span className={'sx-ic ' + f.tipe}>
                            <span className="material-symbols-rounded">{f.tipe === 'posyandu' ? 'child_care' : 'local_hospital'}</span>
                          </span>
                          <span className="sx-card-t">
                            <b>{f.nama}</b>
                            <small>{TIPE[f.tipe]} · {f.jarak.toFixed(1)} km{f.verified ? ' · Terverifikasi' : ''}</small>
                          </span>
                          <span className="material-symbols-rounded sx-chev">{sel ? 'expand_less' : 'expand_more'}</span>
                        </button>
                        {sel && (
                          <div className="sx-card-b">
                            <div className="sx-kv">
                              <span className="material-symbols-rounded">call</span>
                              <span>{f.telp || <i>Nomor telepon belum tercatat</i>}</span>
                              {f.telp && telHref(f.telp) && <a className="sx-mini" href={telHref(f.telp)}>Telepon</a>}
                            </div>
                            <div className="sx-kv">
                              <span className="material-symbols-rounded">location_on</span>
                              <span>{f.alamat || <i>Alamat belum tercatat</i>}</span>
                            </div>
                            <div className="sx-kv">
                              <span className="material-symbols-rounded">schedule</span>
                              <span>{f.jam || <i>Jam buka belum tercatat. Hubungi faskes untuk memastikan.</i>}</span>
                            </div>
                            <div className="sx-acts">
                              <a className="sx-btn sx-maps" href={mapsDir(origin, f)} target="_blank" rel="noreferrer">Rute di Google Maps</a>
                              <button className="sx-btn sx-go" onClick={() => setStep('jenis')}>Pilih sebagai tujuan</button>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                  <p className="sx-note">Data dari OpenStreetMap, bisa belum lengkap atau berubah. Pastikan lewat telepon bila memungkinkan.</p>
                </>
              )}

              {/* ═══ 3. KEJADIAN ═══ */}
              {step === 'jenis' && (
                <>
                  <h4 className="sx-h">Apa yang terjadi?</h4>
                  <div className="sx-jgrid">
                    {JENIS.map((j) => (
                      <button key={j.id} className={'sx-j' + (j.id === jenisId ? ' sel' : '')} onClick={() => setJenisId(j.id)}>
                        <span className="material-symbols-rounded">{j.icon}</span>
                        {j.t}
                      </button>
                    ))}
                  </div>
                  {jenis && (
                    <>
                      <div className="sx-sub2">Pertolongan pertama: {jenis.t}</div>
                      <ol className="sx-guide">{jenis.steps.map((s, i) => <li key={i}>{s}</li>)}</ol>
                      <div className="sx-warn">{jenis.warn}</div>
                    </>
                  )}
                  <p className="sx-note">Panduan awal, bukan pengganti tenaga medis.</p>
                  <div className="sx-acts">
                    <button className="sx-btn sx-soft" onClick={() => setStep('faskes')}>Kembali</button>
                    <button className="sx-btn sx-go" disabled={!jenis} onClick={() => setStep('konfirmasi')}>Lanjut</button>
                  </div>
                </>
              )}

              {/* ═══ 4. TELEPON AMBULANS ═══ */}
              {step === 'konfirmasi' && chosen && (
                <>
                  <h4 className="sx-h">Siap menelepon ambulans</h4>
                  <div className="sx-sum">
                    <div><small>Lokasi</small><b>{origin.nama}</b></div>
                    <div><small>Tujuan</small><b>{chosen.nama}</b><em>{TIPE[chosen.tipe]} · {chosen.jarak.toFixed(1)} km</em></div>
                    <div><small>Kejadian</small><b>{jenis ? jenis.t : '-'}</b></div>
                  </div>
                  <div className="sx-say">
                    <b>Sampaikan ke petugas 119:</b>
                    Lokasi di {origin.nama}, kejadian {jenis ? jenis.t.toLowerCase() : ''}, dan ingin dibawa ke {chosen.nama}.
                  </div>

                  <a className="sx-btn sx-call" href="tel:119" onClick={() => setCalling(true)}>Telepon Ambulans (119)</a>

                  {calling && (
                    <div className="sx-ask">
                      <b>Sudah tersambung dengan 119?</b>
                      <div className="sx-acts">
                        <button className="sx-btn sx-soft" onClick={() => setCalling(false)}>Belum, coba lagi</button>
                        <button className="sx-btn sx-go" onClick={mulaiPantau}>Ya, tersambung</button>
                      </div>
                    </div>
                  )}
                  <p className="sx-note">
                    {DEMO
                      ? 'Pemantauan ambulans saat ini berupa simulasi untuk demo. Tidak ada unit sungguhan yang dikirim lewat aplikasi, panggilan ke 119 tetap harus dilakukan.'
                      : 'Status ambulans diperbarui oleh petugas setelah panggilan diterima.'}
                  </p>
                  <button className="sx-btn sx-soft" onClick={() => { setCalling(false); setStep('jenis'); }}>Kembali</button>
                </>
              )}

              {/* ═══ PEMANTAUAN ═══ */}
              {step === 'tracking' && chosen && (
                <>
                  <div className={'sx-mode' + (DEMO ? ' demo' : '')}>
                    {DEMO
                      ? 'MODE SIMULASI · pergerakan ambulans di peta adalah contoh untuk demo, bukan unit sungguhan. Pastikan Anda sudah menelepon 119.'
                      : 'Status diperbarui oleh petugas. Jika belum dihubungi, telepon 119 lagi.'}
                  </div>
                  <div className="sx-big">{st ? LABEL[st.tahap] : 'Menunggu konfirmasi petugas…'}</div>
                  {st && st.etaMin && st.tahap !== 'tiba' && st.tahap !== 'selesai' && (
                    <div className="sx-eta">Perkiraan {st.etaMin} menit{DEMO ? ' (simulasi)' : ''}</div>
                  )}
                  <div className="sx-info">Dari: {asal} · Tujuan: {chosen.nama}</div>
                  <ol className="sx-tl">
                    {URUT.map((k, i) => (
                      <li key={k} className={i < idx ? 'done' : i === idx ? 'now' : ''}>{LABEL[k]}</li>
                    ))}
                  </ol>
                  <div className="sx-acts">
                    <a className="sx-btn sx-call" href="tel:119">Telepon 119 lagi</a>
                  </div>
                  <div className="sx-acts">
                    <button className="sx-btn sx-soft" onClick={() => setOpen(false)}>Tutup (tetap dipantau)</button>
                    <button className="sx-btn sx-soft" onClick={akhiri}>{st && st.tahap === 'selesai' ? 'Selesai' : 'Akhiri pantauan'}</button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>,
        document.body
      )}
    </>
  );
}