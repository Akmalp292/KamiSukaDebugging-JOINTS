import { useId } from 'react';
import { SKIN, HAIR, TOP, BOTTOM } from '../lib/maskot';
import '../styles/maskot.css';

const VIEWS = { full: [0, 0, 120, 200], bust: [16, 22, 88, 112], face: [24, 26, 72, 72] };
const SHADE = 'rgba(0,0,0,0.16)';

function Arm({ side, sleeve, outline, skin, longSleeve, wave }) {
  const m = (x) => (side === 'r' ? 120 - x : x);
  const arm = (
    <g>
      {!longSleeve && <line x1={m(37)} y1="113" x2={m(32)} y2="130" stroke={skin} strokeWidth="8" strokeLinecap="round" />}
      {outline && <line x1={m(41)} y1="104" x2={m(32)} y2="130" stroke={outline} strokeWidth="12" strokeLinecap="round" />}
      <line
        x1={m(41)} y1="104"
        x2={m(longSleeve ? 32 : 37)} y2={longSleeve ? 130 : 113}
        stroke={sleeve} strokeWidth="10" strokeLinecap="round"
      />
      <circle cx={m(31)} cy="134" r="6" fill={skin} />
    </g>
  );
  return side === 'r' ? <g className={wave ? 'mk-arm-wave' : ''}>{arm}</g> : arm;
}

function BackHair({ style, c }) {
  if (style === 'hijab') return null;
  return (
    <g fill={c}>
      <ellipse cx="60" cy="58" rx="32" ry="30" />
      {style === 'kuncir' && (
        <>
          <ellipse cx="22" cy="78" rx="9" ry="19" transform="rotate(14 22 78)" />
          <ellipse cx="98" cy="78" rx="9" ry="19" transform="rotate(-14 98 78)" />
        </>
      )}
      {style === 'panjang' && <path d="M28 60 Q25 28 60 27 Q95 28 92 60 L97 114 Q60 124 23 114Z" />}
      {style === 'pendek' && <path d="M28 60 Q26 30 60 29 Q94 30 92 60 L92 86 Q60 94 28 86Z" />}
    </g>
  );
}

const FRINGE = {
  pendek: 'M31 58 Q34 33 60 33 Q86 33 89 58 Q76 46 60 48 Q44 46 31 58Z',
  kuncir: 'M31 58 Q34 33 60 33 Q86 33 89 58 Q76 44 60 47 Q44 44 31 58Z',
  panjang: 'M30 60 Q34 33 62 33 Q88 35 90 60 Q72 42 50 52 Q38 52 30 60Z',
  jambul: 'M30 58 L33 36 L44 46 L50 30 L60 44 L70 30 L76 46 L87 36 L90 58 Q76 48 60 50 Q44 48 30 58Z',
};

function FrontHair({ style, c }) {
  if (style === 'hijab') return null;
  return (
    <g>
      <path d={FRINGE[style] || FRINGE.pendek} fill={c} />
      <path d="M42 42 Q52 35 63 37" stroke="#fff" strokeOpacity="0.28" strokeWidth="3" strokeLinecap="round" fill="none" />
      {style === 'kuncir' && (
        <>
          <circle cx="29" cy="62" r="3.6" fill="#FF7FA0" />
          <circle cx="91" cy="62" r="3.6" fill="#FF7FA0" />
        </>
      )}
    </g>
  );
}

function Acc({ kind, accent }) {
  if (kind === 'kacamata') {
    return (
      <g fill="none" stroke="#2B1B17" strokeWidth="2">
        <circle cx="49" cy="66" r="8.5" />
        <circle cx="71" cy="66" r="8.5" />
        <path d="M57.5 65 H62.5" />
      </g>
    );
  }
  if (kind === 'pita') {
    return (
      <g>
        <path d="M36 40 L24 32 L26 48Z" fill="#FF7FA0" />
        <path d="M36 40 L48 32 L46 48Z" fill="#FF7FA0" />
        <circle cx="36" cy="40" r="4" fill="#E9507F" />
      </g>
    );
  }
  if (kind === 'topi') {
    return (
      <g>
        <path d="M31 56 Q33 27 60 27 Q87 27 89 56Z" fill={accent} />
        <path d="M58 54 Q94 48 100 58 Q80 63 58 58Z" fill={accent} />
        <path d="M58 54 Q94 48 100 58" stroke="rgba(0,0,0,0.2)" strokeWidth="1.5" fill="none" />
      </g>
    );
  }
  return null;
}

export default function Maskot({ cfg, view = 'full', size = 120, pose = 'idle', animate = true }) {
  const u = useId().replace(/[^a-zA-Z0-9]/g, '');
  const [vx, vy, vw, vh] = VIEWS[view] || VIEWS.full;
  const skin = SKIN[cfg.skin] ?? SKIN[0];
  const hair = HAIR[cfg.hairColor] ?? HAIR[0];
  const top = TOP[cfg.topColor] ?? TOP[0];
  const bot = BOTTOM[cfg.bottomColor] ?? BOTTOM[0];
  const hijab = cfg.hairStyle === 'hijab';
  const snelli = cfg.top === 'snelli';
  const longSleeve = cfg.top !== 'kaos';
  const sleeve = snelli ? '#FFFFFF' : top;
  const think = pose === 'think';
  const wave = pose === 'wave';

  return (
    <svg
      className="mk-svg"
      width={size}
      height={(size * vh) / vw}
      viewBox={`${vx} ${vy} ${vw} ${vh}`}
      role="img"
      aria-label="Maskot asisten StuntingCare"
    >
      <defs>
        <radialGradient id={u + 'hl'} cx="0.3" cy="0.25" r="0.8">
          <stop offset="0" stopColor="#fff" stopOpacity="0.5" />
          <stop offset="1" stopColor="#fff" stopOpacity="0" />
        </radialGradient>
        <linearGradient id={u + 'sh'} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#000" stopOpacity="0" />
          <stop offset="1" stopColor="#000" stopOpacity="0.18" />
        </linearGradient>
      </defs>

      <ellipse cx="60" cy="192" rx="26" ry="4" fill="rgba(0,0,0,0.14)" />

      <g className={animate ? 'mk-bob' : ''}>
        {/* rambut belakang / hijab belakang */}
        <BackHair style={cfg.hairStyle} c={hair} />
        {hijab && <path d="M20 66 Q18 30 60 26 Q102 30 100 66 L108 120 Q60 134 12 120Z" fill={hair} />}

        {/* kaki */}
        {cfg.bottom === 'celana' && (
          <>
            <rect x="42" y="136" width="17" height="48" rx="7" fill={bot} />
            <rect x="61" y="136" width="17" height="48" rx="7" fill={bot} />
          </>
        )}
        {cfg.bottom !== 'celana' && (
          <>
            <rect x="45" y="150" width="11" height="34" rx="5" fill={skin} />
            <rect x="64" y="150" width="11" height="34" rx="5" fill={skin} />
          </>
        )}
        {cfg.bottom === 'pendek' && (
          <>
            <rect x="42" y="136" width="17" height="28" rx="7" fill={bot} />
            <rect x="61" y="136" width="17" height="28" rx="7" fill={bot} />
          </>
        )}
        {cfg.bottom === 'rok' && <path d="M38 136 L82 136 L90 168 Q60 175 30 168Z" fill={bot} />}
        <ellipse cx="50" cy="187" rx="11" ry="5.5" fill="#fff" stroke="#CBD9DB" strokeWidth="1" />
        <ellipse cx="70" cy="187" rx="11" ry="5.5" fill="#fff" stroke="#CBD9DB" strokeWidth="1" />

        {/* leher + badan */}
        <rect x="53" y="84" width="14" height="16" rx="5" fill={skin} />
        <rect x="40" y="93" width="40" height="50" rx="15" fill={top} />
        <rect x="40" y="93" width="40" height="50" rx="15" fill={`url(#${u}sh)`} />
        {!snelli && cfg.top !== 'hoodie' && <path d="M52 93 Q60 102 68 93Z" fill={skin} />}
        {cfg.top === 'hoodie' && (
          <>
            <ellipse cx="60" cy="96" rx="24" ry="9" fill={top} />
            <ellipse cx="60" cy="96" rx="24" ry="9" fill={SHADE} />
            <rect x="49" y="124" width="22" height="11" rx="5" fill={SHADE} />
            <line x1="55" y1="102" x2="55" y2="113" stroke="#fff" strokeOpacity="0.85" strokeWidth="1.6" strokeLinecap="round" />
            <line x1="65" y1="102" x2="65" y2="113" stroke="#fff" strokeOpacity="0.85" strokeWidth="1.6" strokeLinecap="round" />
          </>
        )}
        {snelli && (
          <>
            <path d="M40 100 Q40 93 48 93 L56 93 L56 150 L44 150 Q40 150 40 142Z" fill="#fff" stroke="#D5E3E3" strokeWidth="1" />
            <path d="M80 100 Q80 93 72 93 L64 93 L64 150 L76 150 Q80 150 80 142Z" fill="#fff" stroke="#D5E3E3" strokeWidth="1" />
          </>
        )}

        {/* lengan */}
        <Arm side="l" sleeve={sleeve} outline={snelli ? '#D5E3E3' : null} skin={skin} longSleeve={longSleeve} />
        <Arm side="r" sleeve={sleeve} outline={snelli ? '#D5E3E3' : null} skin={skin} longSleeve={longSleeve} wave={wave} />

        {/* kerudung menutupi bahu */}
        {hijab && (
          <>
            <path d="M26 86 Q60 112 94 86 L102 124 Q60 138 18 124Z" fill={hair} />
            <path d="M26 86 Q60 112 94 86 L102 124 Q60 138 18 124Z" fill={`url(#${u}sh)`} />
          </>
        )}

        {/* stetoskop */}
        {cfg.acc === 'stetoskop' && (
          <g>
            <path d="M47 95 Q47 122 60 124 Q73 122 73 95" stroke="#5B7075" strokeWidth="2.6" fill="none" strokeLinecap="round" />
            <circle cx="60" cy="126" r="4" fill="#CBD9DB" stroke="#5B7075" strokeWidth="1.5" />
          </g>
        )}

        {/* kepala */}
        <circle cx="31" cy="64" r="5" fill={skin} />
        <circle cx="89" cy="64" r="5" fill={skin} />
        <ellipse cx="60" cy="62" rx="30" ry="27" fill={skin} />
        <ellipse cx="60" cy="62" rx="30" ry="27" fill={`url(#${u}hl)`} />
        <ellipse cx="60" cy="88" rx="16" ry="3" fill="rgba(0,0,0,0.08)" />

        {/* wajah */}
        <path d="M43 57 Q49 54 55 57" stroke="#3B261E" strokeWidth="1.8" strokeLinecap="round" fill="none" />
        <path d="M65 57 Q71 54 77 57" stroke="#3B261E" strokeWidth="1.8" strokeLinecap="round" fill="none" />
        <g className={think ? 'mk-look' : ''}>
          <g className="mk-eyes">
            <ellipse cx="49" cy="66" rx="3.6" ry="4.2" fill="#2B1B17" />
            <ellipse cx="71" cy="66" rx="3.6" ry="4.2" fill="#2B1B17" />
            <circle cx="50.2" cy="64.4" r="1.3" fill="#fff" />
            <circle cx="72.2" cy="64.4" r="1.3" fill="#fff" />
          </g>
        </g>
        <ellipse cx="42" cy="75" rx="5" ry="3" fill="#FF8F8F" opacity="0.45" />
        <ellipse cx="78" cy="75" rx="5" ry="3" fill="#FF8F8F" opacity="0.45" />
        {think ? (
          <circle cx="60" cy="79" r="2.4" fill="#B5503F" />
        ) : wave ? (
          <path d="M53 75 Q60 87 67 75Z" fill="#B5503F" />
        ) : (
          <path d="M54 76 Q60 82 66 76" stroke="#B5503F" strokeWidth="2.2" strokeLinecap="round" fill="none" />
        )}

        {/* rambut depan / hijab depan */}
        <FrontHair style={cfg.hairStyle} c={hair} />
        {hijab && (
          <g>
            <path
              fillRule="evenodd"
              fill={hair}
              d="M24 62 a36 38 0 1 0 72 0 a36 38 0 1 0 -72 0 Z M32 62 a28 27 0 1 0 56 0 a28 27 0 1 0 -56 0 Z"
            />
            <path
              fillRule="evenodd"
              fill={SHADE}
              d="M24 62 a36 38 0 1 0 72 0 a36 38 0 1 0 -72 0 Z M32 62 a28 27 0 1 0 56 0 a28 27 0 1 0 -56 0 Z"
            />
          </g>
        )}

        <Acc kind={cfg.acc} accent={top} />

        {think && (
          <g className="mk-dots">
            <circle cx="86" cy="36" r="2" fill="#9DB3B6" />
            <circle cx="94" cy="30" r="3" fill="#9DB3B6" />
            <circle cx="102" cy="22" r="4" fill="#9DB3B6" />
          </g>
        )}
      </g>
    </svg>
  );
}