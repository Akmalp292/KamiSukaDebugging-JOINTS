import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import MaskotStage from './MaskotStage';
import { OPT, SKIN, HAIR, TOP, BOTTOM, DEFAULT, loadMaskot, saveMaskot, sanitize } from '../lib/maskot';
import '../styles/maskot.css';

const TABS = [['rambut', 'Rambut'], ['baju', 'Baju'], ['bawah', 'Bawahan'], ['aksesori', 'Aksesori'], ['kulit', 'Kulit']];

const rnd = (n) => Math.floor(Math.random() * n);
const rndKey = (list) => list[rnd(list.length)][0];

function Chips({ items, val, on }) {
  return (
    <div className="mk-row">
      {items.map(([k, label]) => (
        <button key={k} className={'mk-chip' + (val === k ? ' sel' : '')} onClick={() => on(k)}>{label}</button>
      ))}
    </div>
  );
}

function Dots({ colors, val, on }) {
  return (
    <div className="mk-row">
      {colors.map((c, i) => (
        <button key={c} className={'mk-dot' + (val === i ? ' sel' : '')} style={{ background: c }} onClick={() => on(i)} aria-label={`Warna ${i + 1}`} />
      ))}
    </div>
  );
}

export default function MaskotStudio({ open, onClose }) {
  const [d, setD] = useState(loadMaskot);
  const [tab, setTab] = useState('rambut');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (open) {
      setD(loadMaskot());
      setTab('rambut');
    }
  }, [open]);

  if (!open) return null;

  const set = (k, v) => setD((x) => ({ ...x, [k]: v }));

  function acak() {
    setD({
      skin: rnd(SKIN.length),
      hairStyle: rndKey(OPT.hairStyle),
      hairColor: rnd(HAIR.length),
      top: rndKey(OPT.top),
      topColor: rnd(TOP.length),
      bottom: rndKey(OPT.bottom),
      bottomColor: rnd(BOTTOM.length),
      acc: rndKey(OPT.acc),
    });
  }

  async function simpan() {
    setBusy(true);
    await saveMaskot(sanitize(d));
    setBusy(false);
    onClose();
  }

  return createPortal(
    <div className="mk-sh-bg" onClick={onClose}>
      <div className="mk-sh" onClick={(e) => e.stopPropagation()}>
        <div className="mk-grip" />
        <h3>Ubah Penampilan</h3>

        <div className="mk-preview">
          <MaskotStage cfg={d} view="full" size={130} />
        </div>
        <p className="mk-hint">Geser karakter untuk memutar. Ketuk dua kali untuk berputar penuh.</p>

        <div className="mk-tabs">
          {TABS.map(([k, label]) => (
            <button key={k} className={'mk-tab' + (tab === k ? ' sel' : '')} onClick={() => setTab(k)}>{label}</button>
          ))}
        </div>

        <div className="mk-panel">
          {tab === 'rambut' && (
            <>
              <div className="mk-lb">Gaya</div>
              <Chips items={OPT.hairStyle} val={d.hairStyle} on={(v) => set('hairStyle', v)} />
              <div className="mk-lb">Warna rambut / hijab</div>
              <Dots colors={HAIR} val={d.hairColor} on={(v) => set('hairColor', v)} />
            </>
          )}
          {tab === 'baju' && (
            <>
              <div className="mk-lb">Model</div>
              <Chips items={OPT.top} val={d.top} on={(v) => set('top', v)} />
              <div className="mk-lb">Warna</div>
              <Dots colors={TOP} val={d.topColor} on={(v) => set('topColor', v)} />
            </>
          )}
          {tab === 'bawah' && (
            <>
              <div className="mk-lb">Model</div>
              <Chips items={OPT.bottom} val={d.bottom} on={(v) => set('bottom', v)} />
              <div className="mk-lb">Warna</div>
              <Dots colors={BOTTOM} val={d.bottomColor} on={(v) => set('bottomColor', v)} />
            </>
          )}
          {tab === 'aksesori' && (
            <>
              <div className="mk-lb">Aksesori</div>
              <Chips items={OPT.acc} val={d.acc} on={(v) => set('acc', v)} />
            </>
          )}
          {tab === 'kulit' && (
            <>
              <div className="mk-lb">Warna kulit</div>
              <Dots colors={SKIN} val={d.skin} on={(v) => set('skin', v)} />
            </>
          )}
        </div>

        <div className="mk-actions">
          <button className="mk-btn light" onClick={acak}>Acak</button>
          <button className="mk-btn light" onClick={() => setD({ ...DEFAULT })}>Reset</button>
          <button className="mk-btn" disabled={busy} onClick={simpan}>{busy ? 'Menyimpan…' : 'Simpan'}</button>
        </div>
      </div>
    </div>,
    document.body
  );
}