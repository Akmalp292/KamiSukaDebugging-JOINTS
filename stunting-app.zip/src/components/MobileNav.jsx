import { useEffect, useState } from 'react';

const PASIEN = [
  { id: 'dash', ic: 'home', l: 'Beranda' },
  { id: 'asisten', ic: 'smart_toy', l: 'Asisten' },
  { id: 'akun', ic: 'person', l: 'Akun' },
];
const DOKTER = [
  { id: 'chat', ic: 'forum', l: 'Konsultasi' },
  { id: 'um', ic: 'person', l: 'Akun' },
];
// halaman yang menyalakan tab Asisten bagi pasien
const ALIAS_PASIEN = { chat: 'asisten', preconsult: 'asisten' };

export default function MobileNav() {
  const [cur, setCur] = useState('dash');
  const [role, setRole] = useState('pasien');

  useEffect(() => {
    const t = setInterval(() => {
      const el = document.querySelector('.page.active');
      const id = el ? el.id.replace('page-', '') : 'dash';
      const r = window.getRole ? window.getRole() : 'pasien';
      setRole(r);
      setCur(r === 'dokter' ? id : ALIAS_PASIEN[id] || id);
    }, 250);
    return () => clearInterval(t);
  }, []);

  const items = role === 'dokter' ? DOKTER : PASIEN;

  function go(id) {
    if (id === 'um') return window.showUM && window.showUM(); // dokter: popup akun
    window.goPage && window.goPage(id);
  }

  return (
    <nav className="mnav">
      {items.map((it) => (
        <button key={it.id} className={'mnav-i' + (cur === it.id ? ' act' : '')} onClick={() => go(it.id)}>
          <span className="material-symbols-rounded">{it.ic}</span>
          <span>{it.l}</span>
        </button>
      ))}
    </nav>
  );
}