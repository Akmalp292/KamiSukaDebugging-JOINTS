import { useRef, useState } from 'react';
import Maskot from './Maskot';
import '../styles/maskot.css';

export default function MaskotStage({ cfg, view = 'full', size = 120, pose = 'idle' }) {
  const [rot, setRot] = useState(0);
  const [drag, setDrag] = useState(false);
  const [wave, setWave] = useState(false);
  const [spin, setSpin] = useState(false);
  const st = useRef({ x: 0, moved: false, last: 0 });

  function down(e) {
    st.current.x = e.clientX;
    st.current.moved = false;
    setDrag(true);
    if (e.currentTarget.setPointerCapture) e.currentTarget.setPointerCapture(e.pointerId);
  }

  function move(e) {
    if (!drag) return;
    const dx = e.clientX - st.current.x;
    if (Math.abs(dx) > 4) st.current.moved = true;
    setRot(Math.max(-55, Math.min(55, dx * 0.7)));
  }

  function up() {
    setDrag(false);
    setRot(0);
    if (st.current.moved) return;
    const now = Date.now();
    if (now - st.current.last < 320) {
      setSpin(true);
      setTimeout(() => setSpin(false), 850);
    } else {
      setWave(true);
      setTimeout(() => setWave(false), 1800);
    }
    st.current.last = now;
  }

  return (
    <div className="mk-stage" style={{ width: size }} onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up}>
      <div
        className={'mk-rot' + (drag ? '' : ' spring') + (spin ? ' spin' : '')}
        style={spin ? undefined : { transform: `perspective(520px) rotateY(${rot}deg)` }}
      >
        <Maskot cfg={cfg} view={view} size={size} pose={wave ? 'wave' : pose} />
      </div>
    </div>
  );
}