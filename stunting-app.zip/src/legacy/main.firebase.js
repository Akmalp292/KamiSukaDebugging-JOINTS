/* ════════════════════════════════
   FIREBASE — Chat real-time (Pasien & Dokter) + Ringkasan AI
════════════════════════════════ */
import { onAuthStateChanged, signOut, signInAnonymously } from 'firebase/auth';
import {
  doc, getDoc, updateDoc, collection, query, where, orderBy, increment,
  onSnapshot, addDoc, getDocs, serverTimestamp
} from 'firebase/firestore';
import { auth as fbAuth, db as fbDb } from '../lib/firebase.js';
import { summarizeChat, MIN_MESSAGES_FOR_SUMMARY } from '../lib/summarizeBackend.js';
import { downloadSummaryPdf } from '../lib/summaryPdf.js';
import '../styles/summary.css';

let activeConsultId = null;
let unsubMsgs = null;
let unsubConvList = null;
let activeConsultData = null;
let lastConsultMessages = []; // disegarkan tiap ada snapshot pesan baru, buat bahan ringkas AI

function currentSession(){ return JSON.parse(localStorage.getItem('sc_s')||'null'); }

const STATUS_LABEL = { menunggu: '🟡 Menunggu', aktif: '🟢 Aktif', selesai: '⚪ Selesai' };

// Pastikan Firebase Auth benar-benar sudah login sebagai dokter ini
onAuthStateChanged(fbAuth, (user) => {
  const s = currentSession();
  if (s?.role === 'dokter' && user && user.uid === s.uid) {
    updateDoc(doc(fbDb, 'doctors', user.uid), { status: 'online' }).catch(()=>{});
  }
});

window.firebaseSignOutDoctor = async function(){
  const s = currentSession();
  if (s?.uid) {
    try { await updateDoc(doc(fbDb, 'doctors', s.uid), { status: 'offline' }); } catch(e){}
  }
  if (unsubMsgs) unsubMsgs();
  if (unsubConvList) unsubConvList();
  try { await signOut(fbAuth); } catch(e){}
};

/* ════════════════════════════════
   SISI DOKTER
════════════════════════════════ */

window.renderDoctorConvList = function(){
  const s = currentSession();
  if (!s?.uid) return;
  const listEl = document.getElementById('doc-list');
  if (!listEl) return;

  if (unsubConvList) unsubConvList();

  const q = query(collection(fbDb, 'consultations'), where('doctorId', '==', s.uid));

  unsubConvList = onSnapshot(q, (snap) => {
    if (snap.empty) {
      listEl.innerHTML = '<div style="padding:24px 16px;text-align:center;color:var(--gray);font-size:.84rem;">Belum ada pasien yang mengirim konsultasi.</div>';
      return;
    }
    const items = [];
    snap.forEach((docSnap) => items.push({ id: docSnap.id, ...docSnap.data() }));
    items.sort((a, b) => (b.updatedAt?.toMillis?.() || 0) - (a.updatedAt?.toMillis?.() || 0));

    listEl.innerHTML = '';
    items.forEach((c) => {
      const item = document.createElement('div');
      item.className = 'doc-list-item' + (c.id === activeConsultId ? ' active' : '');
      item.innerHTML = `
        <div class="dli-ava"><span class="material-symbols-rounded">person</span></div>
        <div style="flex:1;min-width:0;">
          <div class="dli-name">${escapeHtmlDoc(c.patientName || 'Pasien')} <span style="font-size:.68rem;font-weight:400;">${STATUS_LABEL[c.status]||''}</span></div>
          <div class="dli-spec" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${c.childName ? 'Anak: '+escapeHtmlDoc(c.childName)+' · ' : ''}${escapeHtmlDoc(c.lastMessage || 'Belum ada pesan')}</div>
        </div>`;
      item.onclick = () => window.openDoctorConsultation(c.id);
      listEl.appendChild(item);
    });
  }, (err) => {
    listEl.innerHTML = '<div style="padding:20px 16px;color:var(--red);font-size:.82rem;">Gagal memuat data. Coba muat ulang halaman.</div>';
    console.error(err);
  });
};

window.openDoctorConsultation = async function(consultationId){
  activeConsultId = consultationId;
  if (unsubMsgs) unsubMsgs();

  document.querySelectorAll('#doc-list .doc-list-item').forEach(el => el.classList.remove('active'));

  const snap = await getDoc(doc(fbDb, 'consultations', consultationId));
  if (!snap.exists()) return;
  activeConsultData = snap.data();
  renderDoctorTopbar();

  document.getElementById('chat-empty').style.display = 'none';
  document.getElementById('chat-messages').style.display = 'flex';
  document.getElementById('chat-input-area').style.display = activeConsultData.status === 'aktif' ? 'flex' : 'none';

  const msgQ = query(collection(fbDb, 'consultations', consultationId, 'messages'), orderBy('sentAt', 'asc'));
  unsubMsgs = onSnapshot(msgQ, (snap) => {
    const el = document.getElementById('chat-messages');
    if (!el) return;
    el.innerHTML = '';
    snap.forEach((docSnap) => {
      const m = docSnap.data();
      const time = m.sentAt ? new Date(m.sentAt.toDate()).toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'}) : '';
      const div = document.createElement('div');
      div.className = 'msg ' + (m.senderType === 'doctor' ? 'sent' : 'recv');
      div.innerHTML = `<div class="msg-bubble">${escapeHtmlDoc(m.text)}</div><div class="msg-time">${time}</div>`;
      el.appendChild(div);
    });
    el.scrollTop = el.scrollHeight;
  });
};

function renderDoctorTopbar(){
  const c = activeConsultData;
  const info = `${c.childName || '-'} · ${c.usia || '-'} · Topik: ${topikLabel(c.topik)}`;
  let actionBtn = '';
  if (c.status === 'aktif') {
    actionBtn = `<button class="btn btn-sm btn-secondary" onclick="window.finishConsultation()"><span class="material-symbols-rounded">check_circle</span> Selesaikan Konsultasi</button>`;
  }
  document.getElementById('chat-topbar').innerHTML = `
    <div class="chat-topbar-ava"><span class="material-symbols-rounded">person</span></div>
    <div><div class="chat-doc-name">${escapeHtmlDoc(c.patientName || 'Pasien')}</div><div class="chat-doc-status" style="color:var(--gray);font-size:.72rem;">${escapeHtmlDoc(info)} · ${STATUS_LABEL[c.status]||''}</div></div>
    <div style="margin-left:auto;">${actionBtn}</div>`;
}

function topikLabel(t){
  return { gizi: 'Gizi & Nutrisi Anak', anak: 'Tumbuh Kembang Anak', kandungan: 'Kehamilan & Kandungan' }[t] || t || '-';
}

window.sendDoctorReply = async function(){
  const s = currentSession();
  const box = document.getElementById('chat-input-box');
  const text = box.value.trim();
  if (!text || !activeConsultId || !s?.uid) return;
  box.value = ''; box.style.height = 'auto';

  await addDoc(collection(fbDb, 'consultations', activeConsultId, 'messages'), {
    senderType: 'doctor',
    senderId: s.uid,
    text,
    sentAt: serverTimestamp()
  });
  await updateDoc(doc(fbDb, 'consultations', activeConsultId), {
    lastMessage: text,
    updatedAt: serverTimestamp()
  });
};

window.finishConsultation = async function(){
  if (!activeConsultId) return;
  const s = currentSession();
  await updateDoc(doc(fbDb, 'consultations', activeConsultId), { status: 'selesai', updatedAt: serverTimestamp() });
  if (s?.uid) {
    await updateDoc(doc(fbDb, 'doctors', s.uid), { activeConsultations: increment(-1) }).catch(()=>{});
  }
  const snap = await getDoc(doc(fbDb, 'consultations', activeConsultId));
  activeConsultData = snap.data();
  renderDoctorTopbar();
  document.getElementById('chat-input-area').style.display = 'none';
  window.toast && window.toast('Konsultasi ditandai selesai.');
};

/* ════════════════════════════════
   SISI PASIEN
════════════════════════════════ */
let patientUid = null;

async function ensurePatientAuth(){
  if (fbAuth.authStateReady) await fbAuth.authStateReady();
  if (fbAuth.currentUser) { patientUid = fbAuth.currentUser.uid; return patientUid; }
  const cred = await signInAnonymously(fbAuth);
  patientUid = cred.user.uid;
  return patientUid;
}

window.renderPatientConsultList_impl = async function(){
  await ensurePatientAuth().catch((err)=>{ console.error('[consult-list] auth gagal:', err); });
  const listEl = document.getElementById('doc-list');
  if (!listEl) return;

  if (unsubConvList) unsubConvList();

  const q = query(collection(fbDb, 'consultations'), where('patientId', '==', patientUid));
  unsubConvList = onSnapshot(q, (snap) => {
    if (snap.empty) {
      listEl.innerHTML = '<div style="padding:24px 16px;text-align:center;color:var(--gray);font-size:.84rem;">Belum ada riwayat konsultasi. Klik "Mulai Konsultasi Baru" di atas.</div>';
      return;
    }
    const items = [];
    snap.forEach((docSnap) => items.push({ id: docSnap.id, ...docSnap.data() }));
    items.sort((a, b) => (b.updatedAt?.toMillis?.() || 0) - (a.updatedAt?.toMillis?.() || 0));

    listEl.innerHTML = '';
    items.forEach((c) => {
      const item = document.createElement('div');
      item.className = 'doc-list-item' + (c.id === activeConsultId ? ' active' : '');
      item.innerHTML = `
        <div class="dli-ava"><span class="material-symbols-rounded">medical_services</span></div>
        <div style="flex:1;min-width:0;">
          <div class="dli-name">${escapeHtmlDoc(c.doctorName || 'Dokter')} <span style="font-size:.68rem;font-weight:400;">${STATUS_LABEL[c.status]||''}</span></div>
          <div class="dli-spec" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtmlDoc(c.lastMessage || 'Belum ada pesan')}</div>
        </div>`;
      item.onclick = () => window.openPatientConsultation(c.id);
      listEl.appendChild(item);
    });
  }, (err) => {
    listEl.innerHTML = '<div style="padding:20px 16px;color:var(--red);font-size:.82rem;">Gagal memuat riwayat konsultasi.</div>';
    console.error('[consult-list] onSnapshot error:', err);
  });
};

window.openPatientConsultation = async function(consultationId){
  await ensurePatientAuth();
  activeConsultId = consultationId;
  if (unsubMsgs) unsubMsgs();

  document.querySelectorAll('#doc-list .doc-list-item').forEach(el => el.classList.remove('active'));

  const snap = await getDoc(doc(fbDb, 'consultations', consultationId));
  if (!snap.exists()) return;
  activeConsultData = snap.data();

  const statusColor = activeConsultData.status === 'aktif' ? 'var(--green-d)' : activeConsultData.status === 'menunggu' ? 'var(--amber)' : 'var(--gray)';
  document.getElementById('chat-topbar').innerHTML = `
    <div class="chat-topbar-ava"><span class="material-symbols-rounded">medical_services</span></div>
    <div><div class="chat-doc-name">${escapeHtmlDoc(activeConsultData.doctorName || 'Dokter')}</div><div class="chat-doc-status" style="color:${statusColor};">${STATUS_LABEL[activeConsultData.status]||''} · Topik: ${topikLabel(activeConsultData.topik)}</div></div>
    <div id="chat-summary-slot" style="margin-left:auto;"></div>`;

  document.getElementById('chat-empty').style.display = 'none';
  document.getElementById('chat-messages').style.display = 'flex';
  document.getElementById('chat-input-area').style.display = activeConsultData.status === 'aktif' ? 'flex' : 'none';

  const msgQ = query(collection(fbDb, 'consultations', consultationId, 'messages'), orderBy('sentAt', 'asc'));
  unsubMsgs = onSnapshot(msgQ, (snap) => {
    const el = document.getElementById('chat-messages');
    if (!el) return;
    el.innerHTML = '';
    lastConsultMessages = [];

    if (snap.empty) {
      el.innerHTML = '<div style="text-align:center;color:var(--gray);font-size:.82rem;padding:20px;">Mulai percakapan dengan mengirim pesan pertama Anda.</div>';
      updateSummarySlot(0);
      return;
    }
    snap.forEach((docSnap) => {
      const m = docSnap.data();
      lastConsultMessages.push(m);
      const time = m.sentAt ? new Date(m.sentAt.toDate()).toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'}) : '';
      const div = document.createElement('div');
      div.className = 'msg ' + (m.senderType === 'patient' ? 'sent' : 'recv');
      div.innerHTML = `<div class="msg-bubble">${escapeHtmlDoc(m.text)}</div><div class="msg-time">${time}</div>`;
      el.appendChild(div);
    });
    el.scrollTop = el.scrollHeight;
    updateSummarySlot(lastConsultMessages.length);
  });
};

function updateSummarySlot(count){
  const slot = document.getElementById('chat-summary-slot');
  if (!slot) return;
  slot.innerHTML = count >= MIN_MESSAGES_FOR_SUMMARY
    ? `<button class="btn btn-sm btn-secondary" onclick="window.openChatSummary()"><span class="material-symbols-rounded">auto_awesome</span> Ringkas Percakapan</button>`
    : '';
}

window.sendPatientMessageFn = async function(){
  const box = document.getElementById('chat-input-box');
  const text = box.value.trim();
  if (!text) return;
  if (!activeConsultId) { window.toast ? window.toast('Pilih atau mulai konsultasi terlebih dahulu','warn') : alert('Pilih konsultasi dulu'); return; }
  box.value = ''; box.style.height = 'auto';

  await addDoc(collection(fbDb, 'consultations', activeConsultId, 'messages'), {
    senderType: 'patient',
    senderId: patientUid,
    text,
    sentAt: serverTimestamp()
  });
  await updateDoc(doc(fbDb, 'consultations', activeConsultId), {
    lastMessage: text,
    updatedAt: serverTimestamp()
  });
};

/* ════════════════════════════════
   RINGKASAN AI 3 POIN — sisi pasien
════════════════════════════════ */
const SUMMARY_ITEMS = [
  { k: 'diagnosa', t: 'Diagnosa / Saran Dokter', ic: 'medical_services' },
  { k: 'resep', t: 'Resep Obat', ic: 'medication' },
  { k: 'pantangan', t: 'Pantangan Makanan', ic: 'block' },
];

// disimpan supaya Beranda bisa menampilkan rekomendasi (langkah berikutnya)
async function simpanRingkasan(poin){
  try {
    const uid = fbAuth.currentUser?.uid;
    if (!uid) return;
    await addDoc(collection(fbDb, 'patients', uid, 'summaries'), {
      consultationId: activeConsultId,
      doctorName: activeConsultData?.doctorName || '',
      childName: activeConsultData?.childName || '',
      diagnosa: poin.diagnosa,
      resep: poin.resep,
      pantangan: poin.pantangan,
      createdAt: serverTimestamp()
    });
  } catch (err) {
    console.error('Gagal menyimpan ringkasan:', err);
  }
}

window.openChatSummary = async function(){
  const modal = document.getElementById('summary-modal');
  const body = document.getElementById('summary-modal-body');
  if (!modal || !body || !activeConsultData) return;

  modal.classList.add('open');
  body.innerHTML = `
    <div class="sm-loading">
      <div class="sm-spinner"></div>
      <div class="sm-loading-text">Sedang merangkum percakapan Anda, mohon tunggu sebentar...</div>
    </div>`;

  const percakapanText = lastConsultMessages
    .map(m => `${m.senderType === 'patient' ? 'Pasien' : 'Dokter'}: ${m.text}`)
    .join('\n');

  try {
    const poin = await summarizeChat(percakapanText);
    const doctorName = activeConsultData.doctorName || '-';
    const tanggal = new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });

    const cards = SUMMARY_ITEMS.map(({ k, t, ic }) => {
      const isi = poin[k] || 'Tidak disebutkan dokter.';
      const kosong = /^tidak disebutkan/i.test(isi);
      return `<div class="sm-pt${kosong ? ' none' : ''}"><b><span class="material-symbols-rounded">${ic}</span>${t}</b><p>${escapeHtmlDoc(isi)}</p></div>`;
    }).join('');

    body.innerHTML = `
      ${cards}
      <div class="sm-disc">Ringkasan dibuat otomatis oleh AI dari percakapan, bukan pengganti catatan medis. Ikuti instruksi dokter dan aturan pakai pada label obat.</div>
      <div class="sm-actions">
        <button class="btn btn-secondary btn-full" onclick="window.closeSummaryModal()">Tutup</button>
        <button class="btn btn-primary btn-full" id="summary-download-btn"><span class="material-symbols-rounded">download</span> Unduh sebagai PDF</button>
      </div>`;

    document.getElementById('summary-download-btn').onclick = () => {
      downloadSummaryPdf({ doctorName, tanggal, poin });
    };

    simpanRingkasan(poin);
  } catch (err) {
    console.error('Gagal meringkas percakapan:', err);
    body.innerHTML = `
      <div class="sm-err"><span class="material-symbols-rounded">error</span> Gagal meringkas percakapan. ${escapeHtmlDoc(err.message || '')} Coba lagi.</div>
      <div class="sm-actions">
        <button class="btn btn-secondary btn-full" onclick="window.closeSummaryModal()">Tutup</button>
        <button class="btn btn-primary btn-full" onclick="window.openChatSummary()"><span class="material-symbols-rounded">refresh</span> Coba Lagi</button>
      </div>`;
  }
};

window.closeSummaryModal = function(){
  document.getElementById('summary-modal')?.classList.remove('open');
};

/* ════════════════════════════════
   MATCHING DOKTER OTOMATIS (dipanggil dari lembar Konsultasi Online)
════════════════════════════════ */
window.submitPreConsultForm = async function(formData){
  const uid = await ensurePatientAuth();
  const s = currentSession();

  // 1) dokter dengan kategori sesuai topik & sedang online
  const dq = query(
    collection(fbDb, 'doctors'),
    where('category', '==', formData.topik),
    where('status', '==', 'online')
  );
  const dSnap = await getDocs(dq);
  if (dSnap.empty) return null;

  // 2) beban kerja paling sedikit
  const candidates = dSnap.docs.map(docSnap => ({
    id: docSnap.id,
    data: docSnap.data(),
    load: docSnap.data().activeConsultations || 0
  }));
  candidates.sort((a, b) => a.load - b.load);
  const chosen = candidates[0];

  // 3) sesi konsultasi baru
  const newDoc = await addDoc(collection(fbDb, 'consultations'), {
    patientId: uid,
    patientName: s?.name || fbAuth.currentUser?.displayName || 'Pasien',
    doctorId: chosen.id,
    doctorName: chosen.data.name,
    status: 'aktif',
    childName: formData.childName,
    dob: formData.dob,
    gender: formData.gender,
    usia: formData.usia,
    height: formData.height ?? null,
    weight: formData.weight ?? null,
    asi: formData.asi || '',
    sanitasi: formData.sanitasi || '',
    riwayatPenyakitAlergi: formData.riwayatPenyakitAlergi || '',
    ekonomi: formData.ekonomi || '',
    giziIbu: formData.giziIbu || '',
    topik: formData.topik,
    lastMessage: '',
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  });

  // 4) naikkan counter beban kerja (kalau gagal, konsultasi tetap jalan)
  try {
    await updateDoc(doc(fbDb, 'doctors', chosen.id), { activeConsultations: increment(1) });
  } catch (err) {
    console.error('[konsultasi] counter dokter tidak naik:', err);
  }

  return newDoc.id;
};

function escapeHtmlDoc(str){
  const div = document.createElement('div');
  div.textContent = str == null ? '' : String(str);
  return div.innerHTML;
}