export function init() {

/* ════════════════════════════════
   DATA LAYER
════════════════════════════════ */
// session tetap dicache di localStorage (cuma nunjuk akun Firebase mana yg lagi login),
// tapi appointment & checker sekarang beneran nyimpen ke Firestore lewat main.firebase.js
const DB={
  session(){ return JSON.parse(localStorage.getItem('sc_s')||'null'); },
  setSession(s){ localStorage.setItem('sc_s',JSON.stringify(s)); },
  clearSession(){ localStorage.removeItem('sc_s'); },
};

/* ════════════════════════════════
   TOAST
════════════════════════════════ */
function toast(msg,type='ok'){
  const t=document.createElement('div'); t.className='toast '+type; t.textContent=msg;
  document.getElementById('toast-box').appendChild(t);
  requestAnimationFrame(()=>requestAnimationFrame(()=>t.classList.add('show')));
  setTimeout(()=>{ t.classList.remove('show'); setTimeout(()=>t.remove(),400); },3000);
}

/* ════════════════════════════════
   ROLE (pasien / dokter)
════════════════════════════════ */
function getRole(){ const s=DB.session(); return s?.role || 'pasien'; }

/* ════════════════════════════════
   PAGE NAV
════════════════════════════════ */
function goPage(id){
  // Dokter cuma boleh akses Chat & halaman appointment-nya sendiri.
  if(getRole()==='dokter' && id!=='chat' && id!=='docjadwal'){ id='chat'; }
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  const el=document.getElementById('page-'+id);
  if(el) el.classList.add('active');
  window.scrollTo({top:0,behavior:'smooth'});
  if(id==='dash'){ syncUI(); renderMyBookings(); }
  if(id==='layanan'){ syncUI('lay'); resetLay(); }
  if(id==='jadwal'){ syncUI('jd'); renderJadwalPage(); }
  if(id==='docjadwal'){ syncUI('dj'); renderDoctorAppointments(); }
  if(id==='preconsult'){ syncUI('pc'); resetPreConsult(); }
  if(id==='chat'){
    syncUI('chat');
    if(getRole()==='dokter'){ renderDoctorConvList(); } else { renderPatientConsultList(); }
  }
}

function applyRoleUI(){
  const role=getRole();
  document.querySelectorAll('.al-item').forEach(item=>{
    const roles=(item.dataset.roles||'').split(',');
    item.style.display = roles.includes(role) ? 'flex' : 'none';
  });
  const chatLbl=document.getElementById('al-chat-label');
  if(chatLbl) chatLbl.textContent = role==='dokter' ? 'Konsultasi Masuk' : 'Konsultasi Dokter';

  const hdTitle=document.getElementById('chat-hd-title');
  const hdSub=document.getElementById('chat-hd-sub');
  const searchWrap=document.getElementById('chat-search-wrap');
  const emptyTitle=document.querySelector('.chat-empty-title');
  const emptySub=document.querySelector('.chat-empty-sub');
  if(role==='dokter'){
    if(hdTitle) hdTitle.textContent='Konsultasi Masuk';
    if(hdSub) hdSub.textContent='Sesi konsultasi dari pasien';
    if(searchWrap) searchWrap.style.display='none';
    if(emptyTitle) emptyTitle.textContent='Pilih Konsultasi';
    if(emptySub) emptySub.textContent='Pilih sesi konsultasi dari panel kiri untuk membalas pasien.';
  }
}

function syncUI(prefix='dash'){
  const s=DB.session(); if(!s) return;
  const ava=(s.name[0]||'U').toUpperCase();
  let displayName = s.name || 'User';
  if(displayName.length > 40) {
    displayName = displayName.substring(0, 37) + '...';
  }
  ['dash','lay','chat','pc','jd','dj'].forEach(p=>{
    const a=document.getElementById(p+'-ava'); const u=document.getElementById(p+'-uname');
    if(a) a.textContent=ava; if(u) u.textContent=displayName;
  });
}

function scrollTo2(id){ goPage('dash'); setTimeout(()=>{ const el=document.getElementById(id); if(el) el.scrollIntoView({behavior:'smooth',block:'start'}); },380); }

/* ════════════════════════════════
   APP LAUNCHER (Semesta Layanan)
════════════════════════════════ */
function toggleAppLauncher(){
  document.getElementById('al-dropdown').classList.toggle('open');
  document.getElementById('al-overlay').classList.toggle('open');
}
function closeAppLauncher(){
  document.getElementById('al-dropdown').classList.remove('open');
  document.getElementById('al-overlay').classList.remove('open');
}
function alGo(page){ closeAppLauncher(); goPage(page); }
function alGoSection(id){ closeAppLauncher(); scrollTo2(id); }

/* ════════════════════════════════
   AUTH HELPERS
════════════════════════════════ */
// Removed all auth-related functions

function doLogout(){
  const role=getRole();
  if(role==='dokter' && window.firebaseSignOutDoctor){ window.firebaseSignOutDoctor(); }
  DB.clearSession(); toast('Anda telah keluar','warn'); closeUM(); setTimeout(()=>window.location.href='/',600);
}

/* ════════════════════════════════
   USER MODAL
════════════════════════════════ */
function showUM(){ const s=DB.session(); if(!s)return; document.getElementById('um-ava').textContent=s.ava||s.name[0]; document.getElementById('um-name').textContent=s.name; document.getElementById('um-email').textContent=s.email; document.getElementById('um-modal').classList.add('open'); }
function closeUM(){ document.getElementById('um-modal').classList.remove('open'); }

/* ════════════════════════════════
   EDUKASI
════════════════════════════════ */
function searchGoogle(){ const q=document.getElementById('edu-q')?.value?.trim(); if(!q){ toast('Masukkan kata kunci','warn'); return; } window.open('https://www.google.com/search?q='+encodeURIComponent(q),'_blank'); }
function qSearch(q){ if(document.getElementById('edu-q')) document.getElementById('edu-q').value=q; window.open('https://www.google.com/search?q='+encodeURIComponent(q),'_blank'); }

/* ════════════════════════════════
   CONTACT
════════════════════════════════ */
function sendContact(){ const n=document.getElementById('ct-name')?.value?.trim(); const e=document.getElementById('ct-email')?.value?.trim(); const m=document.getElementById('ct-msg')?.value?.trim(); if(!n||!e||!m){ toast('Lengkapi semua kolom','warn'); return; } toast('Pesan terkirim! Tim kami akan membalas segera'); document.getElementById('ct-name').value=''; document.getElementById('ct-email').value=''; document.getElementById('ct-msg').value=''; }

/* ════════════════════════════════
   DOCTORS DATA — dulu array hardcode, sekarang fetch dari Firestore
════════════════════════════════ */
let DOCTORS=[];
let _doctorsLoading=null;
function loadDoctors(){
  if(DOCTORS.length) return Promise.resolve(DOCTORS);
  if(!_doctorsLoading){
    _doctorsLoading = window.fetchDoctorsList ? window.fetchDoctorsList().then(list=>{ DOCTORS=list; return DOCTORS; }) : Promise.resolve([]);
  }
  return _doctorsLoading;
}

/* ════════════════════════════════
   LAYANAN / APPOINTMENT
════════════════════════════════ */
let layStep=1, selDocId=null;

function resetLay(){
  layStep=1; selDocId=null;
  ['p-nama','p-dob','p-usia','p-hamil','p-telp','j-tgl','j-keluhan'].forEach(id=>{ const el=document.getElementById(id); if(el) el.value=''; });
  ['p-gender','j-jam','j-rs'].forEach(id=>{ const el=document.getElementById(id); if(el) el.selectedIndex=0; });
  const td=new Date().toISOString().split('T')[0]; const jt=document.getElementById('j-tgl'); if(jt) jt.min=td;
  document.getElementById('lay-s1').style.display='block';
  document.getElementById('lay-s2').style.display='none';
  document.getElementById('lay-s3').style.display='none';
  document.getElementById('lay-confirm').style.display='none';
  updateSteps(1);
}

function updateSteps(cur){
  for(let i=1;i<=3;i++){
    const sc=document.getElementById('sc'+i); const sl=document.getElementById('sl'+i);
    if(!sc) continue;
    sc.className='step-circle '+(i<cur?'done':i===cur?'cur':'todo');
    sl.className='step-lbl'+(i===cur?' cur':'');
  }
  for(let i=1;i<=2;i++){ const sl=document.getElementById('sline'+i); if(sl) sl.className='step-line '+(cur>i?'done':''); }
}

function autoAge(){ const v=document.getElementById('p-dob')?.value; if(!v) return; const b=new Date(v),n=new Date(); let y=n.getFullYear()-b.getFullYear(),m=n.getMonth()-b.getMonth(); if(m<0){y--;m+=12;} const el=document.getElementById('p-usia'); if(el) el.value=y>0?y+' tahun'+(m?' '+m+' bln':''):m+' bulan'; }

function layErr(id,msg){ const el=document.getElementById(id); const er=document.getElementById(id+'-e'); if(el) el.classList.add('err'); if(er){er.textContent=msg;er.classList.add('show');} }
function layClear(id){ const el=document.getElementById(id); const er=document.getElementById(id+'-e'); if(el) el.classList.remove('err'); if(er) er.classList.remove('show'); }

async function layNext(n){
  if(n===2){
    const nm=document.getElementById('p-nama')?.value?.trim();
    const db=document.getElementById('p-dob')?.value;
    const gn=document.getElementById('p-gender')?.value;
    const tp=document.getElementById('p-telp')?.value?.trim();
    let ok=true;
    if(!nm){ layErr('p-nama','Nama wajib diisi'); ok=false; } else layClear('p-nama');
    if(!db){ layErr('p-dob','Tanggal lahir wajib diisi'); ok=false; } else layClear('p-dob');
    if(!gn){ layErr('p-gender','Pilih jenis kelamin'); ok=false; } else layClear('p-gender');
    if(!tp){ layErr('p-telp','No. telepon wajib diisi'); ok=false; } else layClear('p-telp');
    if(!ok) return;
    document.getElementById('lay-s1').style.display='none';
    document.getElementById('lay-s2').style.display='block';
    updateSteps(2); window.scrollTo({top:0,behavior:'smooth'});
  } else if(n===3){
    const tg=document.getElementById('j-tgl')?.value;
    const jm=document.getElementById('j-jam')?.value;
    const rs=document.getElementById('j-rs')?.value;
    let ok=true;
    if(!tg){ layErr('j-tgl','Tanggal wajib dipilih'); ok=false; } else layClear('j-tgl');
    if(!jm){ layErr('j-jam','Jam wajib dipilih'); ok=false; } else layClear('j-jam');
    if(!rs){ layErr('j-rs','Pilih rumah sakit'); ok=false; } else layClear('j-rs');
    if(!ok) return;
    document.getElementById('lay-s2').style.display='none';
    document.getElementById('lay-s3').style.display='block';
    updateSteps(3);
    document.getElementById('lay-dok-grid').innerHTML='<div style="padding:20px;text-align:center;color:var(--gray);">Memuat daftar dokter...</div>';
    await loadDoctors();
    renderDokter(rs);
    window.scrollTo({top:0,behavior:'smooth'});
  } else if(n===1){
    document.getElementById('lay-s2').style.display='none';
    document.getElementById('lay-s1').style.display='block';
    updateSteps(1); window.scrollTo({top:0,behavior:'smooth'});
  } else if(n===2 && layStep===3){
    document.getElementById('lay-s3').style.display='none';
    document.getElementById('lay-s2').style.display='block';
    updateSteps(2); window.scrollTo({top:0,behavior:'smooth'});
  }
  layStep=n;
}

function renderDokter(rs){
  document.getElementById('lay-rs-label').textContent='Pilih dokter untuk '+rs.split('–')[0].trim()+':';
  document.getElementById('lay-dok-grid').innerHTML=DOCTORS.map(d=>`
    <div class="dok-card ${selDocId===d.id?'chosen':''}" id="dc_${d.id}" onclick="selectDok('${d.id}')">
      <div class="dok-ava">${d.icon}</div>
      <div class="dok-name">${d.name}</div>
      <div class="dok-spec">${d.spec}</div>
      <div class="dok-rating"><span class="material-symbols-rounded">star</span> ${d.rating} <span style="color:var(--gray2);font-weight:400;">(${d.rev})</span></div>
      <div class="dok-sched"><span class="material-symbols-rounded">schedule</span> <strong>Jadwal:</strong> ${d.avail}<br><span class="material-symbols-rounded">local_hospital</span> RS ${d.rs} · ${d.exp}<br><em style="font-size:.72rem;">${d.bio.substring(0,70)}...</em></div>
      <button class="btn btn-primary btn-full btn-sm" onclick="event.stopPropagation();selectDok('${d.id}')">${selDocId===d.id?'<span class="material-symbols-rounded">check_circle</span> Dipilih':'<span class="material-symbols-rounded">calendar_month</span> Pilih Dokter'}</button>
    </div>`).join('');
}

function selectDok(id){
  selDocId=id;
  const doc=DOCTORS.find(d=>d.id===id); if(!doc) return;
  document.querySelectorAll('.dok-card').forEach(c=>c.classList.remove('chosen'));
  document.querySelectorAll('.dok-card button').forEach(b=>{ b.innerHTML='<span class="material-symbols-rounded">calendar_month</span> Pilih Dokter'; });
  const card=document.getElementById('dc_'+id);
  if(card){ card.classList.add('chosen'); const btn=card.querySelector('button'); if(btn) btn.innerHTML='<span class="material-symbols-rounded">check_circle</span> Dipilih'; }
  showConfirm(doc);
}

function showConfirm(doc){
  document.getElementById('lay-confirm').style.display='block';
  document.getElementById('cf-dok-icon').innerHTML=doc.icon;
  document.getElementById('cf-dok-name').textContent=doc.name;
  document.getElementById('cf-dok-spec').textContent=doc.spec;
  const nm=document.getElementById('p-nama')?.value||'–';
  const db=document.getElementById('p-dob')?.value;
  const gn=document.getElementById('p-gender')?.value||'–';
  const us=document.getElementById('p-usia')?.value||'–';
  const hm=document.getElementById('p-hamil')?.value||'';
  const tp=document.getElementById('p-telp')?.value||'–';
  const tg=document.getElementById('j-tgl')?.value;
  const jm=document.getElementById('j-jam')?.value||'–';
  const rs=document.getElementById('j-rs')?.value||'–';
  const kl=document.getElementById('j-keluhan')?.value||'Tidak ada catatan';
  document.getElementById('cf-nama').textContent=nm;
  document.getElementById('cf-dob').textContent=fmtDate(db);
  document.getElementById('cf-gender').textContent=gn;
  document.getElementById('cf-usia').textContent=us;
  document.getElementById('cf-telp').textContent=tp;
  document.getElementById('cf-tgl').textContent=fmtDate(tg);
  document.getElementById('cf-jam').textContent=jm;
  document.getElementById('cf-rs').textContent=rs;
  document.getElementById('cf-keluhan').textContent=kl;
  document.getElementById('cf-dokter').textContent=doc.name+' ('+doc.spec+')';
  if(hm){ document.getElementById('cf-hamil').textContent=hm; document.getElementById('cf-hamil-row').style.display='flex'; } else document.getElementById('cf-hamil-row').style.display='none';
  document.getElementById('lay-confirm').scrollIntoView({behavior:'smooth',block:'start'});
}

async function submitBooking(){
  if(!selDocId){ toast('Pilih dokter terlebih dahulu','warn'); return; }
  const doc=DOCTORS.find(d=>d.id===selDocId);
  const s=DB.session();
  if(!s?.uid){ toast('Sesi login bermasalah, coba login ulang','fail'); return; }
  // Status awal 'menunggu_konfirmasi' — RS/Posyandu belum menyetujui & belum kirim
  // kode antrian. Untuk sekarang proses konfirmasinya masih manual (lihat catatan
  // di bkStatus()/bkDetailRows() di bawah).
  const bk={ patientId:s.uid, userName:s.name, pasien:document.getElementById('p-nama')?.value, dob:document.getElementById('p-dob')?.value, gender:document.getElementById('p-gender')?.value, usia:document.getElementById('p-usia')?.value, hamil:document.getElementById('p-hamil')?.value, telp:document.getElementById('p-telp')?.value, tgl:document.getElementById('j-tgl')?.value, jam:document.getElementById('j-jam')?.value, rs:document.getElementById('j-rs')?.value, keluhan:document.getElementById('j-keluhan')?.value, docId:doc.id, docName:doc.name, docSpec:doc.spec, docIcon:doc.icon, status:'menunggu_konfirmasi', kodeAntrian:null };

  let bookingId;
  try{
    bookingId = await window.saveAppointment(bk);
  } catch(err){
    console.error('Gagal simpan booking ke Firestore:', err);
    toast('Booking gagal disimpan, coba lagi','fail');
    return;
  }

  const h=bk.hamil?`<div class="confirm-row"><span class="ck"><span class="material-symbols-rounded">pregnant_woman</span> Status Hamil</span><span class="cv">${bk.hamil}</span></div>`:'';
  document.getElementById('success-detail').innerHTML=`
    <div style="background:var(--teal-pale);border-radius:var(--r);padding:14px;margin-bottom:16px;display:flex;align-items:center;gap:11px;"><span style="font-size:1.6rem;">${doc.icon}</span><div><div style="font-weight:700;color:var(--navy);">${doc.name}</div><div style="font-size:.8rem;color:var(--gray);">${doc.spec}</div></div></div>
    <div class="confirm-row"><span class="ck"><span class="material-symbols-rounded">person</span> Pasien</span><span class="cv">${bk.pasien}</span></div>
    <div class="confirm-row"><span class="ck"><span class="material-symbols-rounded">smartphone</span> Telepon</span><span class="cv">${bk.telp}</span></div>
    <div class="confirm-row"><span class="ck"><span class="material-symbols-rounded">calendar_month</span> Tanggal</span><span class="cv">${fmtDate(bk.tgl)}</span></div>
    <div class="confirm-row"><span class="ck"><span class="material-symbols-rounded">alarm</span> Jam</span><span class="cv">${bk.jam}</span></div>
    <div class="confirm-row"><span class="ck"><span class="material-symbols-rounded">local_hospital</span> Rumah Sakit</span><span class="cv">${bk.rs}</span></div>
    ${h}
    <div class="confirm-row"><span class="ck">🆔 ID Booking</span><span class="cv" style="font-family:monospace;color:var(--teal);font-size:.78rem;">${bookingId}</span></div>`;
  toast('Booking berhasil dikonfirmasi! Menunggu konfirmasi RS/Posyandu.');
  // simpan manual dulu supaya popup konfirmasi bisa baca datanya tanpa
  // nunggu renderMyBookings() jalan (itu baru kepanggil pas balik ke dashboard)
  window._myBookings = [{ ...bk, id: bookingId }, ...(window._myBookings||[])];
  setTimeout(()=>{
    goPage('success');
    // popup konfirmasi cuma dimunculin sekali di sini, bukan tiap buka dashboard
    showBookingDetail(bookingId);
  },700);
}

function fmtDate(iso){ if(!iso) return '–'; return new Date(iso).toLocaleDateString('id-ID',{day:'numeric',month:'long',year:'numeric'}); }

/* ════════════════════════════════
   JADWAL BOOKING DI DASHBOARD
════════════════════════════════ */
function closeBookingPopup(){ document.getElementById('bk-modal')?.classList.remove('open'); }

// Notice "menunggu konfirmasi RS" — cuma tampil kalau statusnya masih
// menunggu_konfirmasi. Begitu status berubah jadi confirmed/selesai/dst,
// notice ini otomatis hilang, digantikan baris kode antrian.
function bkDetailRows(bk){
  const h=bk.hamil?`<div class="confirm-row"><span class="ck"><span class="material-symbols-rounded">pregnant_woman</span> Status Hamil</span><span class="cv">${bk.hamil}</span></div>`:'';
  const kode=bk.kodeAntrian?`<div class="confirm-row"><span class="ck"><span class="material-symbols-rounded">confirmation_number</span> Kode Antrian</span><span class="cv" style="color:var(--teal);font-weight:700;">${bk.kodeAntrian}</span></div>`:'';
  const notice = bk.status==='menunggu_konfirmasi'
    ? `<div class="bk-notice"><span class="material-symbols-rounded">schedule</span> Booking Anda sedang menunggu konfirmasi dari pihak Rumah Sakit/Posyandu. Proses ini biasanya memakan waktu <strong>2–24 jam</strong>. Kode antrian akan dikirimkan melalui <strong>email</strong> yang terdaftar setelah dikonfirmasi.</div>`
    : '';
  return `
    ${notice}
    <div class="confirm-row"><span class="ck"><span class="material-symbols-rounded">person</span> Pasien</span><span class="cv">${bk.pasien||'-'}</span></div>
    <div class="confirm-row"><span class="ck"><span class="material-symbols-rounded">calendar_month</span> Tanggal</span><span class="cv">${fmtDate(bk.tgl)}</span></div>
    <div class="confirm-row"><span class="ck"><span class="material-symbols-rounded">alarm</span> Jam</span><span class="cv">${bk.jam||'-'}</span></div>
    <div class="confirm-row"><span class="ck"><span class="material-symbols-rounded">local_hospital</span> Rumah Sakit</span><span class="cv">${bk.rs||'-'}</span></div>
    ${h}
    ${kode}
    <div class="confirm-row"><span class="ck"><span class="material-symbols-rounded">smartphone</span> Telepon</span><span class="cv">${bk.telp||'-'}</span></div>
    <div class="confirm-row"><span class="ck">🆔 ID Booking</span><span class="cv" style="font-family:monospace;color:var(--teal);font-size:.78rem;">${bk.id}</span></div>`;
}

function isTanggalLewat(bk){
  if(!bk.tgl) return false;
  const t=new Date(bk.tgl); t.setHours(23,59,59,999);
  return t < new Date();
}

// status beneran dibaca dari field di firestore, bukan ditebak dari tanggal.
// yang tanggalnya udah lewat tapi belum ditandai dokter = masih menggantung,
// jangan langsung diaku "selesai".
//
// 'menunggu_konfirmasi' & 'confirmed' terkait fitur konfirmasi RS/Posyandu —
// untuk sekarang kedua status ini diubah manual lewat Firestore Console
// (belum ada dashboard admin RS), lihat catatan project.
function bkStatus(bk){
  if(bk.status==='selesai')             return {key:'selesai',   label:'Selesai',                cls:'bg-green'};
  if(bk.status==='tidak_hadir')         return {key:'batal',     label:'Tidak Hadir',            cls:'bg-red'};
  if(bk.status==='confirmed')           return {key:'confirmed', label:'Terkonfirmasi',          cls:'bg-teal'};
  if(bk.status==='menunggu_konfirmasi') return {key:'menunggu',  label:'Menunggu Konfirmasi RS', cls:'bg-amber'};
  if(isTanggalLewat(bk))                return {key:'menunggu',  label:'Menunggu konfirmasi',    cls:'bg-amber'};
  return {key:'akan',                   label:'Terjadwal',       cls:'bg-green'};
}

// dianggap kelar kalau dokter udah nandain, bukan cuma gara-gara tanggal lewat
function isBookingKelar(bk){ const k=bkStatus(bk).key; return k==='selesai'||k==='batal'; }

function bkCardHtml(bk){
  const st=bkStatus(bk);
  const lewat=st.key!=='akan';
  const kodeHtml = bk.kodeAntrian
    ? `<div class="bk-rs" style="color:var(--teal);font-weight:700;"><span class="material-symbols-rounded">confirmation_number</span> Kode Antrian: ${bk.kodeAntrian}</div>`
    : '';
  return `
    <div class="bk-card${lewat?' past':''}">
      <div class="bk-card-hd">
        <div class="bk-ava">${bk.docIcon||'<span class="material-symbols-rounded">medical_services</span>'}</div>
        <div style="flex:1;min-width:0;">
          <div class="bk-doc">${bk.docName||'-'}</div>
          <div class="bk-spec">${bk.docSpec||''}</div>
        </div>
        <span class="badge ${st.cls}">${st.label}</span>
      </div>
      <div class="bk-when">
        <span><span class="material-symbols-rounded">calendar_month</span> ${fmtDate(bk.tgl)}</span>
        <span><span class="material-symbols-rounded">alarm</span> ${bk.jam||'-'}</span>
      </div>
      <div class="bk-rs"><span class="material-symbols-rounded">location_on</span> ${bk.rs||'-'}</div>
      ${kodeHtml}
      <button class="btn btn-secondary btn-sm btn-full" onclick="showBookingDetail('${bk.id}')"><span class="material-symbols-rounded">article</span> Lihat Detail</button>
    </div>`;
}

const BK_PREVIEW = 3; // di dashboard cuma 3 dulu, sisanya lewat "Lihat Semua"

// ambil dari firestore sekali, simpan buat dipakai dashboard & halaman jadwal
async function loadMyBookings(){
  const s=DB.session();
  if(!s?.uid || getRole()==='dokter' || !window.fetchMyAppointments) return [];
  try{
    window._myBookings = await window.fetchMyAppointments(s.uid);
  } catch(err){
    console.error('Gagal ambil daftar booking:', err);
    window._myBookings = window._myBookings || [];
  }
  return window._myBookings;
}

async function renderMyBookings(){
  const sec=document.getElementById('my-bookings-sec');
  const list=document.getElementById('my-bookings-list');
  if(!sec||!list) return;

  const items=await loadMyBookings();
  if(!items.length){ sec.style.display='none'; return; } // belum pernah booking

  sec.style.display='block';
  // yang akan datang ditaruh duluan, sisanya yang udah lewat
  const urut=[...items].sort((a,b)=>Number(isBookingKelar(a))-Number(isBookingKelar(b)));
  list.innerHTML=urut.slice(0,BK_PREVIEW).map(bkCardHtml).join('');

  // tombolnya selalu ada — halaman jadwal tetap kepake buat misahin
  // yang akan datang & yang udah selesai, walau bookingnya baru sedikit
}

// halaman "Lihat Semua" — dipisah jadi Akan Datang & Selesai
async function renderJadwalPage(){
  const items=await loadMyBookings();
  const upcoming=items.filter(b=>!isBookingKelar(b));
  const finished=items.filter(isBookingKelar);

  const paint=(listId,countId,arr,kosong)=>{
    const list=document.getElementById(listId);
    const cnt=document.getElementById(countId);
    if(cnt) cnt.textContent=arr.length;
    if(!list) return;
    list.innerHTML = arr.length
      ? arr.map(bkCardHtml).join('')
      : `<div class="bk-empty">${kosong}</div>`;
  };
  paint('jd-upcoming-list','jd-upcoming-count',upcoming,'Belum ada jadwal yang akan datang.');
  paint('jd-finished-list','jd-finished-count',finished,'Belum ada konsultasi yang sudah ditandai selesai oleh dokter.');
}

// ── SISI DOKTER: kelola appointment yang masuk ──
function docCardHtml(bk){
  const st=bkStatus(bk);
  const sudah=isBookingKelar(bk);
  const aksi = sudah
    ? `<button class="btn btn-ghost btn-sm btn-full" onclick="setAppointmentStatus('${bk.id}','confirmed')">Batalkan penandaan</button>`
    : `<div class="bk-actions">
         <button class="btn btn-primary btn-sm" onclick="setAppointmentStatus('${bk.id}','selesai')"><span class="material-symbols-rounded">check_circle</span> Selesai</button>
         <button class="btn btn-secondary btn-sm" onclick="setAppointmentStatus('${bk.id}','tidak_hadir')"><span class="material-symbols-rounded">error</span> Tidak Hadir</button>
       </div>`;
  return `
    <div class="bk-card${sudah?' past':''}">
      <div class="bk-card-hd">
        <div class="bk-ava"><span class="material-symbols-rounded">person</span></div>
        <div style="flex:1;min-width:0;">
          <div class="bk-doc">${bk.pasien||'-'}</div>
          <div class="bk-spec">${bk.usia||''}${bk.gender?' · '+bk.gender:''}</div>
        </div>
        <span class="badge ${st.cls}">${st.label}</span>
      </div>
      <div class="bk-when">
        <span><span class="material-symbols-rounded">calendar_month</span> ${fmtDate(bk.tgl)}</span>
        <span><span class="material-symbols-rounded">alarm</span> ${bk.jam||'-'}</span>
      </div>
      <div class="bk-rs"><span class="material-symbols-rounded">location_on</span> ${bk.rs||'-'}</div>
      <div class="bk-patient"><span class="material-symbols-rounded">smartphone</span> ${bk.telp||'-'}</div>
      ${aksi}
    </div>`;
}

async function renderDoctorAppointments(){
  const s=DB.session();
  if(!s?.uid || !window.fetchDoctorAppointments) return;
  try{
    window._docAppointments = await window.fetchDoctorAppointments(s.uid);
  } catch(err){
    console.error('Gagal ambil appointment dokter:', err);
    window._docAppointments = [];
  }
  const items=window._docAppointments;
  const todo=items.filter(b=>!isBookingKelar(b));
  const done=items.filter(isBookingKelar);

  const paint=(listId,countId,arr,kosong)=>{
    const list=document.getElementById(listId), cnt=document.getElementById(countId);
    if(cnt) cnt.textContent=arr.length;
    if(!list) return;
    list.innerHTML = arr.length ? arr.map(docCardHtml).join('')
      : `<div class="bk-empty">${kosong}</div>`;
  };
  paint('dj-todo-list','dj-todo-count',todo,'Belum ada appointment yang perlu ditindaklanjuti.');
  paint('dj-done-list','dj-done-count',done,'Belum ada appointment yang ditandai.');
}

async function setAppointmentStatus(id,status){
  if(!window.updateAppointmentStatus) return;
  try{
    await window.updateAppointmentStatus(id,status);
    const label={selesai:'selesai',tidak_hadir:'tidak hadir',confirmed:'dikembalikan ke terjadwal'}[status]||status;
    toast('Appointment ditandai '+label);
    renderDoctorAppointments();
  } catch(err){
    console.error('Gagal ubah status appointment:', err);
    toast('Gagal mengubah status. Coba lagi.','fail');
  }
}

function showBookingDetail(id){
  const bk=(window._myBookings||[]).find(b=>b.id===id);
  const body=document.getElementById('bk-modal-body');
  if(!bk||!body) return;
  body.innerHTML=`
    <div style="background:var(--teal-pale);border-radius:var(--r);padding:14px;margin-bottom:14px;display:flex;align-items:center;gap:11px;">
      <span style="font-size:1.6rem;">${bk.docIcon||''}</span>
      <div><div style="font-weight:700;color:var(--navy);">${bk.docName||'-'}</div><div style="font-size:.8rem;color:var(--gray);">${bk.docSpec||''}</div></div>
    </div>
    ${bkDetailRows(bk)}`;
  document.getElementById('bk-modal')?.classList.add('open');
}

/* ════════════════════════════════
   CHAT / KONSULTASI → sekarang pakai Firestore real (lihat script Firebase
   di bagian bawah file: window.renderPatientConsultList, window.openPatientConsultation,
   window.sendPatientMessageFn, window.submitPreConsultForm)
════════════════════════════════ */
function renderPatientConsultList(){ window.renderPatientConsultList_impl && window.renderPatientConsultList_impl(); }

function sendChat(){
  const role=getRole();
  if(role==='dokter'){ window.sendDoctorReply && window.sendDoctorReply(); return; }
  window.sendPatientMessageFn && window.sendPatientMessageFn();
}

function chatEnter(e){ if(e.key==='Enter'&&!e.shiftKey){ e.preventDefault(); sendChat(); } }
function autoH(el){ el.style.height='auto'; el.style.height=Math.min(el.scrollHeight,120)+'px'; }
function nowTime(){ return new Date().toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'}); }

/* ════════════════════════════════
   FORM PRA-KONSUL
════════════════════════════════ */
function resetPreConsult(){
  ['pc-nama','pc-dob','pc-usia','pc-tb','pc-bb','pc-penyakit'].forEach(id=>{ const el=document.getElementById(id); if(el) el.value=''; });
  ['pc-gender','pc-asi','pc-topik'].forEach(id=>{ const el=document.getElementById(id); if(el) el.selectedIndex=0; });
  const errEl=document.getElementById('pc-err'); if(errEl) errEl.classList.remove('show');
  const td=new Date().toISOString().split('T')[0];
  const dobEl=document.getElementById('pc-dob'); if(dobEl) dobEl.max=td;
}

function pcAutoAge(){
  const v=document.getElementById('pc-dob')?.value; if(!v) return;
  const b=new Date(v),n=new Date();
  const m=(n.getFullYear()-b.getFullYear())*12+(n.getMonth()-b.getMonth());
  const el=document.getElementById('pc-usia'); if(el) el.value=m+' bulan';
}

function submitPreConsult(){
  const errEl=document.getElementById('pc-err');
  errEl.classList.remove('show');

  const data={
    childName: document.getElementById('pc-nama')?.value?.trim(),
    dob: document.getElementById('pc-dob')?.value,
    gender: document.getElementById('pc-gender')?.value,
    usia: document.getElementById('pc-usia')?.value,
    height: parseFloat(document.getElementById('pc-tb')?.value),
    weight: parseFloat(document.getElementById('pc-bb')?.value),
    asi: document.getElementById('pc-asi')?.value || '',
    sanitasi: document.getElementById('pc-sanitasi')?.value || 'baik',
    riwayatPenyakitAlergi: document.getElementById('pc-penyakit')?.value?.trim() || '',
    ekonomi: document.getElementById('pc-ekonomi')?.value || 'cukup',
    giziIbu: document.getElementById('pc-gizi-ibu')?.value || 'baik',
    topik: document.getElementById('pc-topik')?.value
  };

  if(!data.childName || !data.dob || !data.gender || isNaN(data.height) || isNaN(data.weight) || !data.topik){
    errEl.textContent='Lengkapi semua kolom bertanda * terlebih dahulu.';
    errEl.classList.add('show');
    return;
  }

  const btn=document.getElementById('pc-submit-btn');
  btn.disabled=true; const btnHtml=btn.innerHTML; btn.innerHTML='<span class="material-symbols-rounded">hourglass_empty</span> Mencari dokter yang tersedia...';

  window.submitPreConsultForm(data).then((consultationId)=>{
    if(!consultationId){
      btn.disabled=false; btn.innerHTML=btnHtml;
      errEl.textContent='Tidak ada dokter yang tersedia untuk topik ini saat ini. Coba lagi beberapa saat lagi.';
      errEl.classList.add('show');
      return;
    }
    toast('Dokter ditemukan! Menghubungkan Anda ke sesi konsultasi...');
    goPage('chat');
    setTimeout(()=>{ window.openPatientConsultation(consultationId); btn.disabled=false; btn.innerHTML=btnHtml; }, 400);
  }).catch((err)=>{
    console.error(err);
    btn.disabled=false; btn.innerHTML=btnHtml;
    errEl.textContent='Terjadi kesalahan. Coba lagi.';
    errEl.classList.add('show');
  });
}

/* ════════════════════════════════
   INIT
════════════════════════════════ */

// biar onclick="..." dkk di markup lama masih bisa manggil fungsi ini —
// harus dijalanin duluan, sebelum blok di bawah yang bisa return lebih awal
if (typeof window !== 'undefined') {
  Object.assign(window, { toast, getRole, goPage, closeBookingPopup, renderMyBookings, renderJadwalPage, showBookingDetail, renderDoctorAppointments, setAppointmentStatus, applyRoleUI, syncUI, scrollTo2, toggleAppLauncher, closeAppLauncher, alGo, alGoSection, doLogout, showUM, closeUM, searchGoogle, qSearch, sendContact, resetLay, updateSteps, autoAge, layErr, layClear, layNext, renderDokter, selectDok, showConfirm, submitBooking, fmtDate, renderPatientConsultList, sendChat, chatEnter, autoH, nowTime, resetPreConsult, pcAutoAge, submitPreConsult });
}

{
  if(DB.session()){
    applyRoleUI();
    goPage(getRole()==='dokter' ? 'chat' : 'dash');
  } else {
    window.location.href='/';
    return;
  }
  const td=new Date().toISOString().split('T')[0];
  const jt=document.getElementById('j-tgl'); if(jt) jt.min=td;
  // Init Google OAuth after GSI library loads
  // Google Sign-In hanya dipakai di login.html, tidak dibutuhkan di sini.
}
}