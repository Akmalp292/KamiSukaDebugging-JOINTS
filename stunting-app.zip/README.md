# StuntingCare (Vite + React)

Pecahan dari versi HTML statis (index, login, main, kebijakan-privasi, syarat-ketentuan) jadi project Vite + React.

## Struktur

- `src/pages/*.jsx` — satu komponen per halaman lama. Markup dikonversi ke JSX (className, self-closing, dst) tapi id/class dipertahankan sama biar CSS & JS lama tetap nempel.
- `src/styles/*.css` — CSS tiap halaman (dulu `<style>` inline), diimpor komponennya masing-masing.
- `src/legacy/*.legacy.js` — script lama tiap halaman, dibungkus `init()` dan dipanggil dari `useEffect` pas komponen mount. Fungsi yang dipanggil lewat `onclick="..."` dkk tetap ditulis apa adanya dan diekspos ke `window`.
- `src/legacy/*.firebase.js` — script Firebase (module), diimpor sebagai side-effect.
- `/` = **landing page + login digabung**: hero "Wujudkan Generasi" & "Fasilitas Kesehatan Terpercaya" (dulu di dashboard) sekarang di sini, form Masuk/Daftar nempel di bawahnya. `LoginPage.jsx` lama udah gak dipakai, `/login` cuma redirect ke `/`.
- Dashboard (`/main`) sekarang mulai dari "Layanan Unggulan" — Edukasi, Resep Menu, Kontak, Footer tetap di sana.
- Daftar jadwal booking tampil di dashboard (3 teratas) + halaman "Lihat Semua" yang misahin Akan Datang / Selesai.
- Status appointment disimpan beneran di Firestore (`confirmed` / `selesai` / `tidak_hadir`), **bukan** ditebak dari tanggal. Yang nandain cuma dokter, lewat halaman "Appointment Pasien" di app launcher. Booking yang tanggalnya lewat tapi belum ditandai dokter statusnya "Menunggu konfirmasi".
- Navigasi antar halaman pakai React Router. Di dalam MainPage, pindah dashboard/layanan/chat masih pakai cara lama (toggle `.page.active`), gak diganti route baru.
- `server/` — Express + MySQL (`server.js`) dan script admin Firebase, dipindah aja gak diubah (gak dipakai frontend lagi, lihat poin Firebase di bawah).

## Data — semuanya di Firebase sekarang

- **Akun pasien**: Firebase Auth + Firestore `patients` (dulu localStorage). Register, login, Google Sign-In, verifikasi kode email — semua nulis/baca ke Firestore.
- **Akun dokter**: Firebase Auth + Firestore `doctors` (sudah dari awal begini, gak diubah).
- **Dokter yang muncul di halaman Layanan/booking & chat**: sekarang fetch dari Firestore `doctors` (dulu array 6 dokter fiktif yang di-hardcode di kode).
- **Booking appointment**: Firestore `appointments` (dulu localStorage).
- **Chat/konsultasi**: Firestore `consultations` + subcollection `messages`, real-time (sudah dari awal begini di halaman utama).
- Satu-satunya yang masih di localStorage: cache "siapa yang lagi login" (`sc_s`) — ini cuma pointer ke akun Firebase yang aktif, bukan data aslinya.

## Chatbot

Tombol bulat di kanan bawah tiap halaman. UI-nya di `src/components/ChatBot.jsx`,
tapi **yang perlu diubah pas model siap cuma `src/lib/chatbotBackend.js`** —
tinggal isi `VITE_CHATBOT_ENDPOINT` di `.env` (contohnya ada di `.env.example`),
atau ganti isi fungsi `askChatbot()` kalau mau panggil model dengan cara lain.
Selama endpoint kosong, bot balas pesan placeholder biar UI tetap bisa dites.

## Yang perlu kamu kerjain

- **Publish `server/database/firebase-admin/firestore.rules` ke Firebase Console.** Ada rule buat `patients` & `appointments` — kalau belum di-publish, semua fitur di atas bakal ditolak Firestore (permission denied). Rules-nya diupdate lagi pas nambah fitur status appointment, jadi **publish ulang** kalau sempat di-publish sebelum itu.
- Aktifin **Google** di Firebase Console → Authentication → Sign-in method (login Google sekarang pakai popup Firebase, bukan Google Identity Services).
- Fitur **Stunting Checker dihapus** total (kartu, halaman, hitungan Z-Score, rules). Route `/index-lama` ikut dicabut karena halaman itu duplikat basi yang masih nyimpen fitur tsb — file `IndexPage.jsx` & `index.legacy.js` jadi nganggur, boleh dihapus manual.
- Kunci EmailJS masih placeholder (kode verifikasi email masih tampil di layar, mode dev).
- `serviceAccountKey.json` ikut ke-copy, udah masuk `.gitignore` — jangan sampai ke-commit ke repo publik.
- `server/` (Express + MySQL) sekarang nganggur, gak dipanggil dari frontend manapun. Kalau gak dipakai, boleh dihapus; kalau mau dipakai lagi, bilang buat apa.

## Jalanin

```bash
npm install
npm run dev
npm run build
```

Backend (opsional):
```bash
cd server
npm install
node server.js
```
