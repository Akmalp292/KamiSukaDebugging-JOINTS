const { initializeApp, cert } = require('firebase-admin/app');
const { getFirestore } = require('firebase-admin/firestore');
const serviceAccount = require('./serviceAccountKey.json');

initializeApp({
  credential: cert(serviceAccount)
});

const db = getFirestore();
db.settings({ preferRest: true });

async function run(){
  console.log('Mengubah status semua dokter jadi "online"...\n');
  const snap = await db.collection('doctors').get();

  if (snap.empty) {
    console.log('Collection "doctors" kosong.');
    process.exit(1);
  }

  const batch = db.batch();
  snap.forEach((docSnap) => {
    const data = docSnap.data();
    batch.update(docSnap.ref, { status: 'online' });
    console.log('  + ' + data.name + '  ->  online');
  });

  await batch.commit();
  console.log('\nSelesai! Semua dokter sekarang online.');
  process.exit(0);
}

run().catch((err) => {
  console.error('Gagal:', err);
  process.exit(1);
});