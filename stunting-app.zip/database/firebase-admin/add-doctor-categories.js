const { initializeApp, cert } = require('firebase-admin/app');
const { getFirestore } = require('firebase-admin/firestore');
const serviceAccount = require('./serviceAccountKey.json');

initializeApp({
  credential: cert(serviceAccount)
});

const db = getFirestore();
// Paksa pakai REST (HTTP biasa) alih-alih gRPC streaming — menghindari
// masalah koneksi yang sering terjadi di jaringan kampus/WiFi publik/antivirus
// yang memblokir atau mengganggu koneksi gRPC streaming.
db.settings({ preferRest: true });

// Pemetaan email dokter -> kategori umum (dipakai untuk matching Topik Konsultasi).
// category: 'gizi' | 'anak' | 'kandungan'
const CATEGORY_MAP = {
  'anisa.putri@stuntingcare.id': 'gizi',
  'reza.firmansyah@stuntingcare.id': 'anak',
  'siti.rahmah@stuntingcare.id': 'gizi',
  'budi.santosa@stuntingcare.id': 'gizi',
  'lestari.wulandari@stuntingcare.id': 'kandungan',
  'ahmad.fauzan@stuntingcare.id': 'anak'
};

async function run(){
  console.log('Menambahkan field category ke tiap dokter...\n');
  const snap = await db.collection('doctors').get();

  if (snap.empty) {
    console.log('Collection "doctors" kosong. Jalankan create-doctor-accounts.js dulu.');
    process.exit(1);
  }

  const batch = db.batch();
  let count = 0;

  snap.forEach((docSnap) => {
    const data = docSnap.data();
    const category = CATEGORY_MAP[data.email];
    if (!category) {
      console.log('  (lewati) ' + data.email + ' — tidak ada di pemetaan kategori');
      return;
    }
    batch.update(docSnap.ref, { category });
    console.log('  + ' + data.name + '  ->  category: ' + category);
    count++;
  });

  await batch.commit();
  console.log('\nSelesai! ' + count + ' dokter diberi field category.');
  process.exit(0);
}

run().catch((err) => {
  console.error('Gagal:', err);
  process.exit(1);
});
