const { initializeApp, cert } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const serviceAccount = require('./serviceAccountKey.json');

initializeApp({
  credential: cert(serviceAccount)
});

const db = getFirestore();

const doctors = [
  {
    name: 'dr. Anisa Putri, Sp.GK',
    specialization: 'Spesialis Gizi Klinik',
    photoUrl: null,
    bio: 'Ahli gizi klinik berpengalaman, fokus pada pencegahan dan penatalaksanaan stunting serta malnutrisi pada anak.',
    experienceYears: 10,
    hospital: 'Hermina',
    rating: 4.9,
    reviewCount: 312,
    scheduleText: 'Senin-Jumat 08:00-17:00',
    email: 'anisa.putri@stuntingcare.id',
    status: 'online'
  },
  {
    name: 'dr. Reza Firmansyah, Sp.A',
    specialization: 'Spesialis Anak',
    photoUrl: null,
    bio: 'Dokter spesialis anak dengan keahlian tumbuh kembang dan deteksi dini stunting.',
    experienceYears: 8,
    hospital: 'Persahabatan',
    rating: 4.8,
    reviewCount: 256,
    scheduleText: 'Senin-Sabtu 09:00-16:00',
    email: 'reza.firmansyah@stuntingcare.id',
    status: 'online'
  },
  {
    name: 'dr. Siti Rahmah, Sp.A(K)',
    specialization: 'Konsultan Nutrisi & Tumbuh Kembang',
    photoUrl: null,
    bio: 'Konsultan pediatri bidang nutrisi dan tumbuh kembang, aktif dalam program penurunan stunting nasional.',
    experienceYears: 15,
    hospital: 'Siloam',
    rating: 4.9,
    reviewCount: 189,
    scheduleText: 'Selasa-Jumat 07:00-15:00',
    email: 'siti.rahmah@stuntingcare.id',
    status: 'busy'
  },
  {
    name: 'dr. Budi Santosa, Sp.GK',
    specialization: 'Gizi Klinik & Dietetika',
    photoUrl: null,
    bio: 'Spesialis gizi klinik dengan keahlian penyusunan diet terapeutik untuk anak stunting.',
    experienceYears: 7,
    hospital: 'Hermina',
    rating: 4.7,
    reviewCount: 143,
    scheduleText: 'Rabu-Sabtu 10:00-18:00',
    email: 'budi.santosa@stuntingcare.id',
    status: 'online'
  },
  {
    name: 'dr. Lestari Wulandari, SpOG',
    specialization: 'Kandungan & Kebidanan',
    photoUrl: null,
    bio: 'Spesialis kandungan fokus pada nutrisi ibu hamil dan pencegahan BBLR sejak kehamilan.',
    experienceYears: 12,
    hospital: 'Persahabatan',
    rating: 4.8,
    reviewCount: 198,
    scheduleText: 'Senin-Jumat 08:00-16:00',
    email: 'lestari.wulandari@stuntingcare.id',
    status: 'online'
  },
  {
    name: 'dr. Ahmad Fauzan, Sp.A',
    specialization: 'Spesialis Anak & Remaja',
    photoUrl: null,
    bio: 'Dokter anak spesialis tumbuh kembang remaja dan manajemen gizi kurang pada anak sekolah.',
    experienceYears: 9,
    hospital: 'Siloam',
    rating: 4.6,
    reviewCount: 167,
    scheduleText: 'Senin-Kamis 09:00-17:00',
    email: 'ahmad.fauzan@stuntingcare.id',
    status: 'busy'
  }
];

async function seed() {
  console.log('Mulai seeding data dokter ke Firestore...\n');
  const batch = db.batch();

  doctors.forEach((doc) => {
    const ref = db.collection('doctors').doc();
    batch.set(ref, {
      ...doc,
      createdAt: FieldValue.serverTimestamp()
    });
    console.log('  + ' + doc.name + ' (' + doc.specialization + ')');
  });

  await batch.commit();
  console.log('\nSelesai! ' + doctors.length + ' dokter berhasil ditambahkan ke collection "doctors".');
  process.exit(0);
}

seed().catch((err) => {
  console.error('Gagal seeding:', err);
  process.exit(1);
});
