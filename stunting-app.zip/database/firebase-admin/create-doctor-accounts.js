const { initializeApp, cert } = require('firebase-admin/app');
const { getAuth } = require('firebase-admin/auth');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const serviceAccount = require('./serviceAccountKey.json');

initializeApp({
  credential: cert(serviceAccount)
});

const auth = getAuth();
const db = getFirestore();

// Password default SEMUA dokter untuk login pertama kali.
// Beritahu dokter untuk ganti password ini setelah login pertama
// (fitur ganti password bisa ditambahkan belakangan di dashboard).
const DEFAULT_PASSWORD = 'dokter123';

const doctors = [
  {
    name: 'dr. Anisa Putri, Sp.GK',
    specialization: 'Spesialis Gizi Klinik',
    photoUrl: null,
    bio: 'Ahli gizi klinik berpengalaman, fokus pada pencegahan dan penatalaksanaan stunting serta malnutrisi pada anak.',
    experienceYears: 10,
    hospital: 'Hermina',
    rating: 4.9,
    reviewCount: 312,
    scheduleText: 'Senin-Jumat 08:00-17:00',
    email: 'anisa.putri@stuntingcare.id',
    status: 'offline'
  },
  {
    name: 'dr. Reza Firmansyah, Sp.A',
    specialization: 'Spesialis Anak',
    photoUrl: null,
    bio: 'Dokter spesialis anak dengan keahlian tumbuh kembang dan deteksi dini stunting.',
    experienceYears: 8,
    hospital: 'Persahabatan',
    rating: 4.8,
    reviewCount: 256,
    scheduleText: 'Senin-Sabtu 09:00-16:00',
    email: 'reza.firmansyah@stuntingcare.id',
    status: 'offline'
  },
  {
    name: 'dr. Siti Rahmah, Sp.A(K)',
    specialization: 'Konsultan Nutrisi & Tumbuh Kembang',
    photoUrl: null,
    bio: 'Konsultan pediatri bidang nutrisi dan tumbuh kembang, aktif dalam program penurunan stunting nasional.',
    experienceYears: 15,
    hospital: 'Siloam',
    rating: 4.9,
    reviewCount: 189,
    scheduleText: 'Selasa-Jumat 07:00-15:00',
    email: 'siti.rahmah@stuntingcare.id',
    status: 'offline'
  },
  {
    name: 'dr. Budi Santosa, Sp.GK',
    specialization: 'Gizi Klinik & Dietetika',
    photoUrl: null,
    bio: 'Spesialis gizi klinik dengan keahlian penyusunan diet terapeutik untuk anak stunting.',
    experienceYears: 7,
    hospital: 'Hermina',
    rating: 4.7,
    reviewCount: 143,
    scheduleText: 'Rabu-Sabtu 10:00-18:00',
    email: 'budi.santosa@stuntingcare.id',
    status: 'offline'
  },
  {
    name: 'dr. Lestari Wulandari, SpOG',
    specialization: 'Kandungan & Kebidanan',
    photoUrl: null,
    bio: 'Spesialis kandungan fokus pada nutrisi ibu hamil dan pencegahan BBLR sejak kehamilan.',
    experienceYears: 12,
    hospital: 'Persahabatan',
    rating: 4.8,
    reviewCount: 198,
    scheduleText: 'Senin-Jumat 08:00-16:00',
    email: 'lestari.wulandari@stuntingcare.id',
    status: 'offline'
  },
  {
    name: 'dr. Ahmad Fauzan, Sp.A',
    specialization: 'Spesialis Anak & Remaja',
    photoUrl: null,
    bio: 'Dokter anak spesialis tumbuh kembang remaja dan manajemen gizi kurang pada anak sekolah.',
    experienceYears: 9,
    hospital: 'Siloam',
    rating: 4.6,
    reviewCount: 167,
    scheduleText: 'Senin-Kamis 09:00-17:00',
    email: 'ahmad.fauzan@stuntingcare.id',
    status: 'offline'
  }
];

async function clearOldDoctorDocs() {
  console.log('Menghapus data dokter lama (ID lama, belum terhubung Auth)...');
  const snap = await db.collection('doctors').get();
  const batch = db.batch();
  snap.forEach((doc) => batch.delete(doc.ref));
  if (!snap.empty) await batch.commit();
  console.log('  Selesai hapus ' + snap.size + ' dokumen lama.\n');
}

async function createDoctorAccounts() {
  console.log('Membuat akun Firebase Auth + data Firestore untuk dokter...\n');

  for (const doc of doctors) {
    let userRecord;
    try {
      userRecord = await auth.createUser({
        email: doc.email,
        password: DEFAULT_PASSWORD,
        displayName: doc.name
      });
    } catch (err) {
      if (err.code === 'auth/email-already-exists') {
        userRecord = await auth.getUserByEmail(doc.email);
        console.log('  (akun ' + doc.email + ' sudah ada, pakai yang lama)');
      } else {
        throw err;
      }
    }

    // Simpan dokumen Firestore dengan ID = UID akun Auth-nya.
    // Ini kunci supaya security rules bisa cek "request.auth.uid == doctorId" langsung.
    await db.collection('doctors').doc(userRecord.uid).set({
      ...doc,
      createdAt: FieldValue.serverTimestamp()
    });

    console.log('  + ' + doc.name + '  ->  uid: ' + userRecord.uid);
  }

  console.log('\nSelesai! ' + doctors.length + ' akun dokter siap dipakai.');
  console.log('Password login semua dokter: ' + DEFAULT_PASSWORD);
  console.log('(Sarankan dokter ganti password ini setelah login pertama.)');
}

async function run() {
  await clearOldDoctorDocs();
  await createDoctorAccounts();
  process.exit(0);
}

run().catch((err) => {
  console.error('Gagal:', err);
  process.exit(1);
});
