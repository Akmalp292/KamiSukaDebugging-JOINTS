import fs from 'fs';
import * as XLSX from 'xlsx';

const f = process.argv[2];
const wb = XLSX.read(fs.readFileSync(f), { type: 'buffer' });
console.log('Sheet:', wb.SheetNames);
for (const name of wb.SheetNames) {
  const rows = XLSX.utils.sheet_to_json(wb.Sheets[name]);
  console.log('---', name, '| jumlah baris:', rows.length);
  console.log(rows.slice(0, 3));
}