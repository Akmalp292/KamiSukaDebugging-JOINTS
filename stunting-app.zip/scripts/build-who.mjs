import fs from 'fs';
import path from 'path';
import * as XLSX from 'xlsx';

const dir = process.argv[2];
if (!dir) throw new Error('Pakai: node scripts/build-who.mjs C:\\who');

const files = fs.readdirSync(dir).filter((n) => n.toLowerCase().endsWith('.xlsx'));
const norm = (n) => n.toLowerCase().replace(/[_ ]/g, '-');

function pick(ind, sex) {
  return files
    .filter((n) => {
      const l = norm(n);
      return l.includes(ind) && l.includes(sex) && l.includes('zscore') && !l.includes('week') && !l.includes('percentile');
    })
    .sort(); // 0-to-2 dulu, lalu 2-to-5 (menimpa bulan 24)
}

const out = { hfa: { boys: [], girls: [] }, wfa: { boys: [], girls: [] } };
const jobs = [['hfa', 'lhfa'], ['wfa', 'wfa']];

for (const [key, prefix] of jobs) {
  for (const sex of ['boys', 'girls']) {
    const picked = pick(prefix, sex);
    if (!picked.length) throw new Error(`File tidak ditemukan: ${prefix} ${sex}`);
    console.log(key, sex, '<-', picked.join(' + '));

    const byMonth = [];
    for (const f of picked) {
      const wb = XLSX.read(fs.readFileSync(path.join(dir, f)), { type: 'buffer' });
      const rows = XLSX.utils
        .sheet_to_json(wb.Sheets[wb.SheetNames[0]])
        .map((o) => Object.fromEntries(Object.entries(o).map(([k, v]) => [k.trim(), v])));
      const seen = new Set();
      for (const r of rows) {
        let t;
        if (r.Month !== undefined) t = Number(r.Month);
        else if (r.Day !== undefined) t = Math.round(r.Day / 30.4375);
        if (!Number.isInteger(t) || t < 0 || t > 60) continue;
        if (r.Month === undefined && seen.has(t)) continue;
        seen.add(t);
        byMonth[t] = { L: Number(r.L), M: Number(r.M), S: Number(r.S) };
      }
    }

    const missing = [];
    for (let t = 0; t <= 60; t++) {
      const x = byMonth[t];
      if (!x || ![x.L, x.M, x.S].every(Number.isFinite)) missing.push(t);
    }
    if (missing.length) throw new Error(`${key} ${sex}: bulan kosong/rusak -> ${missing.join(', ')}`);

    out[key][sex] = byMonth;
    console.log('  OK 61 bulan | M bulan 0 =', byMonth[0].M, '| M bulan 24 =', byMonth[24].M, '| M bulan 60 =', byMonth[60].M);
  }
}

fs.mkdirSync('src/data', { recursive: true });
fs.writeFileSync('src/data/who.json', JSON.stringify(out));
console.log('Selesai: src/data/who.json');