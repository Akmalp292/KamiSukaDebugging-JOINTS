import concurrent.futures
import json
import math
import os
import re
import time
import urllib.parse
import urllib.request

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from google import genai
from pydantic import BaseModel

load_dotenv()

client = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])
MODEL_ID = "gemma-4-26b-a4b-it"

with open("knowledge_base.json", "r", encoding="utf-8") as f:
    knowledge_base = json.load(f)

STOPWORDS = {"apa", "cara", "dimana", "bagaimana", "yang", "di", "ini", "utama", "adalah", "untuk"}
TOPIK_RELEVAN = [
    "stunting", "gizi", "anak", "bayi", "balita", "tumbuh", "kembang", "mpasi", "imunisasi",
    "dokter", "konsultasi", "posyandu", "kehamilan", "hamil", "asi", "kesehatan", "makan",
    "menu", "resep", "berat", "tinggi", "vitamin", "zat besi", "demam", "batuk", "diare",
    "pelacak", "status", "ringkasan", "sos", "darurat", "ambulans",
]

TANPA_MARKDOWN = "Jawab dalam teks polos, jangan gunakan format markdown seperti tanda bintang, heading, atau bullet point."
ATURAN_MEDIS = (
    "Kamu bukan dokter: jangan mendiagnosis dan jangan menyebut dosis obat. "
    "Untuk keluhan kesehatan, beri informasi umum yang singkat lalu sarankan konsultasi dokter lewat tombol "
    "Konsultasi Online di aplikasi. Jika ada tanda bahaya (kejang, sesak napas, tidak sadar, perdarahan, anak sangat lemas), "
    "minta segera menelepon 119 atau ke fasilitas kesehatan terdekat."
)
TIDAK_ADA = "Tidak disebutkan dokter."


def bersihkan_markdown(text):
    text = re.sub(r'^#{1,6}\s*', '', text, flags=re.MULTILINE)
    text = re.sub(r'\*\*(.*?)\*\*', r'\1', text)
    text = re.sub(r'^\*\s+', '• ', text, flags=re.MULTILINE)
    text = re.sub(r'(?<!\*)\*(?!\*)([^\*\n]+?)\*(?!\*)', r'\1', text)
    return text.strip()


def cari_konteks(pertanyaan_user):
    pertanyaan_lower = pertanyaan_user.lower()
    hasil_cocok = []
    for entri in knowledge_base:
        kata_kunci = [k for k in (entri["topik"].split("_") + entri["judul"].lower().split()) if k not in STOPWORDS]
        jumlah_cocok = sum(1 for kata in kata_kunci if kata.lower() in pertanyaan_lower)
        if jumlah_cocok >= 2 or (len(kata_kunci) == 1 and jumlah_cocok == 1):
            hasil_cocok.append(entri)
    return hasil_cocok


def generate(system_prompt, user_prompt):
    response = client.models.generate_content(
        model=MODEL_ID,
        contents=user_prompt,
        config={"system_instruction": system_prompt},
    )
    return bersihkan_markdown(response.text.strip())


def format_riwayat(history):
    baris = []
    for m in (history or [])[-6:]:
        if not isinstance(m, dict) or not m.get("text"):
            continue
        siapa = "Ibu" if m.get("role") == "user" else "Asisten"
        baris.append(f"{siapa}: {m['text']}")
    return "\n".join(baris)


def jawab_chatbot(pertanyaan_user, history=None):
    riwayat = format_riwayat(history)
    konteks_ditemukan = cari_konteks(pertanyaan_user)
    teks_relevansi = (pertanyaan_user + " " + riwayat).lower()

    if not konteks_ditemukan and not any(t in teks_relevansi for t in TOPIK_RELEVAN):
        return "Maaf, saya hanya bisa membantu pertanyaan seputar kesehatan anak, gizi, dan stunting. Untuk pertanyaan lain, silakan gunakan sumber lain ya."

    if konteks_ditemukan:
        konteks_text = "\n\n".join([f"{k['judul']}: {k['isi']}" for k in konteks_ditemukan])
        system_prompt = (
            "Kamu adalah asisten StuntingCare. Jawab pertanyaan HANYA berdasarkan informasi berikut, "
            f"jangan mengarang jika informasi tidak tersedia. {ATURAN_MEDIS} {TANPA_MARKDOWN}\n\n{konteks_text}"
        )
    else:
        system_prompt = (
            "Kamu adalah asisten edukasi kesehatan StuntingCare yang membantu orang tua memahami gizi dan tumbuh kembang anak. "
            f"Jawab dengan bahasa yang mudah dipahami, akurat, dan singkat. {ATURAN_MEDIS} {TANPA_MARKDOWN}"
        )

    user_prompt = pertanyaan_user
    if riwayat:
        user_prompt = f"Percakapan sebelumnya:\n{riwayat}\n\nPertanyaan terbaru dari Ibu: {pertanyaan_user}"
    return generate(system_prompt, user_prompt)


PROMPT_RINGKAS = (
    "Kamu meringkas konsultasi online antara pasien (ibu) dan dokter. "
    "Tulis TEPAT tiga baris dengan format ini, tanpa teks lain:\n"
    "DIAGNOSA: ...\n"
    "RESEP: ...\n"
    "PANTANGAN: ...\n\n"
    "Aturan:\n"
    "- Hanya isi yang benar-benar disampaikan DOKTER di percakapan. Jangan menambah, menebak, atau memakai pengetahuan sendiri.\n"
    "- DIAGNOSA: penilaian atau kondisi menurut dokter. Jika dokter tidak menyebut diagnosis, tulis saran utama dokter.\n"
    "- RESEP: obat, vitamin, atau suplemen yang disebut dokter beserta aturan pakai persis seperti yang disebut. Jangan mengarang dosis.\n"
    "- PANTANGAN: makanan atau kebiasaan yang harus dihindari atau dibatasi menurut dokter.\n"
    f"- Jika suatu bagian tidak disebut dokter, tulis persis: {TIDAK_ADA}\n"
    "- Maksimal 2 kalimat per baris, bahasa Indonesia sederhana. " + TANPA_MARKDOWN
)


def parse_poin(teks):
    hasil = {}
    for kunci, label in (("diagnosa", "DIAGNOSA"), ("resep", "RESEP"), ("pantangan", "PANTANGAN")):
        m = re.search(
            rf"{label}\s*:\s*(.+?)(?=\n\s*(?:DIAGNOSA|RESEP|PANTANGAN)\s*:|\Z)",
            teks, re.S | re.I,
        )
        isi = re.sub(r"\s+", " ", m.group(1)).strip() if m else ""
        hasil[kunci] = isi or TIDAK_ADA
    return hasil


def ringkas_percakapan(percakapan_text):
    mentah = generate(PROMPT_RINGKAS, f"Percakapan:\n\n{percakapan_text[-8000:]}")
    return parse_poin(mentah)


# ─────────────────────────────────────────────
#  PROXY FASKES
#  Rumah sakit & klinik : Overpass (tag baku, ringan)
#  Posyandu             : Nominatim (cepat untuk pencarian nama)
#  Cadangan             : jika Overpass gagal semua, semuanya lewat Nominatim
#  Browser memanggil /faskes di sini, jadi tidak ada masalah CORS.
# ─────────────────────────────────────────────
UA = "StuntingCare/1.0 (stuntingcare.my.id)"
OVERPASS_SERVERS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
    "https://overpass.private.coffee/api/interpreter",
]
FASKES_CACHE = {}
TTL_NORMAL = 6 * 3600
TTL_CADANGAN = 10 * 60


def query_faskes(lat, lon, r):
    a = f"(around:{r},{lat},{lon})"
    return (
        "[out:json][timeout:20];("
        f'nwr["amenity"="hospital"]{a};'
        f'nwr["amenity"="clinic"]{a};'
        f'nwr["healthcare"="hospital"]{a};'
        f'nwr["healthcare"="clinic"]{a};'
        ");out center 60;"
    )


def satu_overpass(url, ql):
    mulai = time.time()
    data = urllib.parse.urlencode({"data": ql}).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={"User-Agent": UA, "Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=25) as r:
        hasil = json.loads(r.read().decode("utf-8"))
    if hasil.get("remark") and not hasil.get("elements"):
        raise ValueError("server sibuk: " + str(hasil.get("remark"))[:80])
    print(f"[faskes] OK {url} ({time.time() - mulai:.1f} dtk, {len(hasil.get('elements', []))} data)")
    return hasil.get("elements", [])


def tanya_overpass(ql):
    """Semua server ditanya bersamaan, yang tercepat berhasil dipakai."""
    ex = concurrent.futures.ThreadPoolExecutor(max_workers=len(OVERPASS_SERVERS))
    futs = {ex.submit(satu_overpass, u, ql): u for u in OVERPASS_SERVERS}
    galat = []
    try:
        for fut in concurrent.futures.as_completed(futs, timeout=32):
            try:
                return fut.result()
            except Exception as e:
                print(f"[faskes] GAGAL {futs[fut]}: {e}")
                galat.append(str(e)[:80])
    except concurrent.futures.TimeoutError:
        galat.append("waktu habis")
    finally:
        ex.shutdown(wait=False)
    raise RuntimeError(" | ".join(galat) or "semua server gagal")


def cari_nominatim(lat, lon, kata, km=6, limit=15):
    dlat = km / 111.0
    dlon = km / (111.0 * max(math.cos(math.radians(lat)), 0.2))
    params = {
        "q": kata,
        "format": "jsonv2",
        "limit": str(limit),
        "viewbox": f"{lon - dlon},{lat + dlat},{lon + dlon},{lat - dlat}",
        "bounded": "1",
        "accept-language": "id",
    }
    url = "https://nominatim.openstreetmap.org/search?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=12) as r:
        data = json.loads(r.read().decode("utf-8"))
    hasil = []
    for d in data:
        try:
            ttampil = str(d.get("display_name", ""))
            nama = d.get("name") or tampil.split(",")[0].strip()
            if not nama:
                continue
            hasil.append({
                "type": "nom",
                "id": d.get("place_id"),
                "lat": float(d["lat"]),
                "lon": float(d["lon"]),
                "tags": {"name": nama, "addr:full": ", ".join(tampil.split(", ")[1:4])},
            })
        except (KeyError, ValueError, TypeError):
            continue
    print(f"[faskes] Nominatim '{kata}': {len(hasil)} data")
    return hasil


def gabung(*daftar):
    seen, hasil = set(), []
    for lst in daftar:
        for el in lst:
            lat = el.get("lat") if el.get("lat") is not None else (el.get("center") or {}).get("lat")
            lon = el.get("lon") if el.get("lon") is not None else (el.get("center") or {}).get("lon")
            nama = ((el.get("tags") or {}).get("name") or "").strip().lower()
            if lat is None or lon is None or not nama:
                continue
            k = (nama, round(lat, 3), round(lon, 3))
            if k in seen:
                continue
            seen.add(k)
            hasil.append(el)
    return hasil


app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://stuntingcare.my.id", "https://www.stuntingcare.my.id"],
    allow_origin_regex=r"http://(localhost|127\.0\.0\.1|192\.168\.\d+\.\d+):\d+",
    allow_methods=["*"],
    allow_headers=["*"],
)


class ChatRequest(BaseModel):
    message: str
    history: list = []


class SummarizeRequest(BaseModel):
    percakapan: str


@app.post("/chat")
def chat_endpoint(req: ChatRequest):
    return {"reply": jawab_chatbot(req.message, req.history)}


@app.post("/summarize")
def summarize_endpoint(req: SummarizeRequest):
    poin = ringkas_percakapan(req.percakapan)
    teks = (
        f"Diagnosa: {poin['diagnosa']}\n"
        f"Resep Obat: {poin['resep']}\n"
        f"Pantangan Makanan: {poin['pantangan']}"
    )
    return {"poin": poin, "summary": teks}


@app.get("/faskes")
def faskes_endpoint(lat: float, lon: float):
    if not (-11.5 <= lat <= 6.5 and 94 <= lon <= 142):
        raise HTTPException(status_code=400, detail="Koordinat di luar Indonesia.")

    kunci = f"{lat:.2f}_{lon:.2f}"
    tersimpan = FASKES_CACHE.get(kunci)
    if tersimpan and time.time() - tersimpan["t"] < tersimpan["ttl"]:
        return {"elements": tersimpan["d"], "cache": True}

    # 1) rumah sakit & klinik dari Overpass
    elemen_osm, overpass_ok = [], True
    try:
        for r in (4000, 12000):
            elemen_osm = tanya_overpass(query_faskes(lat, lon, r))
            if len(elemen_osm) >= 4:
                break
    except Exception as e:
        overpass_ok = False
        print(f"[faskes] Overpass gagal semua: {e}")

    # 2) posyandu (dan, bila Overpass gagal, semua jenis) dari Nominatim. Maks 1 permintaan/detik.
    kata_cari = ["posyandu"] if overpass_ok else ["rumah sakit", "puskesmas", "klinik", "posyandu"]
    elemen_nom = []
    for i, kata in enumerate(kata_cari):
        try:
            if i:
                time.sleep(1.0)
            elemen_nom += cari_nominatim(lat, lon, kata)
        except Exception as e:
            print(f"[faskes] Nominatim '{kata}' gagal: {e}")

    semua = gabung(elemen_osm, elemen_nom)

    if not semua and not overpass_ok:
        raise HTTPException(status_code=502, detail="Semua sumber data faskes sedang tidak bisa dihubungi.")

    if semua:
        FASKES_CACHE[kunci] = {"t": time.time(), "d": semua, "ttl": TTL_NORMAL if overpass_ok else TTL_CADANGAN}
    return {"elements": semua, "cache": False, "sumber": "overpass+nominatim" if overpass_ok else "nominatim"}


@app.get("/")
def health_check():
    return {"status": "ok", "model": MODEL_ID}