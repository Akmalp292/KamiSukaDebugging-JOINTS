import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  build: {
    rollupOptions: {
      // The legacy Firebase code imports straight from the gstatic CDN
      // (e.g. "https://www.gstatic.com/firebasejs/10.13.0/firebase-app.js").
      // Keep those as native ESM imports instead of asking Rollup to bundle them.
      external: (id) => id.startsWith('https://') || id.startsWith('http://'),
    },
  },
})
